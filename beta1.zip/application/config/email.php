<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	$config['protocol'] ='smtp';
	$config['smtp_host']='ssl://smtp.gmail.com';
	$config['smtp_user']='ermx@metistd.com';
	$config['smtp_pass']='cao38790050';
	$config['smtp_port']='465';
	$config['newline']="\r\n";
	$config['mailtype']='html';
	
?>