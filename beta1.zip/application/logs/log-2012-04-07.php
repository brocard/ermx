<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-07 00:00:21 --> Config Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:00:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:00:21 --> URI Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Router Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Output Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Security Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Input Class Initialized
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:21 --> CRSF cookie Set
DEBUG - 2012-04-07 00:00:21 --> CSRF token verified 
DEBUG - 2012-04-07 00:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:00:21 --> Language Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Loader Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Controller Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Model Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Model Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Session Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:00:21 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:00:21 --> Session routines successfully run
DEBUG - 2012-04-07 00:00:21 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:00:21 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:00:21 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:00:21 --> ermex/newregistrypost
DEBUG - 2012-04-07 00:00:21 --> App_model/createNewRegistry
DEBUG - 2012-04-07 00:00:21 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:00:21 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:00:21 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:00:21 --> Final output sent to browser
DEBUG - 2012-04-07 00:00:21 --> Total execution time: 0.1189
DEBUG - 2012-04-07 00:00:49 --> Config Class Initialized
DEBUG - 2012-04-07 00:00:49 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:00:49 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:00:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:00:49 --> URI Class Initialized
DEBUG - 2012-04-07 00:00:49 --> Router Class Initialized
DEBUG - 2012-04-07 00:00:49 --> Output Class Initialized
DEBUG - 2012-04-07 00:00:49 --> Security Class Initialized
DEBUG - 2012-04-07 00:00:49 --> Input Class Initialized
DEBUG - 2012-04-07 00:00:49 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:49 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:49 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:49 --> CRSF cookie Set
DEBUG - 2012-04-07 00:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:00:49 --> Language Class Initialized
DEBUG - 2012-04-07 00:00:49 --> Loader Class Initialized
DEBUG - 2012-04-07 00:00:49 --> Controller Class Initialized
DEBUG - 2012-04-07 00:00:49 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:00:49 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:00:49 --> Session Class Initialized
DEBUG - 2012-04-07 00:00:49 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:00:49 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:00:49 --> Session routines successfully run
DEBUG - 2012-04-07 00:00:49 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:00:49 --> Pages view: mainmenu
DEBUG - 2012-04-07 00:00:49 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:00:49 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-07 00:00:49 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:00:49 --> Final output sent to browser
DEBUG - 2012-04-07 00:00:49 --> Total execution time: 0.0120
DEBUG - 2012-04-07 00:00:54 --> Config Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:00:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:00:54 --> URI Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Router Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Output Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Security Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Input Class Initialized
DEBUG - 2012-04-07 00:00:54 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:54 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:54 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:54 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:54 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:54 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:54 --> XSS Filtering completed
DEBUG - 2012-04-07 00:00:54 --> CRSF cookie Set
DEBUG - 2012-04-07 00:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:00:54 --> Language Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Loader Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Controller Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Model Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Model Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Session Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:00:54 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:00:54 --> Session routines successfully run
DEBUG - 2012-04-07 00:00:54 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:00:54 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:00:54 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:00:54 --> ermex/mapLocator
DEBUG - 2012-04-07 00:00:54 --> localizando por GPS
DEBUG - 2012-04-07 00:00:54 --> creando mapa por coords: 18.8563609 x -97.07180989999999 
DEBUG - 2012-04-07 00:00:54 --> GMap class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:00:54 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:00:54 --> File loaded: application/views/pages/mapa.php
DEBUG - 2012-04-07 00:00:54 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:00:54 --> Final output sent to browser
DEBUG - 2012-04-07 00:00:54 --> Total execution time: 0.0155
DEBUG - 2012-04-07 00:03:37 --> Config Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:03:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:03:37 --> URI Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Router Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Output Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Security Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Input Class Initialized
DEBUG - 2012-04-07 00:03:37 --> XSS Filtering completed
DEBUG - 2012-04-07 00:03:37 --> XSS Filtering completed
DEBUG - 2012-04-07 00:03:37 --> XSS Filtering completed
DEBUG - 2012-04-07 00:03:37 --> XSS Filtering completed
DEBUG - 2012-04-07 00:03:37 --> XSS Filtering completed
DEBUG - 2012-04-07 00:03:37 --> XSS Filtering completed
DEBUG - 2012-04-07 00:03:37 --> XSS Filtering completed
DEBUG - 2012-04-07 00:03:37 --> CRSF cookie Set
DEBUG - 2012-04-07 00:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:03:37 --> Language Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Loader Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Controller Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Model Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Model Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Session Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:03:37 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:03:37 --> Session routines successfully run
DEBUG - 2012-04-07 00:03:37 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:03:37 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:03:37 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:03:37 --> ermex/mapLocator
DEBUG - 2012-04-07 00:03:37 --> localizando por GPS
DEBUG - 2012-04-07 00:03:37 --> creando mapa por coords: 18.8563609 x -97.07180989999999 
DEBUG - 2012-04-07 00:03:37 --> GMap class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:03:37 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:03:37 --> File loaded: application/views/pages/mapa.php
DEBUG - 2012-04-07 00:03:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:03:37 --> Final output sent to browser
DEBUG - 2012-04-07 00:03:37 --> Total execution time: 0.0505
DEBUG - 2012-04-07 00:09:23 --> Config Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:09:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:09:23 --> URI Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Router Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Output Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Security Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Input Class Initialized
DEBUG - 2012-04-07 00:09:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:23 --> CRSF cookie Set
DEBUG - 2012-04-07 00:09:23 --> CSRF token verified 
DEBUG - 2012-04-07 00:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:09:23 --> Language Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Loader Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Controller Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Model Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Model Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Session Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:09:23 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:09:23 --> Session routines successfully run
DEBUG - 2012-04-07 00:09:23 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:09:23 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:09:23 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:09:23 --> ermex/newregistry	
DEBUG - 2012-04-07 00:09:23 --> forma de registro para: 18.8563609 x -97.07180989999999 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-07 00:09:23 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:09:23 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-07 00:09:23 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:09:23 --> Final output sent to browser
DEBUG - 2012-04-07 00:09:23 --> Total execution time: 0.0190
DEBUG - 2012-04-07 00:09:55 --> Config Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:09:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:09:55 --> URI Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Router Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Output Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Security Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Input Class Initialized
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:09:55 --> CRSF cookie Set
DEBUG - 2012-04-07 00:09:55 --> CSRF token verified 
DEBUG - 2012-04-07 00:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:09:55 --> Language Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Loader Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Controller Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Model Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Model Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Session Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:09:55 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:09:55 --> Session routines successfully run
DEBUG - 2012-04-07 00:09:55 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:09:56 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:09:56 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:09:56 --> ermex/newregistrypost
DEBUG - 2012-04-07 00:09:56 --> App_model/createNewRegistry
DEBUG - 2012-04-07 00:09:56 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:09:56 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:09:56 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:09:56 --> Final output sent to browser
DEBUG - 2012-04-07 00:09:56 --> Total execution time: 0.0432
DEBUG - 2012-04-07 00:12:35 --> Config Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:12:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:12:35 --> URI Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Router Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Output Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Security Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Input Class Initialized
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> XSS Filtering completed
DEBUG - 2012-04-07 00:12:35 --> CRSF cookie Set
DEBUG - 2012-04-07 00:12:35 --> CSRF token verified 
DEBUG - 2012-04-07 00:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:12:35 --> Language Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Loader Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Controller Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Model Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Model Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Session Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:12:35 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:12:35 --> Session routines successfully run
DEBUG - 2012-04-07 00:12:35 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:12:35 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:12:35 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:12:35 --> ermex/newregistrypost
DEBUG - 2012-04-07 00:12:35 --> App_model/createNewRegistry
DEBUG - 2012-04-07 00:12:35 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:12:35 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:12:35 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:12:35 --> Final output sent to browser
DEBUG - 2012-04-07 00:12:35 --> Total execution time: 0.0180
DEBUG - 2012-04-07 00:13:09 --> Config Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:13:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:13:09 --> URI Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Router Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Output Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Security Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Input Class Initialized
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:09 --> CRSF cookie Set
DEBUG - 2012-04-07 00:13:09 --> CSRF token verified 
DEBUG - 2012-04-07 00:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:13:09 --> Language Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Loader Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Controller Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Model Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Model Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Session Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:13:09 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:13:09 --> Session routines successfully run
DEBUG - 2012-04-07 00:13:09 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:13:09 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:13:09 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:13:09 --> ermex/newregistrypost
DEBUG - 2012-04-07 00:13:09 --> App_model/createNewRegistry
DEBUG - 2012-04-07 00:13:09 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:13:09 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:13:09 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:13:09 --> Final output sent to browser
DEBUG - 2012-04-07 00:13:09 --> Total execution time: 0.0214
DEBUG - 2012-04-07 00:13:23 --> Config Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:13:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:13:23 --> URI Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Router Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Output Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Security Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Input Class Initialized
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> XSS Filtering completed
DEBUG - 2012-04-07 00:13:23 --> CRSF cookie Set
DEBUG - 2012-04-07 00:13:23 --> CSRF token verified 
DEBUG - 2012-04-07 00:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:13:23 --> Language Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Loader Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Controller Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Model Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Model Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Session Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:13:23 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:13:23 --> Session routines successfully run
DEBUG - 2012-04-07 00:13:23 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:13:23 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:13:23 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:13:23 --> ermex/newregistrypost
DEBUG - 2012-04-07 00:13:23 --> App_model/createNewRegistry
DEBUG - 2012-04-07 00:13:23 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:13:23 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:13:23 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:13:23 --> Final output sent to browser
DEBUG - 2012-04-07 00:13:23 --> Total execution time: 0.0194
DEBUG - 2012-04-07 00:14:15 --> Config Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:14:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:14:15 --> URI Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Router Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Output Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Security Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Input Class Initialized
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:15 --> CRSF cookie Set
DEBUG - 2012-04-07 00:14:15 --> CSRF token verified 
DEBUG - 2012-04-07 00:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:14:15 --> Language Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Loader Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Controller Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Model Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Model Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Session Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:14:15 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:14:15 --> Session routines successfully run
DEBUG - 2012-04-07 00:14:15 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:14:15 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:14:15 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:14:15 --> ermex/newregistrypost
DEBUG - 2012-04-07 00:14:15 --> App_model/createNewRegistry
DEBUG - 2012-04-07 00:14:15 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:14:15 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:14:15 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:14:15 --> Final output sent to browser
DEBUG - 2012-04-07 00:14:15 --> Total execution time: 0.0198
DEBUG - 2012-04-07 00:14:44 --> Config Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:14:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:14:44 --> URI Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Router Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Output Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Security Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Input Class Initialized
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:14:44 --> CRSF cookie Set
DEBUG - 2012-04-07 00:14:44 --> CSRF token verified 
DEBUG - 2012-04-07 00:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:14:44 --> Language Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Loader Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Controller Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Model Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Model Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Session Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:14:44 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:14:44 --> Session routines successfully run
DEBUG - 2012-04-07 00:14:44 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:14:44 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:14:44 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:14:44 --> ermex/newregistrypost
DEBUG - 2012-04-07 00:14:44 --> App_model/createNewRegistry
DEBUG - 2012-04-07 00:14:44 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:14:44 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:14:44 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:14:44 --> Final output sent to browser
DEBUG - 2012-04-07 00:14:44 --> Total execution time: 0.0207
DEBUG - 2012-04-07 00:15:01 --> Config Class Initialized
DEBUG - 2012-04-07 00:15:01 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:15:01 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:15:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:15:01 --> URI Class Initialized
DEBUG - 2012-04-07 00:15:01 --> Router Class Initialized
DEBUG - 2012-04-07 00:15:01 --> No URI present. Default controller set.
DEBUG - 2012-04-07 00:15:01 --> Output Class Initialized
DEBUG - 2012-04-07 00:15:01 --> Security Class Initialized
DEBUG - 2012-04-07 00:15:01 --> Input Class Initialized
DEBUG - 2012-04-07 00:15:01 --> XSS Filtering completed
DEBUG - 2012-04-07 00:15:01 --> XSS Filtering completed
DEBUG - 2012-04-07 00:15:01 --> XSS Filtering completed
DEBUG - 2012-04-07 00:15:01 --> CRSF cookie Set
DEBUG - 2012-04-07 00:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:15:01 --> Language Class Initialized
DEBUG - 2012-04-07 00:15:01 --> Loader Class Initialized
DEBUG - 2012-04-07 00:15:01 --> Controller Class Initialized
DEBUG - 2012-04-07 00:15:01 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:15:01 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:15:01 --> Session Class Initialized
DEBUG - 2012-04-07 00:15:01 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:15:01 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:15:01 --> Session routines successfully run
DEBUG - 2012-04-07 00:15:01 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:15:01 --> Pages view: home
DEBUG - 2012-04-07 00:15:01 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:15:01 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 00:15:01 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:15:01 --> Final output sent to browser
DEBUG - 2012-04-07 00:15:01 --> Total execution time: 0.0124
DEBUG - 2012-04-07 00:25:09 --> Config Class Initialized
DEBUG - 2012-04-07 00:25:09 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:25:09 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:25:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:25:09 --> URI Class Initialized
DEBUG - 2012-04-07 00:25:09 --> Router Class Initialized
DEBUG - 2012-04-07 00:25:09 --> Output Class Initialized
DEBUG - 2012-04-07 00:25:09 --> Security Class Initialized
DEBUG - 2012-04-07 00:25:09 --> Input Class Initialized
DEBUG - 2012-04-07 00:25:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:09 --> CRSF cookie Set
DEBUG - 2012-04-07 00:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:25:09 --> Language Class Initialized
DEBUG - 2012-04-07 00:25:09 --> Loader Class Initialized
DEBUG - 2012-04-07 00:25:09 --> Controller Class Initialized
DEBUG - 2012-04-07 00:25:09 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:25:09 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:25:09 --> Session Class Initialized
DEBUG - 2012-04-07 00:25:09 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:25:09 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:25:09 --> Session routines successfully run
DEBUG - 2012-04-07 00:25:09 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:09 --> Pages view: mainmenu
DEBUG - 2012-04-07 00:25:09 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:25:09 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-07 00:25:09 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:25:09 --> Final output sent to browser
DEBUG - 2012-04-07 00:25:09 --> Total execution time: 0.0159
DEBUG - 2012-04-07 00:25:11 --> Config Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:25:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:25:11 --> URI Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Router Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Output Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Security Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Input Class Initialized
DEBUG - 2012-04-07 00:25:11 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:11 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:11 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:11 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:11 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:11 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:11 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:11 --> CRSF cookie Set
DEBUG - 2012-04-07 00:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:25:11 --> Language Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Loader Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Controller Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Model Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Model Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Session Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:25:11 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:25:11 --> Session routines successfully run
DEBUG - 2012-04-07 00:25:11 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:11 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:25:11 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:25:11 --> ermex/mapLocator
DEBUG - 2012-04-07 00:25:11 --> localizando por GPS
DEBUG - 2012-04-07 00:25:11 --> creando mapa por coords: 18.8563609 x -97.07180989999999 
DEBUG - 2012-04-07 00:25:11 --> GMap class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:11 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:25:11 --> File loaded: application/views/pages/mapa.php
DEBUG - 2012-04-07 00:25:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:25:11 --> Final output sent to browser
DEBUG - 2012-04-07 00:25:11 --> Total execution time: 0.0183
DEBUG - 2012-04-07 00:25:12 --> Config Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:25:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:25:12 --> URI Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Router Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Output Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Security Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Input Class Initialized
DEBUG - 2012-04-07 00:25:12 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:12 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:12 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:12 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:12 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:12 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:12 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:12 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:12 --> CRSF cookie Set
DEBUG - 2012-04-07 00:25:12 --> CSRF token verified 
DEBUG - 2012-04-07 00:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:25:12 --> Language Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Loader Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Controller Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Model Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Model Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Session Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:25:12 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:25:12 --> Session routines successfully run
DEBUG - 2012-04-07 00:25:12 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:12 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:25:12 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:25:12 --> ermex/newregistry	
DEBUG - 2012-04-07 00:25:12 --> forma de registro para: 18.8563609 x -97.07180989999999 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-07 00:25:12 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:25:12 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-07 00:25:12 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:25:12 --> Final output sent to browser
DEBUG - 2012-04-07 00:25:12 --> Total execution time: 0.0141
DEBUG - 2012-04-07 00:25:15 --> Config Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:25:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:25:15 --> URI Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Router Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Output Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Security Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Input Class Initialized
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> CRSF cookie Set
DEBUG - 2012-04-07 00:25:15 --> CSRF token verified 
DEBUG - 2012-04-07 00:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:25:15 --> Language Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Loader Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Controller Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Model Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Model Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Session Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:25:15 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Session routines successfully run
DEBUG - 2012-04-07 00:25:15 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:15 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:25:15 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:25:15 --> ermex/newregistrypost
DEBUG - 2012-04-07 00:25:15 --> App_model/createNewRegistry
DEBUG - 2012-04-07 00:25:15 --> Config Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:25:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:25:15 --> URI Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Router Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Output Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Security Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Input Class Initialized
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:15 --> CRSF cookie Set
DEBUG - 2012-04-07 00:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:25:15 --> Language Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Loader Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Controller Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:25:15 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:25:15 --> Session Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:25:15 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:25:15 --> Session routines successfully run
DEBUG - 2012-04-07 00:25:15 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:15 --> Pages view: registrook
DEBUG - 2012-04-07 00:25:15 --> File loaded: application/views/templates/header.php
ERROR - 2012-04-07 00:25:15 --> Severity: Notice  --> Undefined variable: lat /usr/local/zend/apache2/htdocs/ermex/ermx/application/views/pages/registrook.php 13
ERROR - 2012-04-07 00:25:15 --> Severity: Notice  --> Undefined variable: lon /usr/local/zend/apache2/htdocs/ermex/ermx/application/views/pages/registrook.php 13
ERROR - 2012-04-07 00:25:15 --> Severity: Notice  --> Undefined variable: name /usr/local/zend/apache2/htdocs/ermex/ermx/application/views/pages/registrook.php 15
ERROR - 2012-04-07 00:25:15 --> Severity: Notice  --> Undefined variable: type /usr/local/zend/apache2/htdocs/ermex/ermx/application/views/pages/registrook.php 17
ERROR - 2012-04-07 00:25:15 --> Severity: Notice  --> Undefined variable: desc /usr/local/zend/apache2/htdocs/ermex/ermx/application/views/pages/registrook.php 19
DEBUG - 2012-04-07 00:25:15 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:25:15 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:25:15 --> Final output sent to browser
DEBUG - 2012-04-07 00:25:15 --> Total execution time: 0.0227
DEBUG - 2012-04-07 00:25:55 --> Config Class Initialized
DEBUG - 2012-04-07 00:25:55 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:25:55 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:25:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:25:55 --> URI Class Initialized
DEBUG - 2012-04-07 00:25:55 --> Router Class Initialized
DEBUG - 2012-04-07 00:25:55 --> Output Class Initialized
DEBUG - 2012-04-07 00:25:55 --> Security Class Initialized
DEBUG - 2012-04-07 00:25:55 --> Input Class Initialized
DEBUG - 2012-04-07 00:25:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:55 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:55 --> CRSF cookie Set
DEBUG - 2012-04-07 00:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:25:55 --> Language Class Initialized
DEBUG - 2012-04-07 00:25:55 --> Loader Class Initialized
DEBUG - 2012-04-07 00:25:55 --> Controller Class Initialized
DEBUG - 2012-04-07 00:25:55 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:25:55 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:25:55 --> Session Class Initialized
DEBUG - 2012-04-07 00:25:55 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:25:55 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:25:55 --> Session routines successfully run
DEBUG - 2012-04-07 00:25:55 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:55 --> Pages view: registrook
DEBUG - 2012-04-07 00:25:55 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:25:55 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:25:55 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:25:55 --> Final output sent to browser
DEBUG - 2012-04-07 00:25:55 --> Total execution time: 0.0163
DEBUG - 2012-04-07 00:25:58 --> Config Class Initialized
DEBUG - 2012-04-07 00:25:58 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:25:58 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:25:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:25:58 --> URI Class Initialized
DEBUG - 2012-04-07 00:25:58 --> Router Class Initialized
DEBUG - 2012-04-07 00:25:58 --> Output Class Initialized
DEBUG - 2012-04-07 00:25:58 --> Security Class Initialized
DEBUG - 2012-04-07 00:25:58 --> Input Class Initialized
DEBUG - 2012-04-07 00:25:58 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:58 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:58 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:58 --> CRSF cookie Set
DEBUG - 2012-04-07 00:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:25:58 --> Language Class Initialized
DEBUG - 2012-04-07 00:25:58 --> Loader Class Initialized
DEBUG - 2012-04-07 00:25:58 --> Controller Class Initialized
DEBUG - 2012-04-07 00:25:58 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:25:58 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:25:58 --> Session Class Initialized
DEBUG - 2012-04-07 00:25:58 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:25:58 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:25:58 --> Session routines successfully run
DEBUG - 2012-04-07 00:25:58 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:58 --> Pages view: registrook
DEBUG - 2012-04-07 00:25:58 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:25:58 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:25:58 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:25:58 --> Final output sent to browser
DEBUG - 2012-04-07 00:25:58 --> Total execution time: 0.0146
DEBUG - 2012-04-07 00:25:59 --> Config Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:25:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:25:59 --> URI Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Router Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Output Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Security Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Input Class Initialized
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> CRSF cookie Set
DEBUG - 2012-04-07 00:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:25:59 --> Language Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Loader Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Controller Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:25:59 --> Session Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:25:59 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Session routines successfully run
DEBUG - 2012-04-07 00:25:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:59 --> Pages view: registrook
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:25:59 --> Final output sent to browser
DEBUG - 2012-04-07 00:25:59 --> Total execution time: 0.0134
DEBUG - 2012-04-07 00:25:59 --> Config Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:25:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:25:59 --> URI Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Router Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Output Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Security Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Input Class Initialized
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> CRSF cookie Set
DEBUG - 2012-04-07 00:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:25:59 --> Language Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Loader Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Controller Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:25:59 --> Session Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:25:59 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Session routines successfully run
DEBUG - 2012-04-07 00:25:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:59 --> Pages view: registrook
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:25:59 --> Final output sent to browser
DEBUG - 2012-04-07 00:25:59 --> Total execution time: 0.0141
DEBUG - 2012-04-07 00:25:59 --> Config Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:25:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:25:59 --> URI Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Router Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Output Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Security Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Input Class Initialized
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> CRSF cookie Set
DEBUG - 2012-04-07 00:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:25:59 --> Language Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Loader Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Controller Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:25:59 --> Session Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:25:59 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Session routines successfully run
DEBUG - 2012-04-07 00:25:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:59 --> Pages view: registrook
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:25:59 --> Final output sent to browser
DEBUG - 2012-04-07 00:25:59 --> Total execution time: 0.0123
DEBUG - 2012-04-07 00:25:59 --> Config Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:25:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:25:59 --> URI Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Router Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Output Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Security Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Input Class Initialized
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:25:59 --> CRSF cookie Set
DEBUG - 2012-04-07 00:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:25:59 --> Language Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Loader Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Controller Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:25:59 --> Session Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:25:59 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:25:59 --> Session routines successfully run
DEBUG - 2012-04-07 00:25:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:25:59 --> Pages view: registrook
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:25:59 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:25:59 --> Final output sent to browser
DEBUG - 2012-04-07 00:25:59 --> Total execution time: 0.0122
DEBUG - 2012-04-07 00:26:00 --> Config Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:26:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:26:00 --> URI Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Router Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Output Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Security Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Input Class Initialized
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> CRSF cookie Set
DEBUG - 2012-04-07 00:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:26:00 --> Language Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Loader Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Controller Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:26:00 --> Session Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:26:00 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Session routines successfully run
DEBUG - 2012-04-07 00:26:00 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:26:00 --> Pages view: registrook
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:26:00 --> Final output sent to browser
DEBUG - 2012-04-07 00:26:00 --> Total execution time: 0.0119
DEBUG - 2012-04-07 00:26:00 --> Config Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:26:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:26:00 --> URI Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Router Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Output Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Security Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Input Class Initialized
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> CRSF cookie Set
DEBUG - 2012-04-07 00:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:26:00 --> Language Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Loader Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Controller Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:26:00 --> Session Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:26:00 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Session routines successfully run
DEBUG - 2012-04-07 00:26:00 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:26:00 --> Pages view: registrook
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:26:00 --> Final output sent to browser
DEBUG - 2012-04-07 00:26:00 --> Total execution time: 0.0134
DEBUG - 2012-04-07 00:26:00 --> Config Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:26:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:26:00 --> URI Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Router Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Output Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Security Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Input Class Initialized
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> CRSF cookie Set
DEBUG - 2012-04-07 00:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:26:00 --> Language Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Loader Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Controller Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:26:00 --> Session Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:26:00 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Session routines successfully run
DEBUG - 2012-04-07 00:26:00 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:26:00 --> Pages view: registrook
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:26:00 --> Final output sent to browser
DEBUG - 2012-04-07 00:26:00 --> Total execution time: 0.0135
DEBUG - 2012-04-07 00:26:00 --> Config Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:26:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:26:00 --> URI Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Router Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Output Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Security Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Input Class Initialized
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:00 --> CRSF cookie Set
DEBUG - 2012-04-07 00:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:26:00 --> Language Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Loader Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Controller Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:26:00 --> Session Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:26:00 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:26:00 --> Session routines successfully run
DEBUG - 2012-04-07 00:26:00 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:26:00 --> Pages view: registrook
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:26:00 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:26:00 --> Final output sent to browser
DEBUG - 2012-04-07 00:26:00 --> Total execution time: 0.0134
DEBUG - 2012-04-07 00:26:05 --> Config Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:26:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:26:05 --> URI Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Router Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Output Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Security Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Input Class Initialized
DEBUG - 2012-04-07 00:26:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:05 --> CRSF cookie Set
DEBUG - 2012-04-07 00:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:26:05 --> Language Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Loader Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Controller Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:26:05 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:26:05 --> Session Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:26:05 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Session routines successfully run
DEBUG - 2012-04-07 00:26:05 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:26:05 --> Pages view: registrook
DEBUG - 2012-04-07 00:26:05 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:26:05 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:26:05 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:26:05 --> Final output sent to browser
DEBUG - 2012-04-07 00:26:05 --> Total execution time: 0.0150
DEBUG - 2012-04-07 00:26:05 --> Config Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:26:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:26:05 --> URI Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Router Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Output Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Security Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Input Class Initialized
DEBUG - 2012-04-07 00:26:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:05 --> CRSF cookie Set
DEBUG - 2012-04-07 00:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:26:05 --> Language Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Loader Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Controller Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:26:05 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:26:05 --> Session Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:26:05 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Session routines successfully run
DEBUG - 2012-04-07 00:26:05 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:26:05 --> Pages view: registrook
DEBUG - 2012-04-07 00:26:05 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:26:05 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:26:05 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:26:05 --> Final output sent to browser
DEBUG - 2012-04-07 00:26:05 --> Total execution time: 0.0135
DEBUG - 2012-04-07 00:26:05 --> Config Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:26:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:26:05 --> URI Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Router Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Output Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Security Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Input Class Initialized
DEBUG - 2012-04-07 00:26:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:05 --> CRSF cookie Set
DEBUG - 2012-04-07 00:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:26:05 --> Language Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Loader Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Controller Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:26:05 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:26:05 --> Session Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:26:05 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:26:05 --> Session routines successfully run
DEBUG - 2012-04-07 00:26:05 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:26:05 --> Pages view: registrook
DEBUG - 2012-04-07 00:26:05 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:26:05 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:26:05 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:26:05 --> Final output sent to browser
DEBUG - 2012-04-07 00:26:05 --> Total execution time: 0.0131
DEBUG - 2012-04-07 00:26:06 --> Config Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:26:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:26:06 --> URI Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Router Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Output Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Security Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Input Class Initialized
DEBUG - 2012-04-07 00:26:06 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:06 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:06 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:06 --> CRSF cookie Set
DEBUG - 2012-04-07 00:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:26:06 --> Language Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Loader Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Controller Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:26:06 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:26:06 --> Session Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:26:06 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Session routines successfully run
DEBUG - 2012-04-07 00:26:06 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:26:06 --> Pages view: registrook
DEBUG - 2012-04-07 00:26:06 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:26:06 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:26:06 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:26:06 --> Final output sent to browser
DEBUG - 2012-04-07 00:26:06 --> Total execution time: 0.0115
DEBUG - 2012-04-07 00:26:06 --> Config Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:26:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:26:06 --> URI Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Router Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Output Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Security Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Input Class Initialized
DEBUG - 2012-04-07 00:26:06 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:06 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:06 --> XSS Filtering completed
DEBUG - 2012-04-07 00:26:06 --> CRSF cookie Set
DEBUG - 2012-04-07 00:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:26:06 --> Language Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Loader Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Controller Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:26:06 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:26:06 --> Session Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:26:06 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:26:06 --> Session routines successfully run
DEBUG - 2012-04-07 00:26:06 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:26:06 --> Pages view: registrook
DEBUG - 2012-04-07 00:26:06 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:26:06 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:26:06 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:26:06 --> Final output sent to browser
DEBUG - 2012-04-07 00:26:06 --> Total execution time: 0.0130
DEBUG - 2012-04-07 00:29:33 --> Config Class Initialized
DEBUG - 2012-04-07 00:29:33 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:29:33 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:29:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:29:33 --> URI Class Initialized
DEBUG - 2012-04-07 00:29:33 --> Router Class Initialized
DEBUG - 2012-04-07 00:29:33 --> Output Class Initialized
DEBUG - 2012-04-07 00:29:33 --> Security Class Initialized
DEBUG - 2012-04-07 00:29:33 --> Input Class Initialized
DEBUG - 2012-04-07 00:29:33 --> XSS Filtering completed
DEBUG - 2012-04-07 00:29:33 --> XSS Filtering completed
DEBUG - 2012-04-07 00:29:33 --> XSS Filtering completed
DEBUG - 2012-04-07 00:29:33 --> CRSF cookie Set
DEBUG - 2012-04-07 00:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:29:33 --> Language Class Initialized
DEBUG - 2012-04-07 00:29:33 --> Loader Class Initialized
DEBUG - 2012-04-07 00:29:33 --> Controller Class Initialized
DEBUG - 2012-04-07 00:29:33 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:29:33 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:29:33 --> Session Class Initialized
DEBUG - 2012-04-07 00:29:33 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:29:33 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:29:33 --> Session routines successfully run
DEBUG - 2012-04-07 00:29:33 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:29:33 --> Pages view: registrook
DEBUG - 2012-04-07 00:29:33 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:29:33 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:29:33 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:29:33 --> Final output sent to browser
DEBUG - 2012-04-07 00:29:33 --> Total execution time: 0.0152
DEBUG - 2012-04-07 00:30:09 --> Config Class Initialized
DEBUG - 2012-04-07 00:30:09 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:30:09 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:30:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:30:09 --> URI Class Initialized
DEBUG - 2012-04-07 00:30:09 --> Router Class Initialized
DEBUG - 2012-04-07 00:30:09 --> Output Class Initialized
DEBUG - 2012-04-07 00:30:09 --> Security Class Initialized
DEBUG - 2012-04-07 00:30:09 --> Input Class Initialized
DEBUG - 2012-04-07 00:30:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:30:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:30:09 --> XSS Filtering completed
DEBUG - 2012-04-07 00:30:09 --> CRSF cookie Set
DEBUG - 2012-04-07 00:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:30:09 --> Language Class Initialized
DEBUG - 2012-04-07 00:30:09 --> Loader Class Initialized
DEBUG - 2012-04-07 00:30:09 --> Controller Class Initialized
DEBUG - 2012-04-07 00:30:09 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:30:09 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:30:09 --> Session Class Initialized
DEBUG - 2012-04-07 00:30:09 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:30:09 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:30:10 --> Session routines successfully run
DEBUG - 2012-04-07 00:30:10 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:30:10 --> Pages view: registrook
DEBUG - 2012-04-07 00:30:10 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:30:10 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:30:10 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:30:10 --> Final output sent to browser
DEBUG - 2012-04-07 00:30:10 --> Total execution time: 0.5418
DEBUG - 2012-04-07 00:30:38 --> Config Class Initialized
DEBUG - 2012-04-07 00:30:38 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:30:38 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:30:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:30:38 --> URI Class Initialized
DEBUG - 2012-04-07 00:30:38 --> Router Class Initialized
DEBUG - 2012-04-07 00:30:39 --> Output Class Initialized
DEBUG - 2012-04-07 00:30:39 --> Security Class Initialized
DEBUG - 2012-04-07 00:30:39 --> Input Class Initialized
DEBUG - 2012-04-07 00:30:39 --> XSS Filtering completed
DEBUG - 2012-04-07 00:30:39 --> XSS Filtering completed
DEBUG - 2012-04-07 00:30:39 --> XSS Filtering completed
DEBUG - 2012-04-07 00:30:39 --> CRSF cookie Set
DEBUG - 2012-04-07 00:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:30:39 --> Language Class Initialized
DEBUG - 2012-04-07 00:30:39 --> Loader Class Initialized
DEBUG - 2012-04-07 00:30:39 --> Controller Class Initialized
DEBUG - 2012-04-07 00:30:39 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:30:39 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:30:39 --> Session Class Initialized
DEBUG - 2012-04-07 00:30:39 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:30:39 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:30:39 --> Session routines successfully run
DEBUG - 2012-04-07 00:30:39 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:30:39 --> Pages view: registrook
DEBUG - 2012-04-07 00:30:39 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:30:39 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:30:39 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:30:39 --> Final output sent to browser
DEBUG - 2012-04-07 00:30:39 --> Total execution time: 0.2745
DEBUG - 2012-04-07 00:31:44 --> Config Class Initialized
DEBUG - 2012-04-07 00:31:44 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:31:44 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:31:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:31:44 --> URI Class Initialized
DEBUG - 2012-04-07 00:31:44 --> Router Class Initialized
DEBUG - 2012-04-07 00:31:44 --> Output Class Initialized
DEBUG - 2012-04-07 00:31:44 --> Security Class Initialized
DEBUG - 2012-04-07 00:31:44 --> Input Class Initialized
DEBUG - 2012-04-07 00:31:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:31:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:31:44 --> XSS Filtering completed
DEBUG - 2012-04-07 00:31:44 --> CRSF cookie Set
DEBUG - 2012-04-07 00:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:31:44 --> Language Class Initialized
DEBUG - 2012-04-07 00:31:44 --> Loader Class Initialized
DEBUG - 2012-04-07 00:31:44 --> Controller Class Initialized
DEBUG - 2012-04-07 00:31:44 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:31:44 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:31:44 --> Session Class Initialized
DEBUG - 2012-04-07 00:31:44 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:31:44 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:31:44 --> Session routines successfully run
DEBUG - 2012-04-07 00:31:44 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:31:44 --> Pages view: registrook
DEBUG - 2012-04-07 00:31:44 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:31:44 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:31:44 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:31:44 --> Final output sent to browser
DEBUG - 2012-04-07 00:31:44 --> Total execution time: 0.2592
DEBUG - 2012-04-07 00:31:52 --> Config Class Initialized
DEBUG - 2012-04-07 00:31:52 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:31:52 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:31:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:31:52 --> URI Class Initialized
DEBUG - 2012-04-07 00:31:52 --> Router Class Initialized
DEBUG - 2012-04-07 00:31:52 --> Output Class Initialized
DEBUG - 2012-04-07 00:31:52 --> Security Class Initialized
DEBUG - 2012-04-07 00:31:52 --> Input Class Initialized
DEBUG - 2012-04-07 00:31:52 --> XSS Filtering completed
DEBUG - 2012-04-07 00:31:52 --> XSS Filtering completed
DEBUG - 2012-04-07 00:31:52 --> XSS Filtering completed
DEBUG - 2012-04-07 00:31:52 --> CRSF cookie Set
DEBUG - 2012-04-07 00:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:31:52 --> Language Class Initialized
DEBUG - 2012-04-07 00:31:52 --> Loader Class Initialized
DEBUG - 2012-04-07 00:31:52 --> Controller Class Initialized
DEBUG - 2012-04-07 00:31:52 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:31:52 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:31:52 --> Session Class Initialized
DEBUG - 2012-04-07 00:31:52 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:31:52 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:31:52 --> Session routines successfully run
DEBUG - 2012-04-07 00:31:52 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:31:52 --> Pages view: registrook
DEBUG - 2012-04-07 00:31:52 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:31:52 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:31:52 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:31:52 --> Final output sent to browser
DEBUG - 2012-04-07 00:31:52 --> Total execution time: 0.0670
DEBUG - 2012-04-07 00:32:04 --> Config Class Initialized
DEBUG - 2012-04-07 00:32:04 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:32:04 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:32:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:32:04 --> URI Class Initialized
DEBUG - 2012-04-07 00:32:04 --> Router Class Initialized
DEBUG - 2012-04-07 00:32:04 --> Output Class Initialized
DEBUG - 2012-04-07 00:32:04 --> Security Class Initialized
DEBUG - 2012-04-07 00:32:04 --> Input Class Initialized
DEBUG - 2012-04-07 00:32:04 --> XSS Filtering completed
DEBUG - 2012-04-07 00:32:04 --> XSS Filtering completed
DEBUG - 2012-04-07 00:32:04 --> XSS Filtering completed
DEBUG - 2012-04-07 00:32:04 --> CRSF cookie Set
DEBUG - 2012-04-07 00:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:32:04 --> Language Class Initialized
DEBUG - 2012-04-07 00:32:04 --> Loader Class Initialized
DEBUG - 2012-04-07 00:32:04 --> Controller Class Initialized
DEBUG - 2012-04-07 00:32:04 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:32:04 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:32:04 --> Session Class Initialized
DEBUG - 2012-04-07 00:32:04 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:32:04 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:32:04 --> Session routines successfully run
DEBUG - 2012-04-07 00:32:04 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:32:04 --> Pages view: registrook
DEBUG - 2012-04-07 00:32:04 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:32:04 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:32:04 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:32:04 --> Final output sent to browser
DEBUG - 2012-04-07 00:32:04 --> Total execution time: 0.0147
DEBUG - 2012-04-07 00:32:58 --> Config Class Initialized
DEBUG - 2012-04-07 00:32:58 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:32:58 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:32:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:32:58 --> URI Class Initialized
DEBUG - 2012-04-07 00:32:58 --> Router Class Initialized
DEBUG - 2012-04-07 00:32:58 --> Output Class Initialized
DEBUG - 2012-04-07 00:32:58 --> Security Class Initialized
DEBUG - 2012-04-07 00:32:58 --> Input Class Initialized
DEBUG - 2012-04-07 00:32:58 --> XSS Filtering completed
DEBUG - 2012-04-07 00:32:58 --> XSS Filtering completed
DEBUG - 2012-04-07 00:32:58 --> XSS Filtering completed
DEBUG - 2012-04-07 00:32:58 --> CRSF cookie Set
DEBUG - 2012-04-07 00:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:32:58 --> Language Class Initialized
DEBUG - 2012-04-07 00:32:58 --> Loader Class Initialized
DEBUG - 2012-04-07 00:32:58 --> Controller Class Initialized
DEBUG - 2012-04-07 00:32:58 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:32:58 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:32:58 --> Session Class Initialized
DEBUG - 2012-04-07 00:32:58 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:32:58 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:32:58 --> Session routines successfully run
DEBUG - 2012-04-07 00:32:58 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:32:58 --> Pages view: registrook
DEBUG - 2012-04-07 00:32:58 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:32:58 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 00:32:58 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:32:58 --> Final output sent to browser
DEBUG - 2012-04-07 00:32:58 --> Total execution time: 0.0143
DEBUG - 2012-04-07 00:33:11 --> Config Class Initialized
DEBUG - 2012-04-07 00:33:11 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:33:11 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:33:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:33:11 --> URI Class Initialized
DEBUG - 2012-04-07 00:33:11 --> Router Class Initialized
DEBUG - 2012-04-07 00:33:11 --> Output Class Initialized
DEBUG - 2012-04-07 00:33:11 --> Security Class Initialized
DEBUG - 2012-04-07 00:33:11 --> Input Class Initialized
DEBUG - 2012-04-07 00:33:11 --> XSS Filtering completed
DEBUG - 2012-04-07 00:33:11 --> XSS Filtering completed
DEBUG - 2012-04-07 00:33:11 --> XSS Filtering completed
DEBUG - 2012-04-07 00:33:11 --> CRSF cookie Set
DEBUG - 2012-04-07 00:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:33:11 --> Language Class Initialized
DEBUG - 2012-04-07 00:33:11 --> Loader Class Initialized
DEBUG - 2012-04-07 00:33:11 --> Controller Class Initialized
DEBUG - 2012-04-07 00:33:11 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:33:11 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:33:11 --> Session Class Initialized
DEBUG - 2012-04-07 00:33:11 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:33:11 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:33:11 --> Session routines successfully run
DEBUG - 2012-04-07 00:33:11 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:33:11 --> Pages view: mainmenu
DEBUG - 2012-04-07 00:33:11 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 00:33:11 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-07 00:33:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:33:11 --> Final output sent to browser
DEBUG - 2012-04-07 00:33:11 --> Total execution time: 0.0157
DEBUG - 2012-04-07 00:33:30 --> Config Class Initialized
DEBUG - 2012-04-07 00:33:30 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:33:30 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:33:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:33:30 --> URI Class Initialized
DEBUG - 2012-04-07 00:33:30 --> Router Class Initialized
DEBUG - 2012-04-07 00:33:30 --> No URI present. Default controller set.
DEBUG - 2012-04-07 00:33:30 --> Output Class Initialized
DEBUG - 2012-04-07 00:33:30 --> Security Class Initialized
DEBUG - 2012-04-07 00:33:30 --> Input Class Initialized
DEBUG - 2012-04-07 00:33:30 --> XSS Filtering completed
DEBUG - 2012-04-07 00:33:30 --> XSS Filtering completed
DEBUG - 2012-04-07 00:33:30 --> XSS Filtering completed
DEBUG - 2012-04-07 00:33:30 --> CRSF cookie Set
DEBUG - 2012-04-07 00:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:33:30 --> Language Class Initialized
DEBUG - 2012-04-07 00:33:30 --> Loader Class Initialized
DEBUG - 2012-04-07 00:33:30 --> Controller Class Initialized
DEBUG - 2012-04-07 00:33:30 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:33:30 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:33:30 --> Session Class Initialized
DEBUG - 2012-04-07 00:33:30 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:33:30 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:33:30 --> Session routines successfully run
DEBUG - 2012-04-07 00:33:30 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:33:30 --> Pages view: home
DEBUG - 2012-04-07 00:33:30 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:33:30 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 00:33:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:33:30 --> Final output sent to browser
DEBUG - 2012-04-07 00:33:30 --> Total execution time: 0.0116
DEBUG - 2012-04-07 00:41:00 --> Config Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:41:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:41:00 --> URI Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Router Class Initialized
DEBUG - 2012-04-07 00:41:00 --> No URI present. Default controller set.
DEBUG - 2012-04-07 00:41:00 --> Output Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Security Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Input Class Initialized
DEBUG - 2012-04-07 00:41:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:41:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:41:00 --> XSS Filtering completed
DEBUG - 2012-04-07 00:41:00 --> CRSF cookie Set
DEBUG - 2012-04-07 00:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:41:00 --> Language Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Loader Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Controller Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:41:00 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:41:00 --> Session Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:41:00 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Session routines successfully run
DEBUG - 2012-04-07 00:41:00 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:41:00 --> Pages view: home
DEBUG - 2012-04-07 00:41:00 --> Model Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Model Class Initialized
DEBUG - 2012-04-07 00:41:00 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:41:00 --> File loaded: application/views/templates/headerhome.php
ERROR - 2012-04-07 00:41:00 --> Severity: Notice  --> Undefined index: total_er /usr/local/zend/apache2/htdocs/ermex/ermx/application/views/pages/home.php 41
DEBUG - 2012-04-07 00:41:00 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 00:41:00 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:41:00 --> Final output sent to browser
DEBUG - 2012-04-07 00:41:00 --> Total execution time: 0.0198
DEBUG - 2012-04-07 00:42:10 --> Config Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:42:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:42:10 --> URI Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Router Class Initialized
DEBUG - 2012-04-07 00:42:10 --> No URI present. Default controller set.
DEBUG - 2012-04-07 00:42:10 --> Output Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Security Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Input Class Initialized
DEBUG - 2012-04-07 00:42:10 --> XSS Filtering completed
DEBUG - 2012-04-07 00:42:10 --> XSS Filtering completed
DEBUG - 2012-04-07 00:42:10 --> XSS Filtering completed
DEBUG - 2012-04-07 00:42:10 --> CRSF cookie Set
DEBUG - 2012-04-07 00:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:42:10 --> Language Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Loader Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Controller Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:42:10 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:42:10 --> Session Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:42:10 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Session routines successfully run
DEBUG - 2012-04-07 00:42:10 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:42:10 --> Pages view: home
DEBUG - 2012-04-07 00:42:10 --> Model Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Model Class Initialized
DEBUG - 2012-04-07 00:42:10 --> Database Driver Class Initialized
ERROR - 2012-04-07 00:42:10 --> Severity: Notice  --> Undefined index: total_er /usr/local/zend/apache2/htdocs/ermex/ermx/application/controllers/pages.php 25
ERROR - 2012-04-07 00:42:10 --> Severity: Notice  --> Undefined index: total_usr /usr/local/zend/apache2/htdocs/ermex/ermx/application/controllers/pages.php 26
DEBUG - 2012-04-07 00:42:10 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:42:10 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 00:42:10 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:42:10 --> Final output sent to browser
DEBUG - 2012-04-07 00:42:10 --> Total execution time: 0.0145
DEBUG - 2012-04-07 00:43:56 --> Config Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:43:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:43:56 --> URI Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Router Class Initialized
DEBUG - 2012-04-07 00:43:56 --> No URI present. Default controller set.
DEBUG - 2012-04-07 00:43:56 --> Output Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Security Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Input Class Initialized
DEBUG - 2012-04-07 00:43:56 --> XSS Filtering completed
DEBUG - 2012-04-07 00:43:56 --> XSS Filtering completed
DEBUG - 2012-04-07 00:43:56 --> XSS Filtering completed
DEBUG - 2012-04-07 00:43:56 --> CRSF cookie Set
DEBUG - 2012-04-07 00:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:43:56 --> Language Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Loader Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Controller Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Model Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Model Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:43:56 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:43:56 --> Session Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:43:56 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:43:56 --> Session routines successfully run
DEBUG - 2012-04-07 00:43:56 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:43:56 --> Pages view: home
DEBUG - 2012-04-07 00:43:56 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:43:56 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 00:43:56 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:43:56 --> Final output sent to browser
DEBUG - 2012-04-07 00:43:56 --> Total execution time: 0.0150
DEBUG - 2012-04-07 00:44:16 --> Config Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:44:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:44:16 --> URI Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Router Class Initialized
DEBUG - 2012-04-07 00:44:16 --> No URI present. Default controller set.
DEBUG - 2012-04-07 00:44:16 --> Output Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Security Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Input Class Initialized
DEBUG - 2012-04-07 00:44:16 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:16 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:16 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:16 --> CRSF cookie Set
DEBUG - 2012-04-07 00:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:44:16 --> Language Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Loader Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Controller Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Model Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Model Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:44:16 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:44:16 --> Session Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:44:16 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:44:16 --> Session routines successfully run
DEBUG - 2012-04-07 00:44:16 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:44:16 --> Pages view: home
DEBUG - 2012-04-07 00:44:16 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:44:16 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 00:44:16 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:44:16 --> Final output sent to browser
DEBUG - 2012-04-07 00:44:16 --> Total execution time: 0.0184
DEBUG - 2012-04-07 00:44:25 --> Config Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:44:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:44:25 --> URI Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Router Class Initialized
DEBUG - 2012-04-07 00:44:25 --> No URI present. Default controller set.
DEBUG - 2012-04-07 00:44:25 --> Output Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Security Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Input Class Initialized
DEBUG - 2012-04-07 00:44:25 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:25 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:25 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:25 --> CRSF cookie Set
DEBUG - 2012-04-07 00:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:44:25 --> Language Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Loader Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Controller Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Model Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Model Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:44:25 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:44:25 --> Session Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:44:25 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:44:25 --> Session routines successfully run
DEBUG - 2012-04-07 00:44:25 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:44:25 --> Pages view: home
DEBUG - 2012-04-07 00:44:25 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:44:25 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 00:44:25 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:44:25 --> Final output sent to browser
DEBUG - 2012-04-07 00:44:25 --> Total execution time: 0.0177
DEBUG - 2012-04-07 00:44:53 --> Config Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:44:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:44:53 --> URI Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Router Class Initialized
DEBUG - 2012-04-07 00:44:53 --> No URI present. Default controller set.
DEBUG - 2012-04-07 00:44:53 --> Output Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Security Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Input Class Initialized
DEBUG - 2012-04-07 00:44:53 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:53 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:53 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:53 --> CRSF cookie Set
DEBUG - 2012-04-07 00:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:44:53 --> Language Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Loader Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Controller Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Model Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Model Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:44:53 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:44:53 --> Session Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:44:53 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:44:53 --> Session routines successfully run
DEBUG - 2012-04-07 00:44:53 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:44:53 --> Pages view: home
DEBUG - 2012-04-07 00:44:53 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:44:53 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 00:44:53 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:44:53 --> Final output sent to browser
DEBUG - 2012-04-07 00:44:53 --> Total execution time: 0.0153
DEBUG - 2012-04-07 00:44:59 --> Config Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:44:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:44:59 --> URI Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Router Class Initialized
DEBUG - 2012-04-07 00:44:59 --> No URI present. Default controller set.
DEBUG - 2012-04-07 00:44:59 --> Output Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Security Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Input Class Initialized
DEBUG - 2012-04-07 00:44:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:59 --> XSS Filtering completed
DEBUG - 2012-04-07 00:44:59 --> CRSF cookie Set
DEBUG - 2012-04-07 00:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:44:59 --> Language Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Loader Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Controller Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Model Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Model Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:44:59 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:44:59 --> Session Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:44:59 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:44:59 --> Session routines successfully run
DEBUG - 2012-04-07 00:44:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:44:59 --> Pages view: home
DEBUG - 2012-04-07 00:44:59 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:44:59 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 00:44:59 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:44:59 --> Final output sent to browser
DEBUG - 2012-04-07 00:44:59 --> Total execution time: 0.0152
DEBUG - 2012-04-07 00:45:24 --> Config Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:45:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:45:24 --> URI Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Router Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Output Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Security Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Input Class Initialized
DEBUG - 2012-04-07 00:45:24 --> XSS Filtering completed
DEBUG - 2012-04-07 00:45:24 --> XSS Filtering completed
DEBUG - 2012-04-07 00:45:24 --> XSS Filtering completed
DEBUG - 2012-04-07 00:45:24 --> CRSF cookie Set
DEBUG - 2012-04-07 00:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:45:24 --> Language Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Loader Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Controller Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Model Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Model Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:45:24 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:45:24 --> Session Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:45:24 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:45:24 --> Session routines successfully run
DEBUG - 2012-04-07 00:45:24 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:45:24 --> Pages view: logoff
DEBUG - 2012-04-07 00:45:24 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:45:24 --> File loaded: application/views/pages/logoff.php
DEBUG - 2012-04-07 00:45:24 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:45:24 --> Final output sent to browser
DEBUG - 2012-04-07 00:45:24 --> Total execution time: 0.0126
DEBUG - 2012-04-07 00:45:26 --> Config Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:45:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:45:26 --> URI Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Router Class Initialized
DEBUG - 2012-04-07 00:45:26 --> No URI present. Default controller set.
DEBUG - 2012-04-07 00:45:26 --> Output Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Security Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Input Class Initialized
DEBUG - 2012-04-07 00:45:26 --> XSS Filtering completed
DEBUG - 2012-04-07 00:45:26 --> XSS Filtering completed
DEBUG - 2012-04-07 00:45:26 --> CRSF cookie Set
DEBUG - 2012-04-07 00:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:45:26 --> Language Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Loader Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Controller Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Model Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Model Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:45:26 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:45:26 --> Session Class Initialized
DEBUG - 2012-04-07 00:45:26 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:45:26 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:45:26 --> A session cookie was not found.
DEBUG - 2012-04-07 00:45:26 --> Session routines successfully run
DEBUG - 2012-04-07 00:45:26 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:45:26 --> Pages view: home
DEBUG - 2012-04-07 00:45:26 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:45:26 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 00:45:26 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:45:26 --> Final output sent to browser
DEBUG - 2012-04-07 00:45:26 --> Total execution time: 0.0119
DEBUG - 2012-04-07 00:45:32 --> Config Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:45:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:45:32 --> URI Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Router Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Output Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Security Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Input Class Initialized
DEBUG - 2012-04-07 00:45:32 --> XSS Filtering completed
DEBUG - 2012-04-07 00:45:32 --> XSS Filtering completed
DEBUG - 2012-04-07 00:45:32 --> XSS Filtering completed
DEBUG - 2012-04-07 00:45:32 --> CRSF cookie Set
DEBUG - 2012-04-07 00:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:45:32 --> Language Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Loader Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Controller Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Model Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Model Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:45:32 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:45:32 --> Session Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:45:32 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:45:32 --> Session routines successfully run
DEBUG - 2012-04-07 00:45:32 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:45:32 --> Pages view: recpass
ERROR - 2012-04-07 00:45:32 --> 404 Page Not Found --> 
DEBUG - 2012-04-07 00:48:05 --> Config Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:48:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:48:05 --> URI Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Router Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Output Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Security Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Input Class Initialized
DEBUG - 2012-04-07 00:48:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:05 --> CRSF cookie Set
DEBUG - 2012-04-07 00:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:48:05 --> Language Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Loader Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Controller Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:48:05 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:48:05 --> Session Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:48:05 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Session routines successfully run
DEBUG - 2012-04-07 00:48:05 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:48:05 --> Pages view: recpass
DEBUG - 2012-04-07 00:48:05 --> *No se encontró sesión
DEBUG - 2012-04-07 00:48:05 --> Config Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:48:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:48:05 --> URI Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Router Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Output Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Security Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Input Class Initialized
DEBUG - 2012-04-07 00:48:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:05 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:05 --> CRSF cookie Set
DEBUG - 2012-04-07 00:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:48:05 --> Language Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Loader Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Controller Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:48:05 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:48:05 --> Session Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:48:05 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:48:05 --> Session routines successfully run
DEBUG - 2012-04-07 00:48:05 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:48:05 --> Pages view: loginerror
DEBUG - 2012-04-07 00:48:05 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:48:05 --> File loaded: application/views/pages/loginerror.php
DEBUG - 2012-04-07 00:48:05 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:48:05 --> Final output sent to browser
DEBUG - 2012-04-07 00:48:05 --> Total execution time: 0.0097
DEBUG - 2012-04-07 00:48:28 --> Config Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:48:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:48:28 --> URI Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Router Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Output Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Security Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Input Class Initialized
DEBUG - 2012-04-07 00:48:28 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:28 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:28 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:28 --> CRSF cookie Set
DEBUG - 2012-04-07 00:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:48:28 --> Language Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Loader Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Controller Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:48:28 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:48:28 --> Session Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:48:28 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:48:28 --> Session routines successfully run
DEBUG - 2012-04-07 00:48:28 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:48:28 --> Pages view: loginerror
DEBUG - 2012-04-07 00:48:28 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:48:28 --> File loaded: application/views/pages/loginerror.php
DEBUG - 2012-04-07 00:48:28 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:48:28 --> Final output sent to browser
DEBUG - 2012-04-07 00:48:28 --> Total execution time: 0.0168
DEBUG - 2012-04-07 00:48:31 --> Config Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:48:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:48:31 --> URI Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Router Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Output Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Security Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Input Class Initialized
DEBUG - 2012-04-07 00:48:31 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:31 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:31 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:31 --> CRSF cookie Set
DEBUG - 2012-04-07 00:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:48:31 --> Language Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Loader Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Controller Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:48:31 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:48:31 --> Session Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:48:31 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:48:31 --> Session routines successfully run
DEBUG - 2012-04-07 00:48:31 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:48:31 --> Pages view: recpass
DEBUG - 2012-04-07 00:48:31 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:48:31 --> File loaded: application/views/pages/recpass.php
DEBUG - 2012-04-07 00:48:31 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:48:31 --> Final output sent to browser
DEBUG - 2012-04-07 00:48:31 --> Total execution time: 0.0135
DEBUG - 2012-04-07 00:48:41 --> Config Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:48:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:48:41 --> URI Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Router Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Output Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Security Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Input Class Initialized
DEBUG - 2012-04-07 00:48:41 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:41 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:41 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:41 --> CRSF cookie Set
DEBUG - 2012-04-07 00:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:48:41 --> Language Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Loader Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Controller Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:48:41 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:48:41 --> Session Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:48:41 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:48:41 --> Session routines successfully run
DEBUG - 2012-04-07 00:48:41 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:48:41 --> Pages view: recpass
DEBUG - 2012-04-07 00:48:41 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:48:41 --> File loaded: application/views/pages/recpass.php
DEBUG - 2012-04-07 00:48:41 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:48:41 --> Final output sent to browser
DEBUG - 2012-04-07 00:48:41 --> Total execution time: 0.0177
DEBUG - 2012-04-07 00:48:54 --> Config Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:48:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:48:54 --> URI Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Router Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Output Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Security Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Input Class Initialized
DEBUG - 2012-04-07 00:48:54 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:54 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:54 --> XSS Filtering completed
DEBUG - 2012-04-07 00:48:54 --> CRSF cookie Set
DEBUG - 2012-04-07 00:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:48:54 --> Language Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Loader Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Controller Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Model Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:48:54 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:48:54 --> Session Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:48:54 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:48:54 --> Session routines successfully run
DEBUG - 2012-04-07 00:48:54 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:48:54 --> Pages view: recpass
DEBUG - 2012-04-07 00:48:54 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:48:54 --> File loaded: application/views/pages/recpass.php
DEBUG - 2012-04-07 00:48:54 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:48:54 --> Final output sent to browser
DEBUG - 2012-04-07 00:48:54 --> Total execution time: 0.0182
DEBUG - 2012-04-07 00:58:52 --> Config Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:58:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:58:52 --> URI Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Router Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Output Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Security Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Input Class Initialized
DEBUG - 2012-04-07 00:58:52 --> XSS Filtering completed
DEBUG - 2012-04-07 00:58:52 --> XSS Filtering completed
DEBUG - 2012-04-07 00:58:52 --> XSS Filtering completed
DEBUG - 2012-04-07 00:58:52 --> CRSF cookie Set
DEBUG - 2012-04-07 00:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:58:52 --> Language Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Loader Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Controller Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Model Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Model Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:58:52 --> Helper loaded: form_helper
DEBUG - 2012-04-07 00:58:52 --> Session Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:58:52 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:58:52 --> Session routines successfully run
DEBUG - 2012-04-07 00:58:52 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:58:52 --> Pages view: recpass
DEBUG - 2012-04-07 00:58:52 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 00:58:52 --> File loaded: application/views/pages/recpass.php
DEBUG - 2012-04-07 00:58:52 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 00:58:52 --> Final output sent to browser
DEBUG - 2012-04-07 00:58:52 --> Total execution time: 0.0141
DEBUG - 2012-04-07 00:59:04 --> Config Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Hooks Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Utf8 Class Initialized
DEBUG - 2012-04-07 00:59:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 00:59:04 --> URI Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Router Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Output Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Security Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Input Class Initialized
DEBUG - 2012-04-07 00:59:04 --> XSS Filtering completed
DEBUG - 2012-04-07 00:59:04 --> XSS Filtering completed
DEBUG - 2012-04-07 00:59:04 --> XSS Filtering completed
DEBUG - 2012-04-07 00:59:04 --> XSS Filtering completed
DEBUG - 2012-04-07 00:59:04 --> XSS Filtering completed
DEBUG - 2012-04-07 00:59:04 --> XSS Filtering completed
DEBUG - 2012-04-07 00:59:04 --> CRSF cookie Set
DEBUG - 2012-04-07 00:59:04 --> CSRF token verified 
DEBUG - 2012-04-07 00:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 00:59:04 --> Language Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Loader Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Controller Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Model Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Model Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Database Driver Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Session Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Helper loaded: string_helper
DEBUG - 2012-04-07 00:59:04 --> Encrypt Class Initialized
DEBUG - 2012-04-07 00:59:04 --> Session routines successfully run
DEBUG - 2012-04-07 00:59:04 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 00:59:04 --> Helper loaded: url_helper
DEBUG - 2012-04-07 00:59:04 --> App_model/userExist
DEBUG - 2012-04-07 00:59:04 --> Email not registered
DEBUG - 2012-04-07 01:00:09 --> Config Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:00:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:00:09 --> URI Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Router Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Output Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Security Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Input Class Initialized
DEBUG - 2012-04-07 01:00:09 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:09 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:09 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:09 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:09 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:09 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:09 --> CRSF cookie Set
DEBUG - 2012-04-07 01:00:09 --> CSRF token verified 
DEBUG - 2012-04-07 01:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:00:09 --> Language Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Loader Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Controller Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Model Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Model Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Session Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:00:09 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:00:09 --> Session routines successfully run
DEBUG - 2012-04-07 01:00:09 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:00:09 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:00:09 --> App_model/userExist
DEBUG - 2012-04-07 01:00:09 --> Email not registered
DEBUG - 2012-04-07 01:00:09 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 01:00:12 --> Config Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:00:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:00:12 --> URI Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Router Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Output Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Security Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Input Class Initialized
DEBUG - 2012-04-07 01:00:12 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:12 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:12 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:12 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:12 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:12 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:12 --> CRSF cookie Set
DEBUG - 2012-04-07 01:00:12 --> CSRF token verified 
DEBUG - 2012-04-07 01:00:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:00:12 --> Language Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Loader Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Controller Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Model Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Model Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Session Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:00:12 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:00:12 --> Session routines successfully run
DEBUG - 2012-04-07 01:00:12 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:00:12 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:00:12 --> App_model/userExist
DEBUG - 2012-04-07 01:00:12 --> Email not registered
DEBUG - 2012-04-07 01:00:12 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 01:00:58 --> Config Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:00:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:00:58 --> URI Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Router Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Output Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Security Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Input Class Initialized
DEBUG - 2012-04-07 01:00:58 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:58 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:58 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:58 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:58 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:58 --> XSS Filtering completed
DEBUG - 2012-04-07 01:00:58 --> CRSF cookie Set
DEBUG - 2012-04-07 01:00:58 --> CSRF token verified 
DEBUG - 2012-04-07 01:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:00:58 --> Language Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Loader Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Controller Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Model Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Model Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Session Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:00:58 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:00:58 --> Session routines successfully run
DEBUG - 2012-04-07 01:00:58 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:00:58 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:00:58 --> App_model/userExist
DEBUG - 2012-04-07 01:00:58 --> Email not registered
DEBUG - 2012-04-07 01:00:58 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 01:01:35 --> Config Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:01:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:01:35 --> URI Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Router Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Output Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Security Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Input Class Initialized
DEBUG - 2012-04-07 01:01:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:01:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:01:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:01:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:01:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:01:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:01:35 --> CRSF cookie Set
DEBUG - 2012-04-07 01:01:35 --> CSRF token verified 
DEBUG - 2012-04-07 01:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:01:35 --> Language Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Loader Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Controller Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Model Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Model Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Session Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:01:35 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:01:35 --> Session routines successfully run
DEBUG - 2012-04-07 01:01:35 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:01:35 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:01:35 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:01:35 --> App_model/userExist
DEBUG - 2012-04-07 01:01:35 --> Email not registered
DEBUG - 2012-04-07 01:01:35 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 01:01:35 --> File loaded: application/views/pages/recpass.php
DEBUG - 2012-04-07 01:01:35 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:01:35 --> Final output sent to browser
DEBUG - 2012-04-07 01:01:35 --> Total execution time: 0.0181
DEBUG - 2012-04-07 01:02:07 --> Config Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:02:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:02:07 --> URI Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Router Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Output Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Security Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Input Class Initialized
DEBUG - 2012-04-07 01:02:07 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:07 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:07 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:07 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:07 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:07 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:07 --> CRSF cookie Set
DEBUG - 2012-04-07 01:02:07 --> CSRF token verified 
DEBUG - 2012-04-07 01:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:02:07 --> Language Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Loader Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Controller Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Model Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Model Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Session Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:02:07 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:02:07 --> Session routines successfully run
DEBUG - 2012-04-07 01:02:07 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:02:07 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:02:07 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:02:07 --> App_model/userExist
DEBUG - 2012-04-07 01:02:07 --> Email already used
DEBUG - 2012-04-07 01:02:08 --> DB Transaction Failure
ERROR - 2012-04-07 01:02:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@Mail.com' at line 1
DEBUG - 2012-04-07 01:02:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-07 01:02:34 --> Config Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:02:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:02:34 --> URI Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Router Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Output Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Security Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Input Class Initialized
DEBUG - 2012-04-07 01:02:34 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:34 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:34 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:34 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:34 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:34 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:34 --> CRSF cookie Set
DEBUG - 2012-04-07 01:02:34 --> CSRF token verified 
DEBUG - 2012-04-07 01:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:02:34 --> Language Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Loader Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Controller Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Model Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Model Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Session Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:02:34 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:02:34 --> Session routines successfully run
DEBUG - 2012-04-07 01:02:34 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:02:34 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:02:34 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:02:34 --> App_model/userExist
DEBUG - 2012-04-07 01:02:34 --> Email already used
DEBUG - 2012-04-07 01:02:34 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 01:02:34 --> File loaded: application/views/pages/recpass.php
DEBUG - 2012-04-07 01:02:34 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:02:34 --> Final output sent to browser
DEBUG - 2012-04-07 01:02:34 --> Total execution time: 0.0584
DEBUG - 2012-04-07 01:02:54 --> Config Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:02:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:02:54 --> URI Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Router Class Initialized
DEBUG - 2012-04-07 01:02:54 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:02:54 --> Output Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Security Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Input Class Initialized
DEBUG - 2012-04-07 01:02:54 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:54 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:54 --> XSS Filtering completed
DEBUG - 2012-04-07 01:02:54 --> CRSF cookie Set
DEBUG - 2012-04-07 01:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:02:54 --> Language Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Loader Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Controller Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Model Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Model Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:02:54 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:02:54 --> Session Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:02:54 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:02:54 --> Session routines successfully run
DEBUG - 2012-04-07 01:02:54 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:02:54 --> Pages view: home
DEBUG - 2012-04-07 01:02:54 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:02:54 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:02:54 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:02:54 --> Final output sent to browser
DEBUG - 2012-04-07 01:02:54 --> Total execution time: 0.0122
DEBUG - 2012-04-07 01:06:45 --> Config Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:06:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:06:45 --> URI Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Router Class Initialized
DEBUG - 2012-04-07 01:06:45 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:06:45 --> Output Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Security Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Input Class Initialized
DEBUG - 2012-04-07 01:06:45 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:45 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:45 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:45 --> CRSF cookie Set
DEBUG - 2012-04-07 01:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:06:45 --> Language Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Loader Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Controller Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Model Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Model Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:06:45 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:06:45 --> Session Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:06:45 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:06:45 --> Session routines successfully run
DEBUG - 2012-04-07 01:06:45 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:06:45 --> Pages view: home
DEBUG - 2012-04-07 01:06:45 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:06:45 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:06:45 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:06:45 --> Final output sent to browser
DEBUG - 2012-04-07 01:06:45 --> Total execution time: 0.0146
DEBUG - 2012-04-07 01:06:56 --> Config Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:06:56 --> URI Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Router Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Output Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Security Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Input Class Initialized
DEBUG - 2012-04-07 01:06:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:56 --> CRSF cookie Set
DEBUG - 2012-04-07 01:06:56 --> CSRF token verified 
DEBUG - 2012-04-07 01:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:06:56 --> Language Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Loader Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Controller Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Model Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Model Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Session Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:06:56 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Session routines successfully run
DEBUG - 2012-04-07 01:06:56 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:06:56 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:06:56 --> *Security/login
DEBUG - 2012-04-07 01:06:56 --> App_model login
DEBUG - 2012-04-07 01:06:56 --> **Found user**
DEBUG - 2012-04-07 01:06:56 --> Config Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:06:56 --> URI Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Router Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Output Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Security Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Input Class Initialized
DEBUG - 2012-04-07 01:06:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:06:56 --> CRSF cookie Set
DEBUG - 2012-04-07 01:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:06:56 --> Language Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Loader Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Controller Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Model Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Model Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:06:56 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:06:56 --> Session Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:06:56 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:06:56 --> Session routines successfully run
DEBUG - 2012-04-07 01:06:56 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:06:56 --> Pages view: mainmenu
DEBUG - 2012-04-07 01:06:56 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 01:06:56 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-07 01:06:56 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:06:56 --> Final output sent to browser
DEBUG - 2012-04-07 01:06:56 --> Total execution time: 0.0115
DEBUG - 2012-04-07 01:20:10 --> Config Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:20:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:20:10 --> URI Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Router Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Output Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Security Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Input Class Initialized
DEBUG - 2012-04-07 01:20:10 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:10 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:10 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:10 --> CRSF cookie Set
DEBUG - 2012-04-07 01:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:20:10 --> Language Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Loader Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Controller Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Model Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Model Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:20:10 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:20:10 --> Session Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:20:10 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:20:10 --> Session routines successfully run
DEBUG - 2012-04-07 01:20:10 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:20:10 --> Pages view: nuevacuenta
DEBUG - 2012-04-07 01:20:10 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:20:10 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-07 01:20:10 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:20:10 --> Final output sent to browser
DEBUG - 2012-04-07 01:20:10 --> Total execution time: 0.0159
DEBUG - 2012-04-07 01:20:15 --> Config Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:20:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:20:15 --> URI Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Router Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Output Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Security Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Input Class Initialized
DEBUG - 2012-04-07 01:20:15 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:15 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:15 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:15 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:15 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:15 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:15 --> CRSF cookie Set
DEBUG - 2012-04-07 01:20:15 --> CSRF token verified 
DEBUG - 2012-04-07 01:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:20:15 --> Language Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Loader Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Controller Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Model Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Model Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Session Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:20:15 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Session routines successfully run
DEBUG - 2012-04-07 01:20:15 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:20:15 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:20:15 --> *Security/login
DEBUG - 2012-04-07 01:20:15 --> App_model login
DEBUG - 2012-04-07 01:20:15 --> Config Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:20:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:20:15 --> URI Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Router Class Initialized
DEBUG - 2012-04-07 01:20:15 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:20:15 --> Output Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Security Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Input Class Initialized
DEBUG - 2012-04-07 01:20:15 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:15 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:15 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:15 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:15 --> CRSF cookie Set
DEBUG - 2012-04-07 01:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:20:15 --> Language Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Loader Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Controller Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Model Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Model Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:20:15 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:20:15 --> Session Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:20:15 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:20:15 --> Session routines successfully run
DEBUG - 2012-04-07 01:20:15 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:20:15 --> Pages view: home
DEBUG - 2012-04-07 01:20:15 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:20:15 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:20:15 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:20:15 --> Final output sent to browser
DEBUG - 2012-04-07 01:20:15 --> Total execution time: 0.0119
DEBUG - 2012-04-07 01:20:26 --> Config Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:20:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:20:26 --> URI Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Router Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Output Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Security Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Input Class Initialized
DEBUG - 2012-04-07 01:20:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:20:26 --> CRSF cookie Set
DEBUG - 2012-04-07 01:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:20:26 --> Language Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Loader Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Controller Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Model Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Model Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:20:26 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:20:26 --> Session Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:20:26 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:20:26 --> Session routines successfully run
DEBUG - 2012-04-07 01:20:26 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:20:26 --> Pages view: index.php
ERROR - 2012-04-07 01:20:26 --> 404 Page Not Found --> 
DEBUG - 2012-04-07 01:21:26 --> Config Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:21:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:21:26 --> URI Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Router Class Initialized
DEBUG - 2012-04-07 01:21:26 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:21:26 --> Output Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Security Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Input Class Initialized
DEBUG - 2012-04-07 01:21:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:26 --> CRSF cookie Set
DEBUG - 2012-04-07 01:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:21:26 --> Language Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Loader Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Controller Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Model Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Model Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:21:26 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:21:26 --> Session Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:21:26 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:21:26 --> Session routines successfully run
DEBUG - 2012-04-07 01:21:26 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:21:26 --> Pages view: home
DEBUG - 2012-04-07 01:21:26 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:21:26 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:21:26 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:21:26 --> Final output sent to browser
DEBUG - 2012-04-07 01:21:26 --> Total execution time: 0.0130
DEBUG - 2012-04-07 01:21:35 --> Config Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:21:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:21:35 --> URI Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Router Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Output Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Security Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Input Class Initialized
DEBUG - 2012-04-07 01:21:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:35 --> CRSF cookie Set
DEBUG - 2012-04-07 01:21:35 --> CSRF token verified 
DEBUG - 2012-04-07 01:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:21:35 --> Language Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Loader Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Controller Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Model Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Model Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Session Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:21:35 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Session routines successfully run
DEBUG - 2012-04-07 01:21:35 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:21:35 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:21:35 --> *Security/login
DEBUG - 2012-04-07 01:21:35 --> App_model login
DEBUG - 2012-04-07 01:21:35 --> Config Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:21:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:21:35 --> URI Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Router Class Initialized
DEBUG - 2012-04-07 01:21:35 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:21:35 --> Output Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Security Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Input Class Initialized
DEBUG - 2012-04-07 01:21:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:35 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:35 --> CRSF cookie Set
DEBUG - 2012-04-07 01:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:21:35 --> Language Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Loader Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Controller Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Model Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Model Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:21:35 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:21:35 --> Session Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:21:35 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:21:35 --> Session routines successfully run
DEBUG - 2012-04-07 01:21:35 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:21:35 --> Pages view: home
DEBUG - 2012-04-07 01:21:35 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:21:35 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:21:35 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:21:35 --> Final output sent to browser
DEBUG - 2012-04-07 01:21:35 --> Total execution time: 0.0115
DEBUG - 2012-04-07 01:21:38 --> Config Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:21:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:21:38 --> URI Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Router Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Output Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Security Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Input Class Initialized
DEBUG - 2012-04-07 01:21:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:21:38 --> CRSF cookie Set
DEBUG - 2012-04-07 01:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:21:38 --> Language Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Loader Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Controller Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Model Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Model Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:21:38 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:21:38 --> Session Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:21:38 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:21:38 --> Session routines successfully run
DEBUG - 2012-04-07 01:21:38 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:21:38 --> Pages view: index.php
ERROR - 2012-04-07 01:21:38 --> 404 Page Not Found --> 
DEBUG - 2012-04-07 01:22:05 --> Config Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:22:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:22:05 --> URI Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Router Class Initialized
DEBUG - 2012-04-07 01:22:05 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:22:05 --> Output Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Security Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Input Class Initialized
DEBUG - 2012-04-07 01:22:05 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:05 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:05 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:05 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:05 --> CRSF cookie Set
DEBUG - 2012-04-07 01:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:22:05 --> Language Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Loader Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Controller Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:22:05 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:22:05 --> Session Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:22:05 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:22:05 --> Session routines successfully run
DEBUG - 2012-04-07 01:22:05 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:22:05 --> Pages view: home
DEBUG - 2012-04-07 01:22:05 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:22:05 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:22:05 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:22:05 --> Final output sent to browser
DEBUG - 2012-04-07 01:22:05 --> Total execution time: 0.0145
DEBUG - 2012-04-07 01:22:07 --> Config Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:22:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:22:07 --> URI Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Router Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Output Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Security Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Input Class Initialized
DEBUG - 2012-04-07 01:22:07 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:07 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:07 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:07 --> CRSF cookie Set
DEBUG - 2012-04-07 01:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:22:07 --> Language Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Loader Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Controller Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:22:07 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:22:07 --> Session Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:22:07 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:22:07 --> Session routines successfully run
DEBUG - 2012-04-07 01:22:07 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:22:07 --> Pages view: nuevacuenta
DEBUG - 2012-04-07 01:22:07 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:22:07 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-07 01:22:07 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:22:07 --> Final output sent to browser
DEBUG - 2012-04-07 01:22:07 --> Total execution time: 0.0121
DEBUG - 2012-04-07 01:22:13 --> Config Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:22:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:22:13 --> URI Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Router Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Output Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Security Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Input Class Initialized
DEBUG - 2012-04-07 01:22:13 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:13 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:13 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:13 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:13 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:13 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:13 --> CRSF cookie Set
DEBUG - 2012-04-07 01:22:13 --> CSRF token verified 
DEBUG - 2012-04-07 01:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:22:13 --> Language Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Loader Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Controller Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Session Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:22:13 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Session routines successfully run
DEBUG - 2012-04-07 01:22:13 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:22:13 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:22:13 --> *Security/login
DEBUG - 2012-04-07 01:22:13 --> App_model login
DEBUG - 2012-04-07 01:22:13 --> Config Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:22:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:22:13 --> URI Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Router Class Initialized
DEBUG - 2012-04-07 01:22:13 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:22:13 --> Output Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Security Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Input Class Initialized
DEBUG - 2012-04-07 01:22:13 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:13 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:13 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:13 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:13 --> CRSF cookie Set
DEBUG - 2012-04-07 01:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:22:13 --> Language Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Loader Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Controller Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:22:13 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:22:13 --> Session Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:22:13 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:22:13 --> Session routines successfully run
DEBUG - 2012-04-07 01:22:13 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:22:13 --> Pages view: home
DEBUG - 2012-04-07 01:22:13 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:22:13 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:22:13 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:22:13 --> Final output sent to browser
DEBUG - 2012-04-07 01:22:13 --> Total execution time: 0.0120
DEBUG - 2012-04-07 01:22:14 --> Config Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:22:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:22:14 --> URI Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Router Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Output Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Security Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Input Class Initialized
DEBUG - 2012-04-07 01:22:14 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:14 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:14 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:14 --> CRSF cookie Set
DEBUG - 2012-04-07 01:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:22:14 --> Language Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Loader Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Controller Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:22:14 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:22:14 --> Session Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:22:14 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:22:14 --> Session routines successfully run
DEBUG - 2012-04-07 01:22:14 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:22:14 --> Pages view: nuevacuenta
DEBUG - 2012-04-07 01:22:14 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:22:14 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-07 01:22:14 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:22:14 --> Final output sent to browser
DEBUG - 2012-04-07 01:22:14 --> Total execution time: 0.0129
DEBUG - 2012-04-07 01:22:28 --> Config Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:22:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:22:28 --> URI Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Router Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Output Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Security Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Input Class Initialized
DEBUG - 2012-04-07 01:22:28 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:28 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:28 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:28 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:28 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:28 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:28 --> XSS Filtering completed
DEBUG - 2012-04-07 01:22:28 --> CRSF cookie Set
DEBUG - 2012-04-07 01:22:28 --> CSRF token verified 
DEBUG - 2012-04-07 01:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:22:28 --> Language Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Loader Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Controller Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Model Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Session Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:22:28 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:22:28 --> Session routines successfully run
DEBUG - 2012-04-07 01:22:28 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:22:28 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:22:28 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:22:28 --> ermex/newaccount
DEBUG - 2012-04-07 01:22:28 --> App_model/userExist
DEBUG - 2012-04-07 01:22:28 --> Email not registered
DEBUG - 2012-04-07 01:22:28 --> App_model/insertUser
ERROR - 2012-04-07 01:22:28 --> Severity: Notice  --> Undefined variable: glob_mensajeExito /usr/local/zend/apache2/htdocs/ermex/ermx/application/controllers/ermex.php 35
DEBUG - 2012-04-07 01:22:28 --> Email Class Initialized
ERROR - 2012-04-07 01:22:28 --> Severity: Notice  --> Use of undefined constant _MAIL_FROM_ADDR_ - assumed '_MAIL_FROM_ADDR_' /usr/local/zend/apache2/htdocs/ermex/ermx/application/controllers/ermex.php 58
ERROR - 2012-04-07 01:22:28 --> Severity: Notice  --> Use of undefined constant _MAIL_FROM_NAME_ - assumed '_MAIL_FROM_NAME_' /usr/local/zend/apache2/htdocs/ermex/ermx/application/controllers/ermex.php 58
DEBUG - 2012-04-07 01:23:29 --> Language file loaded: language/english/email_lang.php
DEBUG - 2012-04-07 01:23:29 --> Email class already loaded. Second attempt ignored.
ERROR - 2012-04-07 01:23:29 --> Severity: Notice  --> Use of undefined constant _MAIL_FROM_ADDR_ - assumed '_MAIL_FROM_ADDR_' /usr/local/zend/apache2/htdocs/ermex/ermx/application/controllers/ermex.php 58
ERROR - 2012-04-07 01:23:29 --> Severity: Notice  --> Use of undefined constant _MAIL_FROM_NAME_ - assumed '_MAIL_FROM_NAME_' /usr/local/zend/apache2/htdocs/ermex/ermx/application/controllers/ermex.php 58
DEBUG - 2012-04-07 01:24:29 --> Config Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:24:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:24:29 --> URI Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Router Class Initialized
DEBUG - 2012-04-07 01:24:29 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:24:29 --> Output Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Security Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Input Class Initialized
DEBUG - 2012-04-07 01:24:29 --> XSS Filtering completed
DEBUG - 2012-04-07 01:24:29 --> XSS Filtering completed
DEBUG - 2012-04-07 01:24:29 --> XSS Filtering completed
DEBUG - 2012-04-07 01:24:29 --> XSS Filtering completed
DEBUG - 2012-04-07 01:24:29 --> CRSF cookie Set
DEBUG - 2012-04-07 01:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:24:29 --> Language Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Loader Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Controller Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Model Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Model Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:24:29 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:24:29 --> Session Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:24:29 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:24:29 --> Session routines successfully run
DEBUG - 2012-04-07 01:24:29 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:24:29 --> Pages view: home
DEBUG - 2012-04-07 01:24:29 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:24:29 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:24:29 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:24:29 --> Final output sent to browser
DEBUG - 2012-04-07 01:24:29 --> Total execution time: 0.0136
DEBUG - 2012-04-07 01:25:28 --> Config Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:25:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:25:28 --> URI Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Router Class Initialized
DEBUG - 2012-04-07 01:25:28 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:25:28 --> Output Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Security Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Input Class Initialized
DEBUG - 2012-04-07 01:25:28 --> XSS Filtering completed
DEBUG - 2012-04-07 01:25:28 --> XSS Filtering completed
DEBUG - 2012-04-07 01:25:28 --> XSS Filtering completed
DEBUG - 2012-04-07 01:25:28 --> XSS Filtering completed
DEBUG - 2012-04-07 01:25:28 --> CRSF cookie Set
DEBUG - 2012-04-07 01:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:25:28 --> Language Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Loader Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Controller Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Model Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Model Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:25:28 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:25:28 --> Session Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:25:28 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:25:28 --> Session routines successfully run
DEBUG - 2012-04-07 01:25:28 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:25:28 --> Pages view: home
DEBUG - 2012-04-07 01:25:28 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:25:28 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:25:28 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:25:28 --> Final output sent to browser
DEBUG - 2012-04-07 01:25:28 --> Total execution time: 0.0153
DEBUG - 2012-04-07 01:28:09 --> Config Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:28:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:28:09 --> URI Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Router Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Output Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Security Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Input Class Initialized
DEBUG - 2012-04-07 01:28:09 --> XSS Filtering completed
DEBUG - 2012-04-07 01:28:09 --> XSS Filtering completed
DEBUG - 2012-04-07 01:28:09 --> XSS Filtering completed
DEBUG - 2012-04-07 01:28:09 --> CRSF cookie Set
DEBUG - 2012-04-07 01:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:28:09 --> Language Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Loader Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Controller Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Model Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Model Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:28:09 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:28:09 --> Session Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:28:09 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:28:09 --> Session routines successfully run
DEBUG - 2012-04-07 01:28:09 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:28:09 --> Pages view: nuevacuenta
DEBUG - 2012-04-07 01:28:09 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:28:09 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-07 01:28:09 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:28:09 --> Final output sent to browser
DEBUG - 2012-04-07 01:28:09 --> Total execution time: 0.0142
DEBUG - 2012-04-07 01:28:19 --> Config Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:28:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:28:19 --> URI Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Router Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Output Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Security Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Input Class Initialized
DEBUG - 2012-04-07 01:28:19 --> XSS Filtering completed
DEBUG - 2012-04-07 01:28:19 --> XSS Filtering completed
DEBUG - 2012-04-07 01:28:19 --> XSS Filtering completed
DEBUG - 2012-04-07 01:28:19 --> XSS Filtering completed
DEBUG - 2012-04-07 01:28:19 --> XSS Filtering completed
DEBUG - 2012-04-07 01:28:19 --> XSS Filtering completed
DEBUG - 2012-04-07 01:28:19 --> XSS Filtering completed
DEBUG - 2012-04-07 01:28:19 --> CRSF cookie Set
DEBUG - 2012-04-07 01:28:19 --> CSRF token verified 
DEBUG - 2012-04-07 01:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:28:19 --> Language Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Loader Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Controller Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Model Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Model Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Session Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:28:19 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:28:19 --> Session routines successfully run
DEBUG - 2012-04-07 01:28:19 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:28:19 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:28:19 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:28:19 --> ermex/newaccount
DEBUG - 2012-04-07 01:28:19 --> App_model/userExist
DEBUG - 2012-04-07 01:28:19 --> Email not registered
DEBUG - 2012-04-07 01:28:19 --> App_model/insertUser
ERROR - 2012-04-07 01:28:19 --> Severity: Notice  --> Undefined variable: glob_mensajeExito /usr/local/zend/apache2/htdocs/ermex/ermx/application/controllers/ermex.php 35
DEBUG - 2012-04-07 01:28:19 --> Email Class Initialized
DEBUG - 2012-04-07 01:29:20 --> Language file loaded: language/english/email_lang.php
DEBUG - 2012-04-07 01:29:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:30:20 --> Config Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:30:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:30:20 --> URI Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Router Class Initialized
DEBUG - 2012-04-07 01:30:20 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:30:20 --> Output Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Security Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Input Class Initialized
DEBUG - 2012-04-07 01:30:20 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:20 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:20 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:20 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:20 --> CRSF cookie Set
DEBUG - 2012-04-07 01:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:30:20 --> Language Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Loader Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Controller Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Model Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Model Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:30:20 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:30:20 --> Session Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:30:20 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:30:20 --> Session routines successfully run
DEBUG - 2012-04-07 01:30:20 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:30:20 --> Pages view: home
DEBUG - 2012-04-07 01:30:20 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:30:20 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:30:20 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:30:20 --> Final output sent to browser
DEBUG - 2012-04-07 01:30:20 --> Total execution time: 0.0125
DEBUG - 2012-04-07 01:30:41 --> Config Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:30:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:30:41 --> URI Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Router Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Output Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Security Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Input Class Initialized
DEBUG - 2012-04-07 01:30:41 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:41 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:41 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:41 --> CRSF cookie Set
DEBUG - 2012-04-07 01:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:30:41 --> Language Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Loader Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Controller Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Model Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Model Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:30:41 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:30:41 --> Session Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:30:41 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:30:41 --> Session routines successfully run
DEBUG - 2012-04-07 01:30:41 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:30:41 --> Pages view: nuevacuenta
DEBUG - 2012-04-07 01:30:41 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:30:41 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-07 01:30:41 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:30:41 --> Final output sent to browser
DEBUG - 2012-04-07 01:30:41 --> Total execution time: 0.0146
DEBUG - 2012-04-07 01:30:49 --> Config Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:30:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:30:49 --> URI Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Router Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Output Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Security Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Input Class Initialized
DEBUG - 2012-04-07 01:30:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:30:49 --> CRSF cookie Set
DEBUG - 2012-04-07 01:30:49 --> CSRF token verified 
DEBUG - 2012-04-07 01:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:30:49 --> Language Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Loader Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Controller Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Model Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Model Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Session Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:30:49 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:30:49 --> Session routines successfully run
DEBUG - 2012-04-07 01:30:49 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:30:49 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:30:49 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:30:49 --> ermex/newaccount
DEBUG - 2012-04-07 01:30:49 --> App_model/userExist
DEBUG - 2012-04-07 01:30:49 --> Email not registered
DEBUG - 2012-04-07 01:30:49 --> App_model/insertUser
DEBUG - 2012-04-07 01:30:49 --> Email Class Initialized
DEBUG - 2012-04-07 01:31:50 --> Language file loaded: language/english/email_lang.php
DEBUG - 2012-04-07 01:31:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:32:50 --> Config Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:32:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:32:50 --> URI Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Router Class Initialized
DEBUG - 2012-04-07 01:32:50 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:32:50 --> Output Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Security Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Input Class Initialized
DEBUG - 2012-04-07 01:32:50 --> XSS Filtering completed
DEBUG - 2012-04-07 01:32:50 --> XSS Filtering completed
DEBUG - 2012-04-07 01:32:50 --> XSS Filtering completed
DEBUG - 2012-04-07 01:32:50 --> XSS Filtering completed
DEBUG - 2012-04-07 01:32:50 --> CRSF cookie Set
DEBUG - 2012-04-07 01:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:32:50 --> Language Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Loader Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Controller Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Model Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Model Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:32:50 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:32:50 --> Session Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:32:50 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:32:50 --> Session routines successfully run
DEBUG - 2012-04-07 01:32:50 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:32:50 --> Pages view: home
DEBUG - 2012-04-07 01:32:50 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:32:50 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:32:50 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:32:50 --> Final output sent to browser
DEBUG - 2012-04-07 01:32:50 --> Total execution time: 0.0117
DEBUG - 2012-04-07 01:35:18 --> Config Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:35:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:35:18 --> URI Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Router Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Output Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Security Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Input Class Initialized
DEBUG - 2012-04-07 01:35:18 --> XSS Filtering completed
DEBUG - 2012-04-07 01:35:18 --> XSS Filtering completed
DEBUG - 2012-04-07 01:35:18 --> XSS Filtering completed
DEBUG - 2012-04-07 01:35:18 --> CRSF cookie Set
DEBUG - 2012-04-07 01:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:35:18 --> Language Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Loader Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Controller Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Model Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Model Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:35:18 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:35:18 --> Session Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:35:18 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:35:18 --> Session routines successfully run
DEBUG - 2012-04-07 01:35:18 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:35:18 --> Pages view: nuevacuenta
DEBUG - 2012-04-07 01:35:18 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:35:18 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-07 01:35:18 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:35:18 --> Final output sent to browser
DEBUG - 2012-04-07 01:35:18 --> Total execution time: 0.0171
DEBUG - 2012-04-07 01:35:33 --> Config Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:35:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:35:33 --> URI Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Router Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Output Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Security Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Input Class Initialized
DEBUG - 2012-04-07 01:35:33 --> XSS Filtering completed
DEBUG - 2012-04-07 01:35:33 --> XSS Filtering completed
DEBUG - 2012-04-07 01:35:33 --> XSS Filtering completed
DEBUG - 2012-04-07 01:35:33 --> XSS Filtering completed
DEBUG - 2012-04-07 01:35:33 --> XSS Filtering completed
DEBUG - 2012-04-07 01:35:33 --> XSS Filtering completed
DEBUG - 2012-04-07 01:35:33 --> XSS Filtering completed
DEBUG - 2012-04-07 01:35:33 --> CRSF cookie Set
DEBUG - 2012-04-07 01:35:33 --> CSRF token verified 
DEBUG - 2012-04-07 01:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:35:33 --> Language Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Loader Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Controller Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Model Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Model Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Session Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:35:33 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:35:33 --> Session routines successfully run
DEBUG - 2012-04-07 01:35:33 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:35:33 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:35:33 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:35:33 --> ermex/newaccount
DEBUG - 2012-04-07 01:35:33 --> App_model/userExist
DEBUG - 2012-04-07 01:35:33 --> Email not registered
DEBUG - 2012-04-07 01:35:33 --> App_model/insertUser
DEBUG - 2012-04-07 01:35:33 --> Email Class Initialized
DEBUG - 2012-04-07 01:35:34 --> Language file loaded: language/english/email_lang.php
DEBUG - 2012-04-07 01:38:51 --> Config Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:38:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:38:51 --> URI Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Router Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Output Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Security Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Input Class Initialized
DEBUG - 2012-04-07 01:38:51 --> XSS Filtering completed
DEBUG - 2012-04-07 01:38:51 --> XSS Filtering completed
DEBUG - 2012-04-07 01:38:51 --> XSS Filtering completed
DEBUG - 2012-04-07 01:38:51 --> XSS Filtering completed
DEBUG - 2012-04-07 01:38:51 --> XSS Filtering completed
DEBUG - 2012-04-07 01:38:51 --> XSS Filtering completed
DEBUG - 2012-04-07 01:38:51 --> XSS Filtering completed
DEBUG - 2012-04-07 01:38:51 --> CRSF cookie Set
DEBUG - 2012-04-07 01:38:51 --> CSRF token verified 
DEBUG - 2012-04-07 01:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:38:51 --> Language Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Loader Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Controller Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Model Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Model Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Session Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:38:51 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:38:51 --> Session routines successfully run
DEBUG - 2012-04-07 01:38:51 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:38:51 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:38:51 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:38:51 --> ermex/newaccount
DEBUG - 2012-04-07 01:38:51 --> App_model/userExist
DEBUG - 2012-04-07 01:38:51 --> Email not registered
DEBUG - 2012-04-07 01:38:51 --> App_model/insertUser
DEBUG - 2012-04-07 01:38:51 --> Email Class Initialized
DEBUG - 2012-04-07 01:38:52 --> Language file loaded: language/english/email_lang.php
DEBUG - 2012-04-07 01:38:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:38:55 --> Config Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:38:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:38:55 --> URI Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Router Class Initialized
DEBUG - 2012-04-07 01:38:55 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:38:55 --> Output Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Security Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Input Class Initialized
DEBUG - 2012-04-07 01:38:55 --> XSS Filtering completed
DEBUG - 2012-04-07 01:38:55 --> XSS Filtering completed
DEBUG - 2012-04-07 01:38:55 --> XSS Filtering completed
DEBUG - 2012-04-07 01:38:55 --> XSS Filtering completed
DEBUG - 2012-04-07 01:38:55 --> CRSF cookie Set
DEBUG - 2012-04-07 01:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:38:55 --> Language Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Loader Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Controller Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Model Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Model Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:38:55 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:38:55 --> Session Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:38:55 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:38:55 --> Session routines successfully run
DEBUG - 2012-04-07 01:38:55 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:38:55 --> Pages view: home
DEBUG - 2012-04-07 01:38:55 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:38:55 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:38:55 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:38:55 --> Final output sent to browser
DEBUG - 2012-04-07 01:38:55 --> Total execution time: 0.0113
DEBUG - 2012-04-07 01:41:52 --> Config Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:41:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:41:52 --> URI Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Router Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Output Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Security Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Input Class Initialized
DEBUG - 2012-04-07 01:41:52 --> XSS Filtering completed
DEBUG - 2012-04-07 01:41:52 --> XSS Filtering completed
DEBUG - 2012-04-07 01:41:52 --> XSS Filtering completed
DEBUG - 2012-04-07 01:41:52 --> CRSF cookie Set
DEBUG - 2012-04-07 01:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:41:52 --> Language Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Loader Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Controller Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Model Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Model Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:41:52 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:41:52 --> Session Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:41:52 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:41:52 --> Session routines successfully run
DEBUG - 2012-04-07 01:41:52 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:41:52 --> Pages view: nuevacuenta
DEBUG - 2012-04-07 01:41:52 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:41:52 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-07 01:41:52 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:41:52 --> Final output sent to browser
DEBUG - 2012-04-07 01:41:52 --> Total execution time: 0.0129
DEBUG - 2012-04-07 01:42:01 --> Config Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:42:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:42:01 --> URI Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Router Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Output Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Security Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Input Class Initialized
DEBUG - 2012-04-07 01:42:01 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:01 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:01 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:01 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:01 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:01 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:01 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:01 --> CRSF cookie Set
DEBUG - 2012-04-07 01:42:01 --> CSRF token verified 
DEBUG - 2012-04-07 01:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:42:01 --> Language Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Loader Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Controller Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Session Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:42:01 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Session routines successfully run
DEBUG - 2012-04-07 01:42:01 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:42:01 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:42:01 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:42:01 --> ermex/newaccount
DEBUG - 2012-04-07 01:42:01 --> App_model/userExist
DEBUG - 2012-04-07 01:42:01 --> Email not registered
DEBUG - 2012-04-07 01:42:01 --> App_model/insertUser
DEBUG - 2012-04-07 01:42:01 --> Email Class Initialized
DEBUG - 2012-04-07 01:42:01 --> Language file loaded: language/english/email_lang.php
DEBUG - 2012-04-07 01:42:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:42:05 --> Config Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:42:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:42:05 --> URI Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Router Class Initialized
DEBUG - 2012-04-07 01:42:05 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:42:05 --> Output Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Security Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Input Class Initialized
DEBUG - 2012-04-07 01:42:05 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:05 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:05 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:05 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:05 --> CRSF cookie Set
DEBUG - 2012-04-07 01:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:42:05 --> Language Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Loader Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Controller Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:42:05 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:42:05 --> Session Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:42:05 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:42:05 --> Session routines successfully run
DEBUG - 2012-04-07 01:42:05 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:42:05 --> Pages view: home
DEBUG - 2012-04-07 01:42:05 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:42:05 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:42:05 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:42:05 --> Final output sent to browser
DEBUG - 2012-04-07 01:42:05 --> Total execution time: 0.0121
DEBUG - 2012-04-07 01:42:24 --> Config Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:42:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:42:24 --> URI Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Router Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Output Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Security Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Input Class Initialized
DEBUG - 2012-04-07 01:42:24 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:24 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:24 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:24 --> CRSF cookie Set
DEBUG - 2012-04-07 01:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:42:24 --> Language Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Loader Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Controller Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:42:24 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:42:24 --> Session Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:42:24 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:42:24 --> Session routines successfully run
DEBUG - 2012-04-07 01:42:24 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:42:24 --> Pages view: index.php
ERROR - 2012-04-07 01:42:24 --> 404 Page Not Found --> 
DEBUG - 2012-04-07 01:42:48 --> Config Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:42:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:42:48 --> URI Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Router Class Initialized
DEBUG - 2012-04-07 01:42:48 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:42:48 --> Output Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Security Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Input Class Initialized
DEBUG - 2012-04-07 01:42:48 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:48 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:48 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:48 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:48 --> CRSF cookie Set
DEBUG - 2012-04-07 01:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:42:48 --> Language Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Loader Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Controller Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:42:48 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:42:48 --> Session Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:42:48 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:42:48 --> Session routines successfully run
DEBUG - 2012-04-07 01:42:48 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:42:48 --> Pages view: home
DEBUG - 2012-04-07 01:42:48 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:42:48 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:42:48 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:42:48 --> Final output sent to browser
DEBUG - 2012-04-07 01:42:48 --> Total execution time: 0.0151
DEBUG - 2012-04-07 01:42:50 --> Config Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:42:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:42:50 --> URI Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Router Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Output Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Security Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Input Class Initialized
DEBUG - 2012-04-07 01:42:50 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:50 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:50 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:50 --> CRSF cookie Set
DEBUG - 2012-04-07 01:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:42:50 --> Language Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Loader Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Controller Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:42:50 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:42:50 --> Session Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:42:50 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:42:50 --> Session routines successfully run
DEBUG - 2012-04-07 01:42:50 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:42:50 --> Pages view: recpass
DEBUG - 2012-04-07 01:42:50 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:42:50 --> File loaded: application/views/pages/recpass.php
DEBUG - 2012-04-07 01:42:50 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:42:50 --> Final output sent to browser
DEBUG - 2012-04-07 01:42:50 --> Total execution time: 0.0124
DEBUG - 2012-04-07 01:42:56 --> Config Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:42:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:42:56 --> URI Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Router Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Output Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Security Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Input Class Initialized
DEBUG - 2012-04-07 01:42:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:56 --> XSS Filtering completed
DEBUG - 2012-04-07 01:42:56 --> CRSF cookie Set
DEBUG - 2012-04-07 01:42:56 --> CSRF token verified 
DEBUG - 2012-04-07 01:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:42:56 --> Language Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Loader Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Controller Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Model Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Session Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:42:56 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:42:56 --> Session routines successfully run
DEBUG - 2012-04-07 01:42:56 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:42:56 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:42:56 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:42:56 --> App_model/userExist
DEBUG - 2012-04-07 01:42:56 --> Email already used
DEBUG - 2012-04-07 01:44:26 --> Config Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:44:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:44:26 --> URI Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Router Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Output Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Security Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Input Class Initialized
DEBUG - 2012-04-07 01:44:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:26 --> CRSF cookie Set
DEBUG - 2012-04-07 01:44:26 --> CSRF token verified 
DEBUG - 2012-04-07 01:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:44:26 --> Language Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Loader Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Controller Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Model Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Model Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Session Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:44:26 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:44:26 --> Session routines successfully run
DEBUG - 2012-04-07 01:44:26 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:44:26 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:44:26 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:44:26 --> App_model/userExist
DEBUG - 2012-04-07 01:44:26 --> Email already used
DEBUG - 2012-04-07 01:44:26 --> Email Class Initialized
DEBUG - 2012-04-07 01:44:27 --> Language file loaded: language/english/email_lang.php
DEBUG - 2012-04-07 01:44:29 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 01:44:29 --> File loaded: application/views/pages/recpass.php
DEBUG - 2012-04-07 01:44:29 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:44:29 --> Final output sent to browser
DEBUG - 2012-04-07 01:44:29 --> Total execution time: 2.5771
DEBUG - 2012-04-07 01:44:45 --> Config Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:44:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:44:45 --> URI Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Router Class Initialized
DEBUG - 2012-04-07 01:44:45 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:44:45 --> Output Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Security Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Input Class Initialized
DEBUG - 2012-04-07 01:44:45 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:45 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:45 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:45 --> CRSF cookie Set
DEBUG - 2012-04-07 01:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:44:45 --> Language Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Loader Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Controller Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Model Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Model Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:44:45 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:44:45 --> Session Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:44:45 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:44:45 --> Session routines successfully run
DEBUG - 2012-04-07 01:44:45 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:44:45 --> Pages view: home
DEBUG - 2012-04-07 01:44:45 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:44:45 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:44:45 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:44:45 --> Final output sent to browser
DEBUG - 2012-04-07 01:44:45 --> Total execution time: 0.0133
DEBUG - 2012-04-07 01:44:49 --> Config Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:44:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:44:49 --> URI Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Router Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Output Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Security Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Input Class Initialized
DEBUG - 2012-04-07 01:44:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:49 --> CRSF cookie Set
DEBUG - 2012-04-07 01:44:49 --> CSRF token verified 
DEBUG - 2012-04-07 01:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:44:49 --> Language Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Loader Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Controller Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Model Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Model Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Session Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:44:49 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Session routines successfully run
DEBUG - 2012-04-07 01:44:49 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:44:49 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:44:49 --> *Security/login
DEBUG - 2012-04-07 01:44:49 --> App_model login
DEBUG - 2012-04-07 01:44:49 --> **Found user**
DEBUG - 2012-04-07 01:44:49 --> Config Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:44:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:44:49 --> URI Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Router Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Output Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Security Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Input Class Initialized
DEBUG - 2012-04-07 01:44:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:49 --> XSS Filtering completed
DEBUG - 2012-04-07 01:44:49 --> CRSF cookie Set
DEBUG - 2012-04-07 01:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:44:49 --> Language Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Loader Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Controller Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Model Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Model Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:44:49 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:44:49 --> Session Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:44:49 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:44:49 --> Session routines successfully run
DEBUG - 2012-04-07 01:44:49 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:44:49 --> Pages view: mainmenu
DEBUG - 2012-04-07 01:44:49 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 01:44:49 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-07 01:44:49 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:44:49 --> Final output sent to browser
DEBUG - 2012-04-07 01:44:49 --> Total execution time: 0.0117
DEBUG - 2012-04-07 01:45:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:47:38 --> Config Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:47:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:47:38 --> URI Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Router Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Output Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Security Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Input Class Initialized
DEBUG - 2012-04-07 01:47:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:38 --> CRSF cookie Set
DEBUG - 2012-04-07 01:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:47:38 --> Language Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Loader Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Controller Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Model Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Model Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Session Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:47:38 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:47:38 --> Session routines successfully run
DEBUG - 2012-04-07 01:47:38 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:47:38 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:47:38 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:47:38 --> ermex/mapLocator
DEBUG - 2012-04-07 01:47:38 --> localizando por ADDR
DEBUG - 2012-04-07 01:47:38 --> creando mapa por addr: $addr 
DEBUG - 2012-04-07 01:47:38 --> GMap class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:47:47 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 01:47:47 --> File loaded: application/views/pages/mapa.php
DEBUG - 2012-04-07 01:47:47 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:47:47 --> Final output sent to browser
DEBUG - 2012-04-07 01:47:47 --> Total execution time: 8.8679
DEBUG - 2012-04-07 01:47:57 --> Config Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:47:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:47:57 --> URI Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Router Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Output Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Security Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Input Class Initialized
DEBUG - 2012-04-07 01:47:57 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:57 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:57 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:57 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:57 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:57 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:57 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:57 --> XSS Filtering completed
DEBUG - 2012-04-07 01:47:57 --> CRSF cookie Set
DEBUG - 2012-04-07 01:47:57 --> CSRF token verified 
DEBUG - 2012-04-07 01:47:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:47:57 --> Language Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Loader Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Controller Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Model Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Model Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Session Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:47:57 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:47:57 --> Session routines successfully run
DEBUG - 2012-04-07 01:47:57 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:47:57 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:47:57 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:47:57 --> ermex/newregistry	
DEBUG - 2012-04-07 01:47:57 --> forma de registro para: 25.6635777 x -100.1887268 x Tres Caminos 1er Sector, Guadalupe, NL, México
DEBUG - 2012-04-07 01:47:57 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 01:47:57 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-07 01:47:57 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:47:57 --> Final output sent to browser
DEBUG - 2012-04-07 01:47:57 --> Total execution time: 0.0135
DEBUG - 2012-04-07 01:48:06 --> Config Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:48:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:48:06 --> URI Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Router Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Output Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Security Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Input Class Initialized
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:06 --> CRSF cookie Set
DEBUG - 2012-04-07 01:48:06 --> CSRF token verified 
DEBUG - 2012-04-07 01:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:48:06 --> Language Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Loader Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Controller Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Model Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Model Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Session Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:48:06 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:48:06 --> Session routines successfully run
DEBUG - 2012-04-07 01:48:06 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:48:06 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:48:06 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:48:06 --> ermex/newregistrypost
DEBUG - 2012-04-07 01:48:06 --> App_model/createNewRegistry
DEBUG - 2012-04-07 01:48:06 --> Email Class Initialized
DEBUG - 2012-04-07 01:48:15 --> Language file loaded: language/english/email_lang.php
DEBUG - 2012-04-07 01:48:20 --> Config Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:48:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:48:20 --> URI Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Router Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Output Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Security Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Input Class Initialized
DEBUG - 2012-04-07 01:48:20 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:20 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:20 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:20 --> CRSF cookie Set
DEBUG - 2012-04-07 01:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:48:20 --> Language Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Loader Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Controller Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Model Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Model Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:48:20 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:48:20 --> Session Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:48:20 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:48:20 --> Session routines successfully run
DEBUG - 2012-04-07 01:48:20 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:48:20 --> Pages view: registrook
DEBUG - 2012-04-07 01:48:20 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 01:48:20 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-07 01:48:20 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:48:20 --> Final output sent to browser
DEBUG - 2012-04-07 01:48:20 --> Total execution time: 0.0133
DEBUG - 2012-04-07 01:48:26 --> Config Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:48:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:48:26 --> URI Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Router Class Initialized
DEBUG - 2012-04-07 01:48:26 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:48:26 --> Output Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Security Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Input Class Initialized
DEBUG - 2012-04-07 01:48:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:26 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:26 --> CRSF cookie Set
DEBUG - 2012-04-07 01:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:48:26 --> Language Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Loader Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Controller Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Model Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Model Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:48:26 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:48:26 --> Session Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:48:26 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:48:26 --> Session routines successfully run
DEBUG - 2012-04-07 01:48:26 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:48:26 --> Pages view: home
DEBUG - 2012-04-07 01:48:26 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:48:26 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:48:26 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:48:26 --> Final output sent to browser
DEBUG - 2012-04-07 01:48:26 --> Total execution time: 0.0202
DEBUG - 2012-04-07 01:48:37 --> Config Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:48:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:48:37 --> URI Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Router Class Initialized
DEBUG - 2012-04-07 01:48:37 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:48:37 --> Output Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Security Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Input Class Initialized
DEBUG - 2012-04-07 01:48:37 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:37 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:37 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:37 --> CRSF cookie Set
DEBUG - 2012-04-07 01:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:48:37 --> Language Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Loader Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Controller Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Model Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Model Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:48:37 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:48:37 --> Session Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:48:37 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:48:37 --> Session routines successfully run
DEBUG - 2012-04-07 01:48:37 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:48:37 --> Pages view: home
DEBUG - 2012-04-07 01:48:37 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:48:37 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:48:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:48:37 --> Final output sent to browser
DEBUG - 2012-04-07 01:48:37 --> Total execution time: 0.0142
DEBUG - 2012-04-07 01:48:38 --> Config Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:48:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:48:38 --> URI Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Router Class Initialized
DEBUG - 2012-04-07 01:48:38 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:48:38 --> Output Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Security Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Input Class Initialized
DEBUG - 2012-04-07 01:48:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:38 --> XSS Filtering completed
DEBUG - 2012-04-07 01:48:38 --> CRSF cookie Set
DEBUG - 2012-04-07 01:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:48:38 --> Language Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Loader Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Controller Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Model Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Model Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:48:38 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:48:38 --> Session Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:48:38 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:48:38 --> Session routines successfully run
DEBUG - 2012-04-07 01:48:38 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:48:38 --> Pages view: home
DEBUG - 2012-04-07 01:48:38 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:48:38 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:48:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:48:38 --> Final output sent to browser
DEBUG - 2012-04-07 01:48:38 --> Total execution time: 0.0156
DEBUG - 2012-04-07 01:50:00 --> Config Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Hooks Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Utf8 Class Initialized
DEBUG - 2012-04-07 01:50:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 01:50:00 --> URI Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Router Class Initialized
DEBUG - 2012-04-07 01:50:00 --> No URI present. Default controller set.
DEBUG - 2012-04-07 01:50:00 --> Output Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Security Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Input Class Initialized
DEBUG - 2012-04-07 01:50:00 --> XSS Filtering completed
DEBUG - 2012-04-07 01:50:00 --> XSS Filtering completed
DEBUG - 2012-04-07 01:50:00 --> XSS Filtering completed
DEBUG - 2012-04-07 01:50:00 --> CRSF cookie Set
DEBUG - 2012-04-07 01:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 01:50:00 --> Language Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Loader Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Controller Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Model Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Model Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Database Driver Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Helper loaded: url_helper
DEBUG - 2012-04-07 01:50:00 --> Helper loaded: form_helper
DEBUG - 2012-04-07 01:50:00 --> Session Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Helper loaded: string_helper
DEBUG - 2012-04-07 01:50:00 --> Encrypt Class Initialized
DEBUG - 2012-04-07 01:50:00 --> Session routines successfully run
DEBUG - 2012-04-07 01:50:00 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 01:50:00 --> Pages view: home
DEBUG - 2012-04-07 01:50:00 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 01:50:00 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 01:50:00 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 01:50:00 --> Final output sent to browser
DEBUG - 2012-04-07 01:50:00 --> Total execution time: 0.0167
DEBUG - 2012-04-07 02:08:59 --> Config Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:08:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:08:59 --> URI Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Router Class Initialized
DEBUG - 2012-04-07 02:08:59 --> No URI present. Default controller set.
DEBUG - 2012-04-07 02:08:59 --> Output Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Security Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Input Class Initialized
DEBUG - 2012-04-07 02:08:59 --> XSS Filtering completed
DEBUG - 2012-04-07 02:08:59 --> XSS Filtering completed
DEBUG - 2012-04-07 02:08:59 --> XSS Filtering completed
DEBUG - 2012-04-07 02:08:59 --> CRSF cookie Set
DEBUG - 2012-04-07 02:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:08:59 --> Language Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Loader Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Controller Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Model Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Model Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:08:59 --> Helper loaded: form_helper
DEBUG - 2012-04-07 02:08:59 --> Session Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:08:59 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:08:59 --> Session routines successfully run
DEBUG - 2012-04-07 02:08:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:08:59 --> Pages view: home
DEBUG - 2012-04-07 02:08:59 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 02:08:59 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 02:08:59 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 02:08:59 --> Final output sent to browser
DEBUG - 2012-04-07 02:08:59 --> Total execution time: 0.5563
DEBUG - 2012-04-07 02:09:11 --> Config Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:09:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:09:11 --> URI Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Router Class Initialized
DEBUG - 2012-04-07 02:09:11 --> No URI present. Default controller set.
DEBUG - 2012-04-07 02:09:11 --> Output Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Security Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Input Class Initialized
DEBUG - 2012-04-07 02:09:11 --> XSS Filtering completed
DEBUG - 2012-04-07 02:09:11 --> XSS Filtering completed
DEBUG - 2012-04-07 02:09:11 --> XSS Filtering completed
DEBUG - 2012-04-07 02:09:11 --> CRSF cookie Set
DEBUG - 2012-04-07 02:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:09:11 --> Language Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Loader Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Controller Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Model Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Model Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:09:11 --> Helper loaded: form_helper
DEBUG - 2012-04-07 02:09:11 --> Session Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:09:11 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:09:11 --> Session routines successfully run
DEBUG - 2012-04-07 02:09:11 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:09:11 --> Pages view: home
DEBUG - 2012-04-07 02:09:11 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 02:09:11 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 02:09:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 02:09:11 --> Final output sent to browser
DEBUG - 2012-04-07 02:09:11 --> Total execution time: 0.1811
DEBUG - 2012-04-07 02:12:33 --> Config Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:12:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:12:33 --> URI Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Router Class Initialized
DEBUG - 2012-04-07 02:12:33 --> No URI present. Default controller set.
DEBUG - 2012-04-07 02:12:33 --> Output Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Security Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Input Class Initialized
DEBUG - 2012-04-07 02:12:33 --> XSS Filtering completed
DEBUG - 2012-04-07 02:12:33 --> XSS Filtering completed
DEBUG - 2012-04-07 02:12:33 --> XSS Filtering completed
DEBUG - 2012-04-07 02:12:33 --> CRSF cookie Set
DEBUG - 2012-04-07 02:12:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:12:33 --> Language Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Loader Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Controller Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Model Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Model Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:12:33 --> Helper loaded: form_helper
DEBUG - 2012-04-07 02:12:33 --> Session Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:12:33 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:12:33 --> Session routines successfully run
DEBUG - 2012-04-07 02:12:33 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:12:33 --> Pages view: home
DEBUG - 2012-04-07 02:12:33 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 02:12:33 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 02:12:33 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 02:12:33 --> Final output sent to browser
DEBUG - 2012-04-07 02:12:33 --> Total execution time: 0.1538
DEBUG - 2012-04-07 02:13:58 --> Config Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:13:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:13:58 --> URI Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Router Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Output Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Security Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Input Class Initialized
DEBUG - 2012-04-07 02:13:58 --> XSS Filtering completed
DEBUG - 2012-04-07 02:13:58 --> XSS Filtering completed
DEBUG - 2012-04-07 02:13:58 --> XSS Filtering completed
DEBUG - 2012-04-07 02:13:58 --> XSS Filtering completed
DEBUG - 2012-04-07 02:13:58 --> XSS Filtering completed
DEBUG - 2012-04-07 02:13:58 --> XSS Filtering completed
DEBUG - 2012-04-07 02:13:58 --> CRSF cookie Set
DEBUG - 2012-04-07 02:13:58 --> CSRF token verified 
DEBUG - 2012-04-07 02:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:13:58 --> Language Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Loader Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Controller Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Model Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Model Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Session Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:13:58 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Session routines successfully run
DEBUG - 2012-04-07 02:13:58 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:13:58 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:13:58 --> *Security/login
DEBUG - 2012-04-07 02:13:58 --> App_model login
DEBUG - 2012-04-07 02:13:58 --> **Found user**
DEBUG - 2012-04-07 02:13:58 --> Config Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:13:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:13:58 --> URI Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Router Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Output Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Security Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Input Class Initialized
DEBUG - 2012-04-07 02:13:58 --> XSS Filtering completed
DEBUG - 2012-04-07 02:13:58 --> XSS Filtering completed
DEBUG - 2012-04-07 02:13:58 --> XSS Filtering completed
DEBUG - 2012-04-07 02:13:58 --> CRSF cookie Set
DEBUG - 2012-04-07 02:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:13:58 --> Language Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Loader Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Controller Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Model Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Model Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:13:58 --> Helper loaded: form_helper
DEBUG - 2012-04-07 02:13:58 --> Session Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:13:58 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:13:58 --> Session routines successfully run
DEBUG - 2012-04-07 02:13:58 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:13:58 --> Pages view: mainmenu
DEBUG - 2012-04-07 02:13:58 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 02:13:58 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-07 02:13:58 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 02:13:58 --> Final output sent to browser
DEBUG - 2012-04-07 02:13:58 --> Total execution time: 0.0307
DEBUG - 2012-04-07 02:14:31 --> Config Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:14:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:14:31 --> URI Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Router Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Output Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Security Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Input Class Initialized
DEBUG - 2012-04-07 02:14:31 --> XSS Filtering completed
DEBUG - 2012-04-07 02:14:31 --> XSS Filtering completed
DEBUG - 2012-04-07 02:14:31 --> XSS Filtering completed
DEBUG - 2012-04-07 02:14:31 --> CRSF cookie Set
DEBUG - 2012-04-07 02:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:14:31 --> Language Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Loader Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Controller Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Model Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Model Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:14:31 --> Helper loaded: form_helper
DEBUG - 2012-04-07 02:14:31 --> Session Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:14:31 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:14:31 --> Session routines successfully run
DEBUG - 2012-04-07 02:14:31 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:14:31 --> Pages view: mainmenu
DEBUG - 2012-04-07 02:14:31 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 02:14:31 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-07 02:14:31 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 02:14:31 --> Final output sent to browser
DEBUG - 2012-04-07 02:14:31 --> Total execution time: 0.0225
DEBUG - 2012-04-07 02:15:35 --> Config Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:15:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:15:35 --> URI Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Router Class Initialized
DEBUG - 2012-04-07 02:15:35 --> No URI present. Default controller set.
DEBUG - 2012-04-07 02:15:35 --> Output Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Security Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Input Class Initialized
DEBUG - 2012-04-07 02:15:35 --> XSS Filtering completed
DEBUG - 2012-04-07 02:15:35 --> XSS Filtering completed
DEBUG - 2012-04-07 02:15:35 --> XSS Filtering completed
DEBUG - 2012-04-07 02:15:35 --> CRSF cookie Set
DEBUG - 2012-04-07 02:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:15:35 --> Language Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Loader Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Controller Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Model Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Model Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:15:35 --> Helper loaded: form_helper
DEBUG - 2012-04-07 02:15:35 --> Session Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:15:35 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:15:35 --> Session routines successfully run
DEBUG - 2012-04-07 02:15:35 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:15:35 --> Pages view: home
DEBUG - 2012-04-07 02:15:35 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 02:15:35 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 02:15:35 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 02:15:35 --> Final output sent to browser
DEBUG - 2012-04-07 02:15:35 --> Total execution time: 0.0336
DEBUG - 2012-04-07 02:16:24 --> Config Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:16:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:16:24 --> URI Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Router Class Initialized
DEBUG - 2012-04-07 02:16:24 --> No URI present. Default controller set.
DEBUG - 2012-04-07 02:16:24 --> Output Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Security Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Input Class Initialized
DEBUG - 2012-04-07 02:16:24 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:24 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:24 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:24 --> CRSF cookie Set
DEBUG - 2012-04-07 02:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:16:24 --> Language Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Loader Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Controller Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Model Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Model Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:16:24 --> Helper loaded: form_helper
DEBUG - 2012-04-07 02:16:24 --> Session Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:16:24 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:16:24 --> Session routines successfully run
DEBUG - 2012-04-07 02:16:24 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:16:24 --> Pages view: home
DEBUG - 2012-04-07 02:16:24 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 02:16:24 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 02:16:24 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 02:16:24 --> Final output sent to browser
DEBUG - 2012-04-07 02:16:24 --> Total execution time: 0.0182
DEBUG - 2012-04-07 02:16:29 --> Config Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:16:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:16:29 --> URI Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Router Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Output Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Security Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Input Class Initialized
DEBUG - 2012-04-07 02:16:29 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:29 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:29 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:29 --> CRSF cookie Set
DEBUG - 2012-04-07 02:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:16:29 --> Language Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Loader Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Controller Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Model Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Model Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:16:29 --> Helper loaded: form_helper
DEBUG - 2012-04-07 02:16:29 --> Session Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:16:29 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:16:29 --> Session routines successfully run
DEBUG - 2012-04-07 02:16:29 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:16:29 --> Pages view: logoff
DEBUG - 2012-04-07 02:16:29 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 02:16:29 --> File loaded: application/views/pages/logoff.php
DEBUG - 2012-04-07 02:16:29 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 02:16:29 --> Final output sent to browser
DEBUG - 2012-04-07 02:16:29 --> Total execution time: 0.0115
DEBUG - 2012-04-07 02:16:31 --> Config Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:16:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:16:31 --> URI Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Router Class Initialized
DEBUG - 2012-04-07 02:16:31 --> No URI present. Default controller set.
DEBUG - 2012-04-07 02:16:31 --> Output Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Security Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Input Class Initialized
DEBUG - 2012-04-07 02:16:31 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:31 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:31 --> CRSF cookie Set
DEBUG - 2012-04-07 02:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:16:31 --> Language Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Loader Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Controller Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Model Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Model Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:16:31 --> Helper loaded: form_helper
DEBUG - 2012-04-07 02:16:31 --> Session Class Initialized
DEBUG - 2012-04-07 02:16:31 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:16:31 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:16:31 --> A session cookie was not found.
DEBUG - 2012-04-07 02:16:31 --> Session routines successfully run
DEBUG - 2012-04-07 02:16:31 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:16:31 --> Pages view: home
DEBUG - 2012-04-07 02:16:31 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-07 02:16:31 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-07 02:16:31 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 02:16:31 --> Final output sent to browser
DEBUG - 2012-04-07 02:16:31 --> Total execution time: 0.0110
DEBUG - 2012-04-07 02:16:37 --> Config Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:16:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:16:37 --> URI Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Router Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Output Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Security Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Input Class Initialized
DEBUG - 2012-04-07 02:16:37 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:37 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:37 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:37 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:37 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:37 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:37 --> CRSF cookie Set
DEBUG - 2012-04-07 02:16:37 --> CSRF token verified 
DEBUG - 2012-04-07 02:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:16:37 --> Language Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Loader Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Controller Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Model Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Model Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Session Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:16:37 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Session routines successfully run
DEBUG - 2012-04-07 02:16:37 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:16:37 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:16:37 --> *Security/login
DEBUG - 2012-04-07 02:16:37 --> App_model login
DEBUG - 2012-04-07 02:16:37 --> **Found user**
DEBUG - 2012-04-07 02:16:37 --> Config Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Hooks Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Utf8 Class Initialized
DEBUG - 2012-04-07 02:16:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 02:16:37 --> URI Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Router Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Output Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Security Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Input Class Initialized
DEBUG - 2012-04-07 02:16:37 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:37 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:37 --> XSS Filtering completed
DEBUG - 2012-04-07 02:16:37 --> CRSF cookie Set
DEBUG - 2012-04-07 02:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 02:16:37 --> Language Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Loader Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Controller Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Model Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Model Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Database Driver Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Helper loaded: url_helper
DEBUG - 2012-04-07 02:16:37 --> Helper loaded: form_helper
DEBUG - 2012-04-07 02:16:37 --> Session Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Helper loaded: string_helper
DEBUG - 2012-04-07 02:16:37 --> Encrypt Class Initialized
DEBUG - 2012-04-07 02:16:37 --> Session routines successfully run
DEBUG - 2012-04-07 02:16:37 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-07 02:16:37 --> Pages view: mainmenu
DEBUG - 2012-04-07 02:16:37 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-07 02:16:37 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-07 02:16:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-07 02:16:37 --> Final output sent to browser
DEBUG - 2012-04-07 02:16:37 --> Total execution time: 0.0119
