<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-06 22:42:19 --> Config Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:42:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:42:19 --> URI Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Router Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Output Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Security Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Input Class Initialized
DEBUG - 2012-04-06 22:42:19 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:19 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:19 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:19 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:19 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:19 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:19 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:19 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:19 --> CRSF cookie Set
DEBUG - 2012-04-06 22:42:19 --> CSRF token verified 
DEBUG - 2012-04-06 22:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:42:19 --> Language Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Loader Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Controller Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Model Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Model Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Session Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:42:19 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Session routines successfully run
DEBUG - 2012-04-06 22:42:19 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:42:19 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:42:19 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:42:19 --> ermex/newregistry
DEBUG - 2012-04-06 22:42:19 --> No se recibieron coordenadas
DEBUG - 2012-04-06 22:42:19 --> Config Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:42:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:42:19 --> URI Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Router Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Output Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Security Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Input Class Initialized
DEBUG - 2012-04-06 22:42:19 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:19 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:19 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:19 --> CRSF cookie Set
DEBUG - 2012-04-06 22:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:42:19 --> Language Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Loader Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Controller Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:42:19 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:42:19 --> Session Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:42:19 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:42:19 --> Session routines successfully run
DEBUG - 2012-04-06 22:42:19 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:42:19 --> Pages view: mainmenu
DEBUG - 2012-04-06 22:42:19 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:42:19 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-06 22:42:19 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:42:19 --> Final output sent to browser
DEBUG - 2012-04-06 22:42:19 --> Total execution time: 0.0092
DEBUG - 2012-04-06 22:42:52 --> Config Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:42:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:42:52 --> URI Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Router Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Output Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Security Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Input Class Initialized
DEBUG - 2012-04-06 22:42:52 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:52 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:52 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:52 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:52 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:52 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:52 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:52 --> CRSF cookie Set
DEBUG - 2012-04-06 22:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:42:52 --> Language Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Loader Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Controller Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Model Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Model Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Session Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:42:52 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:42:52 --> Session routines successfully run
DEBUG - 2012-04-06 22:42:52 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:42:52 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:42:52 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:42:52 --> ermex/mapLocator
DEBUG - 2012-04-06 22:42:52 --> localizando por GPS
DEBUG - 2012-04-06 22:42:52 --> creando mapa por coords: 18.8563587 x -97.0718117 
DEBUG - 2012-04-06 22:42:52 --> GMap class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:42:52 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:42:52 --> File loaded: application/views/pages/mapa.php
DEBUG - 2012-04-06 22:42:52 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:42:52 --> Final output sent to browser
DEBUG - 2012-04-06 22:42:52 --> Total execution time: 0.0156
DEBUG - 2012-04-06 22:42:59 --> Config Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:42:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:42:59 --> URI Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Router Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Output Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Security Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Input Class Initialized
DEBUG - 2012-04-06 22:42:59 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:59 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:59 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:59 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:59 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:59 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:59 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:59 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:59 --> CRSF cookie Set
DEBUG - 2012-04-06 22:42:59 --> CSRF token verified 
DEBUG - 2012-04-06 22:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:42:59 --> Language Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Loader Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Controller Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Model Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Model Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Session Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:42:59 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Session routines successfully run
DEBUG - 2012-04-06 22:42:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:42:59 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:42:59 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:42:59 --> ermex/newregistry
DEBUG - 2012-04-06 22:42:59 --> No se recibieron coordenadas
DEBUG - 2012-04-06 22:42:59 --> Config Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:42:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:42:59 --> URI Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Router Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Output Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Security Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Input Class Initialized
DEBUG - 2012-04-06 22:42:59 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:59 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:59 --> XSS Filtering completed
DEBUG - 2012-04-06 22:42:59 --> CRSF cookie Set
DEBUG - 2012-04-06 22:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:42:59 --> Language Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Loader Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Controller Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:42:59 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:42:59 --> Session Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:42:59 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:42:59 --> Session routines successfully run
DEBUG - 2012-04-06 22:42:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:42:59 --> Pages view: mainmenu
DEBUG - 2012-04-06 22:42:59 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:42:59 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-06 22:42:59 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:42:59 --> Final output sent to browser
DEBUG - 2012-04-06 22:42:59 --> Total execution time: 0.0087
DEBUG - 2012-04-06 22:45:10 --> Config Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:45:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:45:10 --> URI Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Router Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Output Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Security Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Input Class Initialized
DEBUG - 2012-04-06 22:45:10 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:10 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:10 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:10 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:10 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:10 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:10 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:10 --> CRSF cookie Set
DEBUG - 2012-04-06 22:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:45:10 --> Language Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Loader Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Controller Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Model Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Model Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Session Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:45:10 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:45:10 --> Session routines successfully run
DEBUG - 2012-04-06 22:45:10 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:45:10 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:45:10 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:45:10 --> ermex/mapLocator
DEBUG - 2012-04-06 22:45:10 --> localizando por GPS
DEBUG - 2012-04-06 22:45:10 --> creando mapa por coords: 18.8563587 x -97.0718117 
DEBUG - 2012-04-06 22:45:10 --> GMap class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:45:10 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:45:10 --> File loaded: application/views/pages/mapa.php
DEBUG - 2012-04-06 22:45:10 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:45:10 --> Final output sent to browser
DEBUG - 2012-04-06 22:45:10 --> Total execution time: 0.1390
DEBUG - 2012-04-06 22:45:13 --> Config Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:45:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:45:13 --> URI Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Router Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Output Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Security Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Input Class Initialized
DEBUG - 2012-04-06 22:45:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:13 --> CRSF cookie Set
DEBUG - 2012-04-06 22:45:13 --> CSRF token verified 
DEBUG - 2012-04-06 22:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:45:13 --> Language Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Loader Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Controller Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Model Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Model Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Session Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:45:13 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Session routines successfully run
DEBUG - 2012-04-06 22:45:13 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:45:13 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:45:13 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:45:13 --> ermex/newregistry	
DEBUG - 2012-04-06 22:45:13 --> forma de registro para:  x  x 
ERROR - 2012-04-06 22:45:13 --> No se recibieron coordenadas
DEBUG - 2012-04-06 22:45:13 --> Config Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:45:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:45:13 --> URI Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Router Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Output Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Security Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Input Class Initialized
DEBUG - 2012-04-06 22:45:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:45:13 --> CRSF cookie Set
DEBUG - 2012-04-06 22:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:45:13 --> Language Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Loader Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Controller Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:45:13 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:45:13 --> Session Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:45:13 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:45:13 --> Session routines successfully run
DEBUG - 2012-04-06 22:45:13 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:45:13 --> Pages view: mainmenu
DEBUG - 2012-04-06 22:45:13 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:45:13 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-06 22:45:13 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:45:13 --> Final output sent to browser
DEBUG - 2012-04-06 22:45:13 --> Total execution time: 0.0081
DEBUG - 2012-04-06 22:46:53 --> Config Class Initialized
DEBUG - 2012-04-06 22:46:53 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:46:53 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:46:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:46:53 --> URI Class Initialized
DEBUG - 2012-04-06 22:46:53 --> Router Class Initialized
DEBUG - 2012-04-06 22:46:53 --> Output Class Initialized
DEBUG - 2012-04-06 22:46:53 --> Security Class Initialized
DEBUG - 2012-04-06 22:46:53 --> Input Class Initialized
DEBUG - 2012-04-06 22:46:53 --> XSS Filtering completed
DEBUG - 2012-04-06 22:46:53 --> XSS Filtering completed
DEBUG - 2012-04-06 22:46:53 --> XSS Filtering completed
DEBUG - 2012-04-06 22:46:53 --> CRSF cookie Set
DEBUG - 2012-04-06 22:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:46:53 --> Language Class Initialized
DEBUG - 2012-04-06 22:46:53 --> Loader Class Initialized
DEBUG - 2012-04-06 22:46:53 --> Controller Class Initialized
DEBUG - 2012-04-06 22:46:53 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:46:53 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:46:53 --> Session Class Initialized
DEBUG - 2012-04-06 22:46:53 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:46:53 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:46:53 --> Session routines successfully run
DEBUG - 2012-04-06 22:46:53 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:46:53 --> Pages view: mainmenu
DEBUG - 2012-04-06 22:46:53 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:46:53 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-06 22:46:53 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:46:53 --> Final output sent to browser
DEBUG - 2012-04-06 22:46:53 --> Total execution time: 0.0125
DEBUG - 2012-04-06 22:46:55 --> Config Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:46:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:46:55 --> URI Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Router Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Output Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Security Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Input Class Initialized
DEBUG - 2012-04-06 22:46:55 --> XSS Filtering completed
DEBUG - 2012-04-06 22:46:55 --> XSS Filtering completed
DEBUG - 2012-04-06 22:46:55 --> XSS Filtering completed
DEBUG - 2012-04-06 22:46:55 --> XSS Filtering completed
DEBUG - 2012-04-06 22:46:55 --> XSS Filtering completed
DEBUG - 2012-04-06 22:46:55 --> XSS Filtering completed
DEBUG - 2012-04-06 22:46:55 --> XSS Filtering completed
DEBUG - 2012-04-06 22:46:55 --> CRSF cookie Set
DEBUG - 2012-04-06 22:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:46:55 --> Language Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Loader Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Controller Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Model Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Model Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Session Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:46:55 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:46:55 --> Session routines successfully run
DEBUG - 2012-04-06 22:46:55 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:46:55 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:46:55 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:46:55 --> ermex/mapLocator
DEBUG - 2012-04-06 22:46:55 --> localizando por GPS
DEBUG - 2012-04-06 22:46:55 --> creando mapa por coords: 18.8563434 x -97.071827 
DEBUG - 2012-04-06 22:46:55 --> GMap class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:46:55 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:46:55 --> File loaded: application/views/pages/mapa.php
DEBUG - 2012-04-06 22:46:55 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:46:55 --> Final output sent to browser
DEBUG - 2012-04-06 22:46:55 --> Total execution time: 0.0144
DEBUG - 2012-04-06 22:47:03 --> Config Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:47:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:47:03 --> URI Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Router Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Output Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Security Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Input Class Initialized
DEBUG - 2012-04-06 22:47:03 --> XSS Filtering completed
DEBUG - 2012-04-06 22:47:03 --> XSS Filtering completed
DEBUG - 2012-04-06 22:47:03 --> XSS Filtering completed
DEBUG - 2012-04-06 22:47:03 --> XSS Filtering completed
DEBUG - 2012-04-06 22:47:03 --> XSS Filtering completed
DEBUG - 2012-04-06 22:47:03 --> XSS Filtering completed
DEBUG - 2012-04-06 22:47:03 --> XSS Filtering completed
DEBUG - 2012-04-06 22:47:03 --> XSS Filtering completed
DEBUG - 2012-04-06 22:47:03 --> CRSF cookie Set
DEBUG - 2012-04-06 22:47:03 --> CSRF token verified 
DEBUG - 2012-04-06 22:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:47:03 --> Language Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Loader Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Controller Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Model Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Model Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Session Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:47:03 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:47:03 --> Session routines successfully run
DEBUG - 2012-04-06 22:47:03 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:47:03 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:47:03 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:47:03 --> ermex/newregistry	
DEBUG - 2012-04-06 22:47:03 --> forma de registro para: 18.8563434 x -97.071827 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-06 22:47:03 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:47:03 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 22:47:03 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:47:03 --> Final output sent to browser
DEBUG - 2012-04-06 22:47:03 --> Total execution time: 0.0145
DEBUG - 2012-04-06 22:50:37 --> Config Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:50:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:50:37 --> URI Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Router Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Output Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Security Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Input Class Initialized
DEBUG - 2012-04-06 22:50:37 --> XSS Filtering completed
DEBUG - 2012-04-06 22:50:37 --> XSS Filtering completed
DEBUG - 2012-04-06 22:50:37 --> XSS Filtering completed
DEBUG - 2012-04-06 22:50:37 --> XSS Filtering completed
DEBUG - 2012-04-06 22:50:37 --> XSS Filtering completed
DEBUG - 2012-04-06 22:50:37 --> XSS Filtering completed
DEBUG - 2012-04-06 22:50:37 --> XSS Filtering completed
DEBUG - 2012-04-06 22:50:37 --> XSS Filtering completed
DEBUG - 2012-04-06 22:50:37 --> CRSF cookie Set
DEBUG - 2012-04-06 22:50:37 --> CSRF token verified 
DEBUG - 2012-04-06 22:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:50:37 --> Language Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Loader Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Controller Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Model Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Model Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Session Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:50:37 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:50:37 --> Session routines successfully run
DEBUG - 2012-04-06 22:50:37 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:50:37 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:50:37 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:50:37 --> ermex/newregistry	
DEBUG - 2012-04-06 22:50:37 --> forma de registro para: 18.8563434 x -97.071827 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-06 22:50:37 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:50:37 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 22:50:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:50:37 --> Final output sent to browser
DEBUG - 2012-04-06 22:50:37 --> Total execution time: 0.1191
DEBUG - 2012-04-06 22:51:48 --> Config Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:51:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:51:48 --> URI Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Router Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Output Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Security Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Input Class Initialized
DEBUG - 2012-04-06 22:51:48 --> XSS Filtering completed
DEBUG - 2012-04-06 22:51:48 --> XSS Filtering completed
DEBUG - 2012-04-06 22:51:48 --> XSS Filtering completed
DEBUG - 2012-04-06 22:51:48 --> XSS Filtering completed
DEBUG - 2012-04-06 22:51:48 --> XSS Filtering completed
DEBUG - 2012-04-06 22:51:48 --> XSS Filtering completed
DEBUG - 2012-04-06 22:51:48 --> XSS Filtering completed
DEBUG - 2012-04-06 22:51:48 --> XSS Filtering completed
DEBUG - 2012-04-06 22:51:48 --> CRSF cookie Set
DEBUG - 2012-04-06 22:51:48 --> CSRF token verified 
DEBUG - 2012-04-06 22:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:51:48 --> Language Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Loader Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Controller Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Model Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Model Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Session Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:51:48 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:51:48 --> Session routines successfully run
DEBUG - 2012-04-06 22:51:48 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:51:48 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:51:48 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:51:48 --> ermex/newregistry	
DEBUG - 2012-04-06 22:51:48 --> forma de registro para: 18.8563434 x -97.071827 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-06 22:51:48 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:51:48 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 22:51:48 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:51:48 --> Final output sent to browser
DEBUG - 2012-04-06 22:51:48 --> Total execution time: 0.0157
DEBUG - 2012-04-06 22:52:16 --> Config Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:52:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:52:16 --> URI Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Router Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Output Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Security Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Input Class Initialized
DEBUG - 2012-04-06 22:52:16 --> XSS Filtering completed
DEBUG - 2012-04-06 22:52:16 --> XSS Filtering completed
DEBUG - 2012-04-06 22:52:16 --> XSS Filtering completed
DEBUG - 2012-04-06 22:52:16 --> XSS Filtering completed
DEBUG - 2012-04-06 22:52:16 --> XSS Filtering completed
DEBUG - 2012-04-06 22:52:16 --> XSS Filtering completed
DEBUG - 2012-04-06 22:52:16 --> XSS Filtering completed
DEBUG - 2012-04-06 22:52:16 --> XSS Filtering completed
DEBUG - 2012-04-06 22:52:16 --> CRSF cookie Set
DEBUG - 2012-04-06 22:52:16 --> CSRF token verified 
DEBUG - 2012-04-06 22:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:52:16 --> Language Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Loader Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Controller Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Model Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Model Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Session Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:52:16 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:52:16 --> Session routines successfully run
DEBUG - 2012-04-06 22:52:16 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:52:16 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:52:16 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:52:16 --> ermex/newregistry	
DEBUG - 2012-04-06 22:52:16 --> forma de registro para: 18.8563434 x -97.071827 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-06 22:52:16 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:52:16 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 22:52:16 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:52:16 --> Final output sent to browser
DEBUG - 2012-04-06 22:52:16 --> Total execution time: 0.0211
DEBUG - 2012-04-06 22:55:30 --> Config Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:55:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:55:30 --> URI Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Router Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Output Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Security Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Input Class Initialized
DEBUG - 2012-04-06 22:55:30 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:30 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:30 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:30 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:30 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:30 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:30 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:30 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:30 --> CRSF cookie Set
DEBUG - 2012-04-06 22:55:30 --> CSRF token verified 
DEBUG - 2012-04-06 22:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:55:30 --> Language Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Loader Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Controller Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Model Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Model Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Session Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:55:30 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:55:30 --> Session routines successfully run
DEBUG - 2012-04-06 22:55:30 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:55:30 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:55:30 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:55:30 --> ermex/newregistry	
DEBUG - 2012-04-06 22:55:30 --> forma de registro para: 18.8563434 x -97.071827 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-06 22:55:30 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:55:30 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 22:55:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:55:30 --> Final output sent to browser
DEBUG - 2012-04-06 22:55:30 --> Total execution time: 0.0162
DEBUG - 2012-04-06 22:55:57 --> Config Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:55:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:55:57 --> URI Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Router Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Output Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Security Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Input Class Initialized
DEBUG - 2012-04-06 22:55:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:55:57 --> CRSF cookie Set
DEBUG - 2012-04-06 22:55:57 --> CSRF token verified 
DEBUG - 2012-04-06 22:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:55:57 --> Language Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Loader Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Controller Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Model Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Model Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Session Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:55:57 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:55:57 --> Session routines successfully run
DEBUG - 2012-04-06 22:55:57 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:55:57 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:55:57 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:55:57 --> ermex/newregistry	
DEBUG - 2012-04-06 22:55:57 --> forma de registro para: 18.8563434 x -97.071827 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-06 22:55:57 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:55:57 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 22:55:57 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:55:57 --> Final output sent to browser
DEBUG - 2012-04-06 22:55:57 --> Total execution time: 0.0156
DEBUG - 2012-04-06 22:56:13 --> Config Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:56:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:56:13 --> URI Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Router Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Output Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Security Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Input Class Initialized
DEBUG - 2012-04-06 22:56:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:13 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:13 --> CRSF cookie Set
DEBUG - 2012-04-06 22:56:13 --> CSRF token verified 
DEBUG - 2012-04-06 22:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:56:13 --> Language Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Loader Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Controller Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Model Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Model Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Session Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:56:13 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:56:13 --> Session routines successfully run
DEBUG - 2012-04-06 22:56:13 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:56:13 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:56:13 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:56:13 --> ermex/newregistry	
DEBUG - 2012-04-06 22:56:13 --> forma de registro para: 18.8563434 x -97.071827 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-06 22:56:13 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:56:13 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 22:56:13 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:56:13 --> Final output sent to browser
DEBUG - 2012-04-06 22:56:13 --> Total execution time: 0.0150
DEBUG - 2012-04-06 22:56:21 --> Config Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:56:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:56:21 --> URI Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Router Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Output Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Security Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Input Class Initialized
DEBUG - 2012-04-06 22:56:21 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:21 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:21 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:21 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:21 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:21 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:21 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:21 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:21 --> CRSF cookie Set
DEBUG - 2012-04-06 22:56:21 --> CSRF token verified 
DEBUG - 2012-04-06 22:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:56:21 --> Language Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Loader Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Controller Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Model Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Model Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Session Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:56:21 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:56:21 --> Session routines successfully run
DEBUG - 2012-04-06 22:56:21 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:56:21 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:56:21 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:56:21 --> ermex/newregistry	
DEBUG - 2012-04-06 22:56:21 --> forma de registro para: 18.8563434 x -97.071827 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-06 22:56:21 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:56:21 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 22:56:21 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:56:21 --> Final output sent to browser
DEBUG - 2012-04-06 22:56:21 --> Total execution time: 0.0188
DEBUG - 2012-04-06 22:56:44 --> Config Class Initialized
DEBUG - 2012-04-06 22:56:44 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:56:44 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:56:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:56:44 --> URI Class Initialized
DEBUG - 2012-04-06 22:56:44 --> Router Class Initialized
DEBUG - 2012-04-06 22:56:44 --> Output Class Initialized
DEBUG - 2012-04-06 22:56:44 --> Security Class Initialized
DEBUG - 2012-04-06 22:56:44 --> Input Class Initialized
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:44 --> CRSF cookie Set
DEBUG - 2012-04-06 22:56:44 --> CSRF token verified 
DEBUG - 2012-04-06 22:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:56:44 --> Language Class Initialized
DEBUG - 2012-04-06 22:56:44 --> Loader Class Initialized
DEBUG - 2012-04-06 22:56:44 --> Controller Class Initialized
DEBUG - 2012-04-06 22:56:44 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:56:44 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:56:44 --> Session Class Initialized
DEBUG - 2012-04-06 22:56:44 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:56:44 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:56:44 --> Session routines successfully run
DEBUG - 2012-04-06 22:56:44 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:56:44 --> Pages view: ermex
ERROR - 2012-04-06 22:56:44 --> 404 Page Not Found --> 
DEBUG - 2012-04-06 22:56:50 --> Config Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:56:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:56:50 --> URI Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Router Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Output Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Security Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Input Class Initialized
DEBUG - 2012-04-06 22:56:50 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:50 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:50 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:50 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:50 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:50 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:50 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:50 --> XSS Filtering completed
DEBUG - 2012-04-06 22:56:50 --> CRSF cookie Set
DEBUG - 2012-04-06 22:56:50 --> CSRF token verified 
DEBUG - 2012-04-06 22:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:56:50 --> Language Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Loader Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Controller Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Model Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Model Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Session Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:56:50 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:56:50 --> Session routines successfully run
DEBUG - 2012-04-06 22:56:50 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:56:50 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:56:50 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:56:50 --> ermex/newregistry	
DEBUG - 2012-04-06 22:56:50 --> forma de registro para: 18.8563434 x -97.071827 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-06 22:56:50 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:56:50 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 22:56:50 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:56:50 --> Final output sent to browser
DEBUG - 2012-04-06 22:56:50 --> Total execution time: 0.0167
DEBUG - 2012-04-06 22:57:57 --> Config Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Hooks Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Utf8 Class Initialized
DEBUG - 2012-04-06 22:57:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 22:57:57 --> URI Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Router Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Output Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Security Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Input Class Initialized
DEBUG - 2012-04-06 22:57:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:57:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:57:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:57:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:57:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:57:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:57:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:57:57 --> XSS Filtering completed
DEBUG - 2012-04-06 22:57:57 --> CRSF cookie Set
DEBUG - 2012-04-06 22:57:57 --> CSRF token verified 
DEBUG - 2012-04-06 22:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 22:57:57 --> Language Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Loader Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Controller Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Model Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Model Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Database Driver Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Session Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Helper loaded: string_helper
DEBUG - 2012-04-06 22:57:57 --> Encrypt Class Initialized
DEBUG - 2012-04-06 22:57:57 --> Session routines successfully run
DEBUG - 2012-04-06 22:57:57 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 22:57:57 --> Helper loaded: url_helper
DEBUG - 2012-04-06 22:57:57 --> Helper loaded: form_helper
DEBUG - 2012-04-06 22:57:57 --> ermex/newregistry	
DEBUG - 2012-04-06 22:57:57 --> forma de registro para: 18.8563434 x -97.071827 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-06 22:57:57 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 22:57:57 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 22:57:57 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 22:57:57 --> Final output sent to browser
DEBUG - 2012-04-06 22:57:57 --> Total execution time: 0.0158
DEBUG - 2012-04-06 23:21:18 --> Config Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:21:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:21:18 --> URI Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Router Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Output Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Security Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Input Class Initialized
DEBUG - 2012-04-06 23:21:18 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:18 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:18 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:18 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:18 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:18 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:18 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:18 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:18 --> CRSF cookie Set
DEBUG - 2012-04-06 23:21:18 --> CSRF token verified 
DEBUG - 2012-04-06 23:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:21:18 --> Language Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Loader Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Controller Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Model Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Model Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Database Driver Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Session Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:21:18 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:21:18 --> Session routines successfully run
DEBUG - 2012-04-06 23:21:18 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:21:18 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:21:18 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:21:18 --> ermex/newregistry	
DEBUG - 2012-04-06 23:21:18 --> forma de registro para: 18.8563434 x -97.071827 x Jardín, 94346 Orizaba, VER, México
DEBUG - 2012-04-06 23:21:18 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 23:21:18 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 23:21:18 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:21:18 --> Final output sent to browser
DEBUG - 2012-04-06 23:21:18 --> Total execution time: 0.0193
DEBUG - 2012-04-06 23:21:32 --> Config Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:21:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:21:32 --> URI Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Router Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Output Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Security Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Input Class Initialized
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> XSS Filtering completed
DEBUG - 2012-04-06 23:21:32 --> CRSF cookie Set
DEBUG - 2012-04-06 23:21:32 --> CSRF token verified 
DEBUG - 2012-04-06 23:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:21:32 --> Language Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Loader Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Controller Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Model Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Model Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Database Driver Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Session Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:21:32 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:21:32 --> Session routines successfully run
DEBUG - 2012-04-06 23:21:32 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:21:32 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:21:32 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:21:32 --> ermex/newregistrypost
DEBUG - 2012-04-06 23:21:32 --> App_model/createNewRegistry
DEBUG - 2012-04-06 23:21:32 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 23:21:32 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-06 23:21:32 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:21:32 --> Final output sent to browser
DEBUG - 2012-04-06 23:21:32 --> Total execution time: 0.0608
DEBUG - 2012-04-06 23:28:50 --> Config Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:28:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:28:50 --> URI Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Router Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Output Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Security Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Input Class Initialized
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> XSS Filtering completed
DEBUG - 2012-04-06 23:28:50 --> CRSF cookie Set
DEBUG - 2012-04-06 23:28:50 --> CSRF token verified 
DEBUG - 2012-04-06 23:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:28:50 --> Language Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Loader Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Controller Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Model Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Model Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Database Driver Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Session Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:28:50 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:28:50 --> Session routines successfully run
DEBUG - 2012-04-06 23:28:50 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:28:50 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:28:50 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:28:50 --> ermex/newregistrypost
DEBUG - 2012-04-06 23:28:50 --> App_model/createNewRegistry
DEBUG - 2012-04-06 23:28:50 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 23:28:50 --> File loaded: application/views/pages/registrook.php
DEBUG - 2012-04-06 23:28:50 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:28:50 --> Final output sent to browser
DEBUG - 2012-04-06 23:28:50 --> Total execution time: 0.0246
DEBUG - 2012-04-06 23:29:01 --> Config Class Initialized
DEBUG - 2012-04-06 23:29:01 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:29:01 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:29:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:29:01 --> URI Class Initialized
DEBUG - 2012-04-06 23:29:01 --> Router Class Initialized
DEBUG - 2012-04-06 23:29:01 --> Output Class Initialized
DEBUG - 2012-04-06 23:29:01 --> Security Class Initialized
DEBUG - 2012-04-06 23:29:01 --> Input Class Initialized
DEBUG - 2012-04-06 23:29:01 --> XSS Filtering completed
DEBUG - 2012-04-06 23:29:01 --> XSS Filtering completed
DEBUG - 2012-04-06 23:29:01 --> XSS Filtering completed
DEBUG - 2012-04-06 23:29:01 --> CRSF cookie Set
DEBUG - 2012-04-06 23:29:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:29:01 --> Language Class Initialized
DEBUG - 2012-04-06 23:29:01 --> Loader Class Initialized
DEBUG - 2012-04-06 23:29:01 --> Controller Class Initialized
DEBUG - 2012-04-06 23:29:01 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:29:01 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:29:01 --> Session Class Initialized
DEBUG - 2012-04-06 23:29:01 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:29:01 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:29:01 --> Session routines successfully run
DEBUG - 2012-04-06 23:29:01 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:29:01 --> Pages view: mainmenu
DEBUG - 2012-04-06 23:29:01 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 23:29:01 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-06 23:29:01 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:29:01 --> Final output sent to browser
DEBUG - 2012-04-06 23:29:01 --> Total execution time: 0.0116
DEBUG - 2012-04-06 23:29:08 --> Config Class Initialized
DEBUG - 2012-04-06 23:29:08 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:29:08 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:29:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:29:08 --> URI Class Initialized
DEBUG - 2012-04-06 23:29:08 --> Router Class Initialized
DEBUG - 2012-04-06 23:29:08 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:29:08 --> Output Class Initialized
DEBUG - 2012-04-06 23:29:08 --> Security Class Initialized
DEBUG - 2012-04-06 23:29:08 --> Input Class Initialized
DEBUG - 2012-04-06 23:29:08 --> XSS Filtering completed
DEBUG - 2012-04-06 23:29:08 --> XSS Filtering completed
DEBUG - 2012-04-06 23:29:08 --> XSS Filtering completed
DEBUG - 2012-04-06 23:29:08 --> CRSF cookie Set
DEBUG - 2012-04-06 23:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:29:08 --> Language Class Initialized
DEBUG - 2012-04-06 23:29:08 --> Loader Class Initialized
DEBUG - 2012-04-06 23:29:08 --> Controller Class Initialized
DEBUG - 2012-04-06 23:29:08 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:29:08 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:29:08 --> Session Class Initialized
DEBUG - 2012-04-06 23:29:08 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:29:08 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:29:08 --> Session routines successfully run
DEBUG - 2012-04-06 23:29:08 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:29:08 --> Pages view: home
DEBUG - 2012-04-06 23:29:08 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:29:08 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:29:08 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:29:08 --> Final output sent to browser
DEBUG - 2012-04-06 23:29:08 --> Total execution time: 0.0101
DEBUG - 2012-04-06 23:29:43 --> Config Class Initialized
DEBUG - 2012-04-06 23:29:43 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:29:43 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:29:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:29:43 --> URI Class Initialized
DEBUG - 2012-04-06 23:29:43 --> Router Class Initialized
DEBUG - 2012-04-06 23:29:43 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:29:43 --> Output Class Initialized
DEBUG - 2012-04-06 23:29:43 --> Security Class Initialized
DEBUG - 2012-04-06 23:29:43 --> Input Class Initialized
DEBUG - 2012-04-06 23:29:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:29:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:29:43 --> CRSF cookie Set
DEBUG - 2012-04-06 23:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:29:43 --> Language Class Initialized
DEBUG - 2012-04-06 23:29:43 --> Loader Class Initialized
DEBUG - 2012-04-06 23:29:43 --> Controller Class Initialized
DEBUG - 2012-04-06 23:29:43 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:29:43 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:29:43 --> Session Class Initialized
DEBUG - 2012-04-06 23:29:43 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:29:43 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:29:43 --> A session cookie was not found.
DEBUG - 2012-04-06 23:29:43 --> Session routines successfully run
DEBUG - 2012-04-06 23:29:43 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:29:43 --> Pages view: home
DEBUG - 2012-04-06 23:29:43 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:29:43 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:29:43 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:29:43 --> Final output sent to browser
DEBUG - 2012-04-06 23:29:43 --> Total execution time: 0.0090
DEBUG - 2012-04-06 23:31:38 --> Config Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:31:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:31:38 --> URI Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Router Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Output Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Security Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Input Class Initialized
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> CRSF cookie Set
DEBUG - 2012-04-06 23:31:38 --> CSRF token verified 
DEBUG - 2012-04-06 23:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:31:38 --> Language Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Loader Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Controller Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Model Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Model Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Database Driver Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Session Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:31:38 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:31:38 --> A session cookie was not found.
DEBUG - 2012-04-06 23:31:38 --> Session routines successfully run
DEBUG - 2012-04-06 23:31:38 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:31:38 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:31:38 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:31:38 --> ermex/newregistrypost
ERROR - 2012-04-06 23:31:38 --> *No se encontró sesión
DEBUG - 2012-04-06 23:31:38 --> Config Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:31:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:31:38 --> URI Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Router Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Output Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Security Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Input Class Initialized
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> XSS Filtering completed
DEBUG - 2012-04-06 23:31:38 --> CRSF cookie Set
DEBUG - 2012-04-06 23:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:31:38 --> Language Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Loader Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Controller Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:31:38 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:31:38 --> Session Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:31:38 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:31:38 --> Session routines successfully run
DEBUG - 2012-04-06 23:31:38 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:31:38 --> Pages view: loginerror
DEBUG - 2012-04-06 23:31:38 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:31:38 --> File loaded: application/views/pages/loginerror.php
DEBUG - 2012-04-06 23:31:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:31:38 --> Final output sent to browser
DEBUG - 2012-04-06 23:31:38 --> Total execution time: 0.0096
DEBUG - 2012-04-06 23:34:58 --> Config Class Initialized
DEBUG - 2012-04-06 23:34:59 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:34:59 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:34:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:34:59 --> URI Class Initialized
DEBUG - 2012-04-06 23:34:59 --> Router Class Initialized
DEBUG - 2012-04-06 23:34:59 --> Output Class Initialized
DEBUG - 2012-04-06 23:34:59 --> Security Class Initialized
DEBUG - 2012-04-06 23:34:59 --> Input Class Initialized
DEBUG - 2012-04-06 23:34:59 --> XSS Filtering completed
DEBUG - 2012-04-06 23:34:59 --> XSS Filtering completed
DEBUG - 2012-04-06 23:34:59 --> CRSF cookie Set
DEBUG - 2012-04-06 23:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:34:59 --> Language Class Initialized
DEBUG - 2012-04-06 23:34:59 --> Loader Class Initialized
DEBUG - 2012-04-06 23:34:59 --> Controller Class Initialized
DEBUG - 2012-04-06 23:34:59 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:34:59 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:34:59 --> Session Class Initialized
DEBUG - 2012-04-06 23:34:59 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:34:59 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:34:59 --> A session cookie was not found.
DEBUG - 2012-04-06 23:34:59 --> Session routines successfully run
DEBUG - 2012-04-06 23:34:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:34:59 --> Pages view: loginerror
DEBUG - 2012-04-06 23:34:59 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:34:59 --> File loaded: application/views/pages/loginerror.php
DEBUG - 2012-04-06 23:34:59 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:34:59 --> Final output sent to browser
DEBUG - 2012-04-06 23:34:59 --> Total execution time: 0.0391
DEBUG - 2012-04-06 23:35:52 --> Config Class Initialized
DEBUG - 2012-04-06 23:35:52 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:35:52 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:35:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:35:52 --> URI Class Initialized
DEBUG - 2012-04-06 23:35:52 --> Router Class Initialized
DEBUG - 2012-04-06 23:35:52 --> Output Class Initialized
DEBUG - 2012-04-06 23:35:52 --> Security Class Initialized
DEBUG - 2012-04-06 23:35:52 --> Input Class Initialized
DEBUG - 2012-04-06 23:35:52 --> XSS Filtering completed
DEBUG - 2012-04-06 23:35:52 --> XSS Filtering completed
DEBUG - 2012-04-06 23:35:52 --> CRSF cookie Set
DEBUG - 2012-04-06 23:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:35:52 --> Language Class Initialized
DEBUG - 2012-04-06 23:35:52 --> Loader Class Initialized
DEBUG - 2012-04-06 23:35:52 --> Controller Class Initialized
DEBUG - 2012-04-06 23:35:52 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:35:52 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:35:52 --> Session Class Initialized
DEBUG - 2012-04-06 23:35:52 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:35:52 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:35:52 --> A session cookie was not found.
DEBUG - 2012-04-06 23:35:52 --> Session routines successfully run
DEBUG - 2012-04-06 23:35:52 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:35:52 --> Pages view: loginerror
DEBUG - 2012-04-06 23:35:52 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:35:52 --> File loaded: application/views/pages/loginerror.php
DEBUG - 2012-04-06 23:35:52 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:35:52 --> Final output sent to browser
DEBUG - 2012-04-06 23:35:52 --> Total execution time: 0.0120
DEBUG - 2012-04-06 23:36:01 --> Config Class Initialized
DEBUG - 2012-04-06 23:36:01 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:36:01 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:36:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:36:01 --> URI Class Initialized
DEBUG - 2012-04-06 23:36:01 --> Router Class Initialized
DEBUG - 2012-04-06 23:36:01 --> Output Class Initialized
DEBUG - 2012-04-06 23:36:01 --> Security Class Initialized
DEBUG - 2012-04-06 23:36:01 --> Input Class Initialized
DEBUG - 2012-04-06 23:36:01 --> XSS Filtering completed
DEBUG - 2012-04-06 23:36:01 --> XSS Filtering completed
DEBUG - 2012-04-06 23:36:01 --> CRSF cookie Set
DEBUG - 2012-04-06 23:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:36:01 --> Language Class Initialized
DEBUG - 2012-04-06 23:36:01 --> Loader Class Initialized
DEBUG - 2012-04-06 23:36:01 --> Controller Class Initialized
DEBUG - 2012-04-06 23:36:01 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:36:01 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:36:01 --> Session Class Initialized
DEBUG - 2012-04-06 23:36:01 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:36:01 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:36:01 --> A session cookie was not found.
DEBUG - 2012-04-06 23:36:01 --> Session routines successfully run
DEBUG - 2012-04-06 23:36:01 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:36:01 --> Pages view: loginerror
DEBUG - 2012-04-06 23:36:01 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:36:01 --> File loaded: application/views/pages/loginerror.php
DEBUG - 2012-04-06 23:36:01 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:36:01 --> Final output sent to browser
DEBUG - 2012-04-06 23:36:01 --> Total execution time: 0.0092
DEBUG - 2012-04-06 23:36:07 --> Config Class Initialized
DEBUG - 2012-04-06 23:36:07 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:36:07 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:36:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:36:07 --> URI Class Initialized
DEBUG - 2012-04-06 23:36:07 --> Router Class Initialized
DEBUG - 2012-04-06 23:36:07 --> Output Class Initialized
DEBUG - 2012-04-06 23:36:07 --> Security Class Initialized
DEBUG - 2012-04-06 23:36:07 --> Input Class Initialized
DEBUG - 2012-04-06 23:36:07 --> XSS Filtering completed
DEBUG - 2012-04-06 23:36:07 --> XSS Filtering completed
DEBUG - 2012-04-06 23:36:07 --> CRSF cookie Set
DEBUG - 2012-04-06 23:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:36:07 --> Language Class Initialized
DEBUG - 2012-04-06 23:36:07 --> Loader Class Initialized
DEBUG - 2012-04-06 23:36:07 --> Controller Class Initialized
DEBUG - 2012-04-06 23:36:07 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:36:07 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:36:07 --> Session Class Initialized
DEBUG - 2012-04-06 23:36:07 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:36:07 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:36:07 --> A session cookie was not found.
DEBUG - 2012-04-06 23:36:07 --> Session routines successfully run
DEBUG - 2012-04-06 23:36:07 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:36:07 --> Pages view: loginerror
DEBUG - 2012-04-06 23:36:07 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:36:07 --> File loaded: application/views/pages/loginerror.php
DEBUG - 2012-04-06 23:36:07 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:36:07 --> Final output sent to browser
DEBUG - 2012-04-06 23:36:07 --> Total execution time: 0.0095
DEBUG - 2012-04-06 23:36:15 --> Config Class Initialized
DEBUG - 2012-04-06 23:36:15 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:36:15 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:36:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:36:15 --> URI Class Initialized
DEBUG - 2012-04-06 23:36:15 --> Router Class Initialized
DEBUG - 2012-04-06 23:36:15 --> Output Class Initialized
DEBUG - 2012-04-06 23:36:15 --> Security Class Initialized
DEBUG - 2012-04-06 23:36:15 --> Input Class Initialized
DEBUG - 2012-04-06 23:36:15 --> XSS Filtering completed
DEBUG - 2012-04-06 23:36:15 --> XSS Filtering completed
DEBUG - 2012-04-06 23:36:15 --> CRSF cookie Set
DEBUG - 2012-04-06 23:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:36:15 --> Language Class Initialized
DEBUG - 2012-04-06 23:36:15 --> Loader Class Initialized
DEBUG - 2012-04-06 23:36:15 --> Controller Class Initialized
DEBUG - 2012-04-06 23:36:15 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:36:15 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:36:15 --> Session Class Initialized
DEBUG - 2012-04-06 23:36:15 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:36:15 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:36:15 --> A session cookie was not found.
DEBUG - 2012-04-06 23:36:15 --> Session routines successfully run
DEBUG - 2012-04-06 23:36:15 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:36:15 --> Pages view: loginerror
DEBUG - 2012-04-06 23:36:15 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:36:15 --> File loaded: application/views/pages/loginerror.php
DEBUG - 2012-04-06 23:36:15 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:36:15 --> Final output sent to browser
DEBUG - 2012-04-06 23:36:15 --> Total execution time: 0.0107
DEBUG - 2012-04-06 23:36:21 --> Config Class Initialized
DEBUG - 2012-04-06 23:36:21 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:36:21 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:36:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:36:21 --> URI Class Initialized
DEBUG - 2012-04-06 23:36:21 --> Router Class Initialized
DEBUG - 2012-04-06 23:36:21 --> Output Class Initialized
DEBUG - 2012-04-06 23:36:21 --> Security Class Initialized
DEBUG - 2012-04-06 23:36:21 --> Input Class Initialized
DEBUG - 2012-04-06 23:36:21 --> XSS Filtering completed
DEBUG - 2012-04-06 23:36:21 --> XSS Filtering completed
DEBUG - 2012-04-06 23:36:21 --> CRSF cookie Set
DEBUG - 2012-04-06 23:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:36:21 --> Language Class Initialized
DEBUG - 2012-04-06 23:36:21 --> Loader Class Initialized
DEBUG - 2012-04-06 23:36:21 --> Controller Class Initialized
DEBUG - 2012-04-06 23:36:21 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:36:21 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:36:21 --> Session Class Initialized
DEBUG - 2012-04-06 23:36:21 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:36:21 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:36:21 --> A session cookie was not found.
DEBUG - 2012-04-06 23:36:21 --> Session routines successfully run
DEBUG - 2012-04-06 23:36:21 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:36:21 --> Pages view: loginerror
DEBUG - 2012-04-06 23:36:21 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:36:21 --> File loaded: application/views/pages/loginerror.php
DEBUG - 2012-04-06 23:36:21 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:36:21 --> Final output sent to browser
DEBUG - 2012-04-06 23:36:21 --> Total execution time: 0.0114
DEBUG - 2012-04-06 23:36:25 --> Config Class Initialized
DEBUG - 2012-04-06 23:36:25 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:36:25 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:36:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:36:25 --> URI Class Initialized
DEBUG - 2012-04-06 23:36:25 --> Router Class Initialized
DEBUG - 2012-04-06 23:36:25 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:36:25 --> Output Class Initialized
DEBUG - 2012-04-06 23:36:25 --> Security Class Initialized
DEBUG - 2012-04-06 23:36:25 --> Input Class Initialized
DEBUG - 2012-04-06 23:36:25 --> XSS Filtering completed
DEBUG - 2012-04-06 23:36:25 --> XSS Filtering completed
DEBUG - 2012-04-06 23:36:25 --> CRSF cookie Set
DEBUG - 2012-04-06 23:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:36:25 --> Language Class Initialized
DEBUG - 2012-04-06 23:36:25 --> Loader Class Initialized
DEBUG - 2012-04-06 23:36:25 --> Controller Class Initialized
DEBUG - 2012-04-06 23:36:25 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:36:25 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:36:25 --> Session Class Initialized
DEBUG - 2012-04-06 23:36:25 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:36:25 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:36:25 --> A session cookie was not found.
DEBUG - 2012-04-06 23:36:25 --> Session routines successfully run
DEBUG - 2012-04-06 23:36:25 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:36:25 --> Pages view: home
DEBUG - 2012-04-06 23:36:25 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:36:25 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:36:25 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:36:25 --> Final output sent to browser
DEBUG - 2012-04-06 23:36:25 --> Total execution time: 0.0094
DEBUG - 2012-04-06 23:41:09 --> Config Class Initialized
DEBUG - 2012-04-06 23:41:09 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:41:09 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:41:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:41:09 --> URI Class Initialized
DEBUG - 2012-04-06 23:41:09 --> Router Class Initialized
DEBUG - 2012-04-06 23:41:09 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:41:09 --> Output Class Initialized
DEBUG - 2012-04-06 23:41:09 --> Security Class Initialized
DEBUG - 2012-04-06 23:41:09 --> Input Class Initialized
DEBUG - 2012-04-06 23:41:09 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:09 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:09 --> CRSF cookie Set
DEBUG - 2012-04-06 23:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:41:09 --> Language Class Initialized
DEBUG - 2012-04-06 23:41:09 --> Loader Class Initialized
DEBUG - 2012-04-06 23:41:09 --> Controller Class Initialized
DEBUG - 2012-04-06 23:41:09 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:41:09 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:41:09 --> Session Class Initialized
DEBUG - 2012-04-06 23:41:09 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:41:09 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:41:09 --> A session cookie was not found.
DEBUG - 2012-04-06 23:41:09 --> Session routines successfully run
DEBUG - 2012-04-06 23:41:09 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:41:09 --> Pages view: home
ERROR - 2012-04-06 23:41:09 --> Severity: Notice  --> Undefined index: USERNAME /usr/local/zend/apache2/htdocs/ermex/ermx/application/controllers/pages.php 26
DEBUG - 2012-04-06 23:41:09 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:41:09 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:41:09 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:41:09 --> Final output sent to browser
DEBUG - 2012-04-06 23:41:09 --> Total execution time: 0.0267
DEBUG - 2012-04-06 23:41:43 --> Config Class Initialized
DEBUG - 2012-04-06 23:41:43 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:41:43 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:41:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:41:43 --> URI Class Initialized
DEBUG - 2012-04-06 23:41:43 --> Router Class Initialized
DEBUG - 2012-04-06 23:41:43 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:41:43 --> Output Class Initialized
DEBUG - 2012-04-06 23:41:43 --> Security Class Initialized
DEBUG - 2012-04-06 23:41:43 --> Input Class Initialized
DEBUG - 2012-04-06 23:41:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:43 --> CRSF cookie Set
DEBUG - 2012-04-06 23:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:41:43 --> Language Class Initialized
DEBUG - 2012-04-06 23:41:43 --> Loader Class Initialized
DEBUG - 2012-04-06 23:41:43 --> Controller Class Initialized
DEBUG - 2012-04-06 23:41:43 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:41:43 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:41:43 --> Session Class Initialized
DEBUG - 2012-04-06 23:41:43 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:41:43 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:41:43 --> Session routines successfully run
DEBUG - 2012-04-06 23:41:43 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:41:43 --> Pages view: home
DEBUG - 2012-04-06 23:41:43 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:41:43 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:41:43 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:41:43 --> Final output sent to browser
DEBUG - 2012-04-06 23:41:43 --> Total execution time: 0.0130
DEBUG - 2012-04-06 23:41:45 --> Config Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:41:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:41:45 --> URI Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Router Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Output Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Security Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Input Class Initialized
DEBUG - 2012-04-06 23:41:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:45 --> CRSF cookie Set
DEBUG - 2012-04-06 23:41:45 --> CSRF token verified 
DEBUG - 2012-04-06 23:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:41:45 --> Language Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Loader Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Controller Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Model Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Model Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Database Driver Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Session Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:41:45 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Session routines successfully run
DEBUG - 2012-04-06 23:41:45 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:41:45 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:41:45 --> *Security/login
DEBUG - 2012-04-06 23:41:45 --> App_model login
DEBUG - 2012-04-06 23:41:45 --> **Found user**
DEBUG - 2012-04-06 23:41:45 --> Config Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:41:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:41:45 --> URI Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Router Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Output Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Security Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Input Class Initialized
DEBUG - 2012-04-06 23:41:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:45 --> CRSF cookie Set
DEBUG - 2012-04-06 23:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:41:45 --> Language Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Loader Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Controller Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:41:45 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:41:45 --> Session Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:41:45 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:41:45 --> Session routines successfully run
DEBUG - 2012-04-06 23:41:45 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:41:45 --> Pages view: mainmenu
DEBUG - 2012-04-06 23:41:45 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 23:41:45 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-06 23:41:45 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:41:45 --> Final output sent to browser
DEBUG - 2012-04-06 23:41:45 --> Total execution time: 0.0089
DEBUG - 2012-04-06 23:41:48 --> Config Class Initialized
DEBUG - 2012-04-06 23:41:48 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:41:48 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:41:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:41:48 --> URI Class Initialized
DEBUG - 2012-04-06 23:41:48 --> Router Class Initialized
DEBUG - 2012-04-06 23:41:48 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:41:48 --> Output Class Initialized
DEBUG - 2012-04-06 23:41:48 --> Security Class Initialized
DEBUG - 2012-04-06 23:41:48 --> Input Class Initialized
DEBUG - 2012-04-06 23:41:48 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:48 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:48 --> XSS Filtering completed
DEBUG - 2012-04-06 23:41:48 --> CRSF cookie Set
DEBUG - 2012-04-06 23:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:41:48 --> Language Class Initialized
DEBUG - 2012-04-06 23:41:48 --> Loader Class Initialized
DEBUG - 2012-04-06 23:41:48 --> Controller Class Initialized
DEBUG - 2012-04-06 23:41:48 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:41:48 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:41:48 --> Session Class Initialized
DEBUG - 2012-04-06 23:41:48 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:41:48 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:41:48 --> Session routines successfully run
DEBUG - 2012-04-06 23:41:48 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:41:48 --> Pages view: home
DEBUG - 2012-04-06 23:41:48 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:41:48 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:41:48 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:41:48 --> Final output sent to browser
DEBUG - 2012-04-06 23:41:48 --> Total execution time: 0.0114
DEBUG - 2012-04-06 23:42:00 --> Config Class Initialized
DEBUG - 2012-04-06 23:42:00 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:42:00 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:42:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:42:00 --> URI Class Initialized
DEBUG - 2012-04-06 23:42:00 --> Router Class Initialized
DEBUG - 2012-04-06 23:42:00 --> Output Class Initialized
DEBUG - 2012-04-06 23:42:00 --> Security Class Initialized
DEBUG - 2012-04-06 23:42:00 --> Input Class Initialized
DEBUG - 2012-04-06 23:42:00 --> XSS Filtering completed
DEBUG - 2012-04-06 23:42:00 --> XSS Filtering completed
DEBUG - 2012-04-06 23:42:00 --> XSS Filtering completed
DEBUG - 2012-04-06 23:42:00 --> CRSF cookie Set
DEBUG - 2012-04-06 23:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:42:00 --> Language Class Initialized
DEBUG - 2012-04-06 23:42:00 --> Loader Class Initialized
DEBUG - 2012-04-06 23:42:00 --> Controller Class Initialized
DEBUG - 2012-04-06 23:42:00 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:42:00 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:42:00 --> Session Class Initialized
DEBUG - 2012-04-06 23:42:00 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:42:00 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:42:00 --> Session routines successfully run
DEBUG - 2012-04-06 23:42:00 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:42:00 --> Pages view: mainmenu
DEBUG - 2012-04-06 23:42:00 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 23:42:00 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-06 23:42:00 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:42:00 --> Final output sent to browser
DEBUG - 2012-04-06 23:42:00 --> Total execution time: 0.0107
DEBUG - 2012-04-06 23:42:51 --> Config Class Initialized
DEBUG - 2012-04-06 23:42:51 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:42:51 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:42:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:42:51 --> URI Class Initialized
DEBUG - 2012-04-06 23:42:51 --> Router Class Initialized
DEBUG - 2012-04-06 23:42:51 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:42:51 --> Output Class Initialized
DEBUG - 2012-04-06 23:42:51 --> Security Class Initialized
DEBUG - 2012-04-06 23:42:51 --> Input Class Initialized
DEBUG - 2012-04-06 23:42:51 --> XSS Filtering completed
DEBUG - 2012-04-06 23:42:51 --> XSS Filtering completed
DEBUG - 2012-04-06 23:42:51 --> XSS Filtering completed
DEBUG - 2012-04-06 23:42:51 --> CRSF cookie Set
DEBUG - 2012-04-06 23:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:42:51 --> Language Class Initialized
DEBUG - 2012-04-06 23:42:51 --> Loader Class Initialized
DEBUG - 2012-04-06 23:42:51 --> Controller Class Initialized
DEBUG - 2012-04-06 23:42:51 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:42:51 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:42:51 --> Session Class Initialized
DEBUG - 2012-04-06 23:42:51 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:42:51 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:42:51 --> Session routines successfully run
DEBUG - 2012-04-06 23:42:51 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:42:51 --> Pages view: home
DEBUG - 2012-04-06 23:42:51 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:42:51 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:42:51 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:42:51 --> Final output sent to browser
DEBUG - 2012-04-06 23:42:51 --> Total execution time: 0.0146
DEBUG - 2012-04-06 23:43:41 --> Config Class Initialized
DEBUG - 2012-04-06 23:43:41 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:43:41 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:43:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:43:41 --> URI Class Initialized
DEBUG - 2012-04-06 23:43:41 --> Router Class Initialized
DEBUG - 2012-04-06 23:43:41 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:43:41 --> Output Class Initialized
DEBUG - 2012-04-06 23:43:41 --> Security Class Initialized
DEBUG - 2012-04-06 23:43:41 --> Input Class Initialized
DEBUG - 2012-04-06 23:43:41 --> XSS Filtering completed
DEBUG - 2012-04-06 23:43:41 --> XSS Filtering completed
DEBUG - 2012-04-06 23:43:41 --> XSS Filtering completed
DEBUG - 2012-04-06 23:43:41 --> CRSF cookie Set
DEBUG - 2012-04-06 23:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:43:41 --> Language Class Initialized
DEBUG - 2012-04-06 23:43:41 --> Loader Class Initialized
DEBUG - 2012-04-06 23:43:41 --> Controller Class Initialized
DEBUG - 2012-04-06 23:43:41 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:43:41 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:43:41 --> Session Class Initialized
DEBUG - 2012-04-06 23:43:41 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:43:41 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:43:41 --> Session routines successfully run
DEBUG - 2012-04-06 23:43:41 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:43:41 --> Pages view: home
DEBUG - 2012-04-06 23:43:41 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:43:41 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:43:41 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:43:41 --> Final output sent to browser
DEBUG - 2012-04-06 23:43:41 --> Total execution time: 0.0106
DEBUG - 2012-04-06 23:45:00 --> Config Class Initialized
DEBUG - 2012-04-06 23:45:00 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:45:00 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:45:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:45:00 --> URI Class Initialized
DEBUG - 2012-04-06 23:45:00 --> Router Class Initialized
DEBUG - 2012-04-06 23:45:00 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:45:00 --> Output Class Initialized
DEBUG - 2012-04-06 23:45:00 --> Security Class Initialized
DEBUG - 2012-04-06 23:45:00 --> Input Class Initialized
DEBUG - 2012-04-06 23:45:00 --> XSS Filtering completed
DEBUG - 2012-04-06 23:45:00 --> XSS Filtering completed
DEBUG - 2012-04-06 23:45:00 --> XSS Filtering completed
DEBUG - 2012-04-06 23:45:00 --> CRSF cookie Set
DEBUG - 2012-04-06 23:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:45:00 --> Language Class Initialized
DEBUG - 2012-04-06 23:45:00 --> Loader Class Initialized
DEBUG - 2012-04-06 23:45:00 --> Controller Class Initialized
DEBUG - 2012-04-06 23:45:00 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:45:00 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:45:00 --> Session Class Initialized
DEBUG - 2012-04-06 23:45:00 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:45:00 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:45:00 --> Session routines successfully run
DEBUG - 2012-04-06 23:45:00 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:45:00 --> Pages view: home
DEBUG - 2012-04-06 23:45:00 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:45:00 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:45:00 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:45:00 --> Final output sent to browser
DEBUG - 2012-04-06 23:45:00 --> Total execution time: 0.0104
DEBUG - 2012-04-06 23:45:55 --> Config Class Initialized
DEBUG - 2012-04-06 23:45:55 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:45:55 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:45:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:45:55 --> URI Class Initialized
DEBUG - 2012-04-06 23:45:55 --> Router Class Initialized
DEBUG - 2012-04-06 23:45:55 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:45:55 --> Output Class Initialized
DEBUG - 2012-04-06 23:45:55 --> Security Class Initialized
DEBUG - 2012-04-06 23:45:55 --> Input Class Initialized
DEBUG - 2012-04-06 23:45:55 --> XSS Filtering completed
DEBUG - 2012-04-06 23:45:55 --> XSS Filtering completed
DEBUG - 2012-04-06 23:45:55 --> XSS Filtering completed
DEBUG - 2012-04-06 23:45:55 --> CRSF cookie Set
DEBUG - 2012-04-06 23:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:45:55 --> Language Class Initialized
DEBUG - 2012-04-06 23:45:55 --> Loader Class Initialized
DEBUG - 2012-04-06 23:45:55 --> Controller Class Initialized
DEBUG - 2012-04-06 23:45:55 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:45:55 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:45:55 --> Session Class Initialized
DEBUG - 2012-04-06 23:45:55 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:45:55 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:45:55 --> Session routines successfully run
DEBUG - 2012-04-06 23:45:55 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:45:55 --> Pages view: home
DEBUG - 2012-04-06 23:45:55 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:45:55 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:45:55 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:45:55 --> Final output sent to browser
DEBUG - 2012-04-06 23:45:55 --> Total execution time: 0.0102
DEBUG - 2012-04-06 23:46:23 --> Config Class Initialized
DEBUG - 2012-04-06 23:46:23 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:46:23 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:46:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:46:23 --> URI Class Initialized
DEBUG - 2012-04-06 23:46:23 --> Router Class Initialized
DEBUG - 2012-04-06 23:46:23 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:46:23 --> Output Class Initialized
DEBUG - 2012-04-06 23:46:23 --> Security Class Initialized
DEBUG - 2012-04-06 23:46:23 --> Input Class Initialized
DEBUG - 2012-04-06 23:46:23 --> XSS Filtering completed
DEBUG - 2012-04-06 23:46:23 --> XSS Filtering completed
DEBUG - 2012-04-06 23:46:23 --> XSS Filtering completed
DEBUG - 2012-04-06 23:46:23 --> CRSF cookie Set
DEBUG - 2012-04-06 23:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:46:23 --> Language Class Initialized
DEBUG - 2012-04-06 23:46:23 --> Loader Class Initialized
DEBUG - 2012-04-06 23:46:23 --> Controller Class Initialized
DEBUG - 2012-04-06 23:46:23 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:46:23 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:46:23 --> Session Class Initialized
DEBUG - 2012-04-06 23:46:23 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:46:23 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:46:23 --> Session routines successfully run
DEBUG - 2012-04-06 23:46:23 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:46:23 --> Pages view: home
DEBUG - 2012-04-06 23:46:23 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:46:23 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:46:23 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:46:23 --> Final output sent to browser
DEBUG - 2012-04-06 23:46:23 --> Total execution time: 0.0114
DEBUG - 2012-04-06 23:46:26 --> Config Class Initialized
DEBUG - 2012-04-06 23:46:26 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:46:26 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:46:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:46:26 --> URI Class Initialized
DEBUG - 2012-04-06 23:46:26 --> Router Class Initialized
DEBUG - 2012-04-06 23:46:26 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:46:26 --> Output Class Initialized
DEBUG - 2012-04-06 23:46:26 --> Security Class Initialized
DEBUG - 2012-04-06 23:46:26 --> Input Class Initialized
DEBUG - 2012-04-06 23:46:26 --> XSS Filtering completed
DEBUG - 2012-04-06 23:46:26 --> XSS Filtering completed
DEBUG - 2012-04-06 23:46:26 --> XSS Filtering completed
DEBUG - 2012-04-06 23:46:26 --> CRSF cookie Set
DEBUG - 2012-04-06 23:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:46:26 --> Language Class Initialized
DEBUG - 2012-04-06 23:46:26 --> Loader Class Initialized
DEBUG - 2012-04-06 23:46:26 --> Controller Class Initialized
DEBUG - 2012-04-06 23:46:26 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:46:26 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:46:26 --> Session Class Initialized
DEBUG - 2012-04-06 23:46:26 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:46:26 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:46:26 --> Session routines successfully run
DEBUG - 2012-04-06 23:46:26 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:46:26 --> Pages view: home
DEBUG - 2012-04-06 23:46:26 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:46:26 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:46:26 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:46:26 --> Final output sent to browser
DEBUG - 2012-04-06 23:46:26 --> Total execution time: 0.0123
DEBUG - 2012-04-06 23:46:37 --> Config Class Initialized
DEBUG - 2012-04-06 23:46:37 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:46:37 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:46:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:46:37 --> URI Class Initialized
DEBUG - 2012-04-06 23:46:37 --> Router Class Initialized
DEBUG - 2012-04-06 23:46:37 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:46:37 --> Output Class Initialized
DEBUG - 2012-04-06 23:46:37 --> Security Class Initialized
DEBUG - 2012-04-06 23:46:37 --> Input Class Initialized
DEBUG - 2012-04-06 23:46:37 --> XSS Filtering completed
DEBUG - 2012-04-06 23:46:37 --> XSS Filtering completed
DEBUG - 2012-04-06 23:46:37 --> XSS Filtering completed
DEBUG - 2012-04-06 23:46:37 --> CRSF cookie Set
DEBUG - 2012-04-06 23:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:46:37 --> Language Class Initialized
DEBUG - 2012-04-06 23:46:37 --> Loader Class Initialized
DEBUG - 2012-04-06 23:46:37 --> Controller Class Initialized
DEBUG - 2012-04-06 23:46:37 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:46:37 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:46:37 --> Session Class Initialized
DEBUG - 2012-04-06 23:46:37 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:46:37 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:46:37 --> Session routines successfully run
DEBUG - 2012-04-06 23:46:37 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:46:37 --> Pages view: home
DEBUG - 2012-04-06 23:46:37 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:46:37 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:46:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:46:37 --> Final output sent to browser
DEBUG - 2012-04-06 23:46:37 --> Total execution time: 0.0108
DEBUG - 2012-04-06 23:47:06 --> Config Class Initialized
DEBUG - 2012-04-06 23:47:06 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:47:06 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:47:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:47:06 --> URI Class Initialized
DEBUG - 2012-04-06 23:47:06 --> Router Class Initialized
DEBUG - 2012-04-06 23:47:06 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:47:06 --> Output Class Initialized
DEBUG - 2012-04-06 23:47:06 --> Security Class Initialized
DEBUG - 2012-04-06 23:47:06 --> Input Class Initialized
DEBUG - 2012-04-06 23:47:06 --> XSS Filtering completed
DEBUG - 2012-04-06 23:47:06 --> XSS Filtering completed
DEBUG - 2012-04-06 23:47:06 --> XSS Filtering completed
DEBUG - 2012-04-06 23:47:06 --> CRSF cookie Set
DEBUG - 2012-04-06 23:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:47:06 --> Language Class Initialized
DEBUG - 2012-04-06 23:47:06 --> Loader Class Initialized
DEBUG - 2012-04-06 23:47:06 --> Controller Class Initialized
DEBUG - 2012-04-06 23:47:06 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:47:06 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:47:06 --> Session Class Initialized
DEBUG - 2012-04-06 23:47:06 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:47:06 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:47:06 --> Session routines successfully run
DEBUG - 2012-04-06 23:47:06 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:47:06 --> Pages view: home
DEBUG - 2012-04-06 23:47:06 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:47:06 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:47:06 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:47:06 --> Final output sent to browser
DEBUG - 2012-04-06 23:47:06 --> Total execution time: 0.0127
DEBUG - 2012-04-06 23:50:11 --> Config Class Initialized
DEBUG - 2012-04-06 23:50:11 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:50:11 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:50:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:50:11 --> URI Class Initialized
DEBUG - 2012-04-06 23:50:11 --> Router Class Initialized
DEBUG - 2012-04-06 23:50:11 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:50:11 --> Output Class Initialized
DEBUG - 2012-04-06 23:50:11 --> Security Class Initialized
DEBUG - 2012-04-06 23:50:11 --> Input Class Initialized
DEBUG - 2012-04-06 23:50:11 --> XSS Filtering completed
DEBUG - 2012-04-06 23:50:11 --> XSS Filtering completed
DEBUG - 2012-04-06 23:50:11 --> XSS Filtering completed
DEBUG - 2012-04-06 23:50:11 --> CRSF cookie Set
DEBUG - 2012-04-06 23:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:50:11 --> Language Class Initialized
DEBUG - 2012-04-06 23:50:11 --> Loader Class Initialized
DEBUG - 2012-04-06 23:50:11 --> Controller Class Initialized
DEBUG - 2012-04-06 23:50:11 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:50:11 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:50:11 --> Session Class Initialized
DEBUG - 2012-04-06 23:50:11 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:50:11 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:50:11 --> Session routines successfully run
DEBUG - 2012-04-06 23:50:11 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:50:11 --> Pages view: home
DEBUG - 2012-04-06 23:50:11 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:50:11 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:50:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:50:11 --> Final output sent to browser
DEBUG - 2012-04-06 23:50:11 --> Total execution time: 0.0104
DEBUG - 2012-04-06 23:50:15 --> Config Class Initialized
DEBUG - 2012-04-06 23:50:15 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:50:15 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:50:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:50:15 --> URI Class Initialized
DEBUG - 2012-04-06 23:50:15 --> Router Class Initialized
DEBUG - 2012-04-06 23:50:15 --> Output Class Initialized
DEBUG - 2012-04-06 23:50:15 --> Security Class Initialized
DEBUG - 2012-04-06 23:50:15 --> Input Class Initialized
DEBUG - 2012-04-06 23:50:15 --> XSS Filtering completed
DEBUG - 2012-04-06 23:50:15 --> XSS Filtering completed
DEBUG - 2012-04-06 23:50:15 --> XSS Filtering completed
DEBUG - 2012-04-06 23:50:15 --> CRSF cookie Set
DEBUG - 2012-04-06 23:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:50:15 --> Language Class Initialized
DEBUG - 2012-04-06 23:50:15 --> Loader Class Initialized
DEBUG - 2012-04-06 23:50:15 --> Controller Class Initialized
DEBUG - 2012-04-06 23:50:15 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:50:15 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:50:15 --> Session Class Initialized
DEBUG - 2012-04-06 23:50:15 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:50:15 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:50:15 --> Session routines successfully run
DEBUG - 2012-04-06 23:50:15 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:50:15 --> Pages view: logoff
DEBUG - 2012-04-06 23:50:15 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:50:15 --> File loaded: application/views/pages/logoff.php
DEBUG - 2012-04-06 23:50:15 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:50:15 --> Final output sent to browser
DEBUG - 2012-04-06 23:50:15 --> Total execution time: 0.0186
DEBUG - 2012-04-06 23:50:18 --> Config Class Initialized
DEBUG - 2012-04-06 23:50:18 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:50:18 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:50:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:50:18 --> URI Class Initialized
DEBUG - 2012-04-06 23:50:18 --> Router Class Initialized
DEBUG - 2012-04-06 23:50:18 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:50:18 --> Output Class Initialized
DEBUG - 2012-04-06 23:50:18 --> Security Class Initialized
DEBUG - 2012-04-06 23:50:18 --> Input Class Initialized
DEBUG - 2012-04-06 23:50:18 --> XSS Filtering completed
DEBUG - 2012-04-06 23:50:18 --> XSS Filtering completed
DEBUG - 2012-04-06 23:50:18 --> CRSF cookie Set
DEBUG - 2012-04-06 23:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:50:18 --> Language Class Initialized
DEBUG - 2012-04-06 23:50:18 --> Loader Class Initialized
DEBUG - 2012-04-06 23:50:18 --> Controller Class Initialized
DEBUG - 2012-04-06 23:50:18 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:50:18 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:50:18 --> Session Class Initialized
DEBUG - 2012-04-06 23:50:18 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:50:18 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:50:18 --> A session cookie was not found.
DEBUG - 2012-04-06 23:50:18 --> Session routines successfully run
DEBUG - 2012-04-06 23:50:18 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:50:18 --> Pages view: home
DEBUG - 2012-04-06 23:50:18 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:50:18 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:50:18 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:50:18 --> Final output sent to browser
DEBUG - 2012-04-06 23:50:18 --> Total execution time: 0.0188
DEBUG - 2012-04-06 23:50:59 --> Config Class Initialized
DEBUG - 2012-04-06 23:50:59 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:50:59 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:50:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:50:59 --> URI Class Initialized
DEBUG - 2012-04-06 23:50:59 --> Router Class Initialized
DEBUG - 2012-04-06 23:50:59 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:50:59 --> Output Class Initialized
DEBUG - 2012-04-06 23:50:59 --> Security Class Initialized
DEBUG - 2012-04-06 23:50:59 --> Input Class Initialized
DEBUG - 2012-04-06 23:50:59 --> XSS Filtering completed
DEBUG - 2012-04-06 23:50:59 --> XSS Filtering completed
DEBUG - 2012-04-06 23:50:59 --> XSS Filtering completed
DEBUG - 2012-04-06 23:50:59 --> CRSF cookie Set
DEBUG - 2012-04-06 23:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:50:59 --> Language Class Initialized
DEBUG - 2012-04-06 23:50:59 --> Loader Class Initialized
DEBUG - 2012-04-06 23:50:59 --> Controller Class Initialized
DEBUG - 2012-04-06 23:50:59 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:50:59 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:50:59 --> Session Class Initialized
DEBUG - 2012-04-06 23:50:59 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:50:59 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:50:59 --> Session routines successfully run
DEBUG - 2012-04-06 23:50:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:50:59 --> Pages view: home
DEBUG - 2012-04-06 23:50:59 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:50:59 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:50:59 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:50:59 --> Final output sent to browser
DEBUG - 2012-04-06 23:50:59 --> Total execution time: 0.0095
DEBUG - 2012-04-06 23:51:13 --> Config Class Initialized
DEBUG - 2012-04-06 23:51:13 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:51:13 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:51:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:51:13 --> URI Class Initialized
DEBUG - 2012-04-06 23:51:13 --> Router Class Initialized
DEBUG - 2012-04-06 23:51:13 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:51:13 --> Output Class Initialized
DEBUG - 2012-04-06 23:51:13 --> Security Class Initialized
DEBUG - 2012-04-06 23:51:13 --> Input Class Initialized
DEBUG - 2012-04-06 23:51:13 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:13 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:13 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:13 --> CRSF cookie Set
DEBUG - 2012-04-06 23:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:51:13 --> Language Class Initialized
DEBUG - 2012-04-06 23:51:13 --> Loader Class Initialized
DEBUG - 2012-04-06 23:51:13 --> Controller Class Initialized
DEBUG - 2012-04-06 23:51:13 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:51:13 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:51:13 --> Session Class Initialized
DEBUG - 2012-04-06 23:51:13 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:51:13 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:51:13 --> Session routines successfully run
DEBUG - 2012-04-06 23:51:13 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:51:13 --> Pages view: home
DEBUG - 2012-04-06 23:51:13 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:51:13 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:51:13 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:51:13 --> Final output sent to browser
DEBUG - 2012-04-06 23:51:13 --> Total execution time: 0.0124
DEBUG - 2012-04-06 23:51:25 --> Config Class Initialized
DEBUG - 2012-04-06 23:51:25 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:51:25 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:51:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:51:25 --> URI Class Initialized
DEBUG - 2012-04-06 23:51:25 --> Router Class Initialized
DEBUG - 2012-04-06 23:51:25 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:51:25 --> Output Class Initialized
DEBUG - 2012-04-06 23:51:25 --> Security Class Initialized
DEBUG - 2012-04-06 23:51:25 --> Input Class Initialized
DEBUG - 2012-04-06 23:51:25 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:25 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:25 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:25 --> CRSF cookie Set
DEBUG - 2012-04-06 23:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:51:25 --> Language Class Initialized
DEBUG - 2012-04-06 23:51:25 --> Loader Class Initialized
DEBUG - 2012-04-06 23:51:25 --> Controller Class Initialized
DEBUG - 2012-04-06 23:51:25 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:51:25 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:51:25 --> Session Class Initialized
DEBUG - 2012-04-06 23:51:25 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:51:25 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:51:25 --> Session routines successfully run
DEBUG - 2012-04-06 23:51:25 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:51:25 --> Pages view: home
DEBUG - 2012-04-06 23:51:25 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:51:25 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:51:25 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:51:25 --> Final output sent to browser
DEBUG - 2012-04-06 23:51:25 --> Total execution time: 0.0134
DEBUG - 2012-04-06 23:51:39 --> Config Class Initialized
DEBUG - 2012-04-06 23:51:39 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:51:39 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:51:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:51:39 --> URI Class Initialized
DEBUG - 2012-04-06 23:51:39 --> Router Class Initialized
DEBUG - 2012-04-06 23:51:39 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:51:39 --> Output Class Initialized
DEBUG - 2012-04-06 23:51:39 --> Security Class Initialized
DEBUG - 2012-04-06 23:51:39 --> Input Class Initialized
DEBUG - 2012-04-06 23:51:39 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:39 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:39 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:39 --> CRSF cookie Set
DEBUG - 2012-04-06 23:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:51:39 --> Language Class Initialized
DEBUG - 2012-04-06 23:51:39 --> Loader Class Initialized
DEBUG - 2012-04-06 23:51:39 --> Controller Class Initialized
DEBUG - 2012-04-06 23:51:39 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:51:39 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:51:39 --> Session Class Initialized
DEBUG - 2012-04-06 23:51:39 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:51:39 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:51:39 --> Session routines successfully run
DEBUG - 2012-04-06 23:51:39 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:51:39 --> Pages view: home
DEBUG - 2012-04-06 23:51:39 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:51:39 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:51:39 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:51:39 --> Final output sent to browser
DEBUG - 2012-04-06 23:51:39 --> Total execution time: 0.0128
DEBUG - 2012-04-06 23:51:45 --> Config Class Initialized
DEBUG - 2012-04-06 23:51:45 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:51:45 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:51:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:51:45 --> URI Class Initialized
DEBUG - 2012-04-06 23:51:45 --> Router Class Initialized
DEBUG - 2012-04-06 23:51:45 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:51:45 --> Output Class Initialized
DEBUG - 2012-04-06 23:51:45 --> Security Class Initialized
DEBUG - 2012-04-06 23:51:45 --> Input Class Initialized
DEBUG - 2012-04-06 23:51:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:45 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:45 --> CRSF cookie Set
DEBUG - 2012-04-06 23:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:51:45 --> Language Class Initialized
DEBUG - 2012-04-06 23:51:45 --> Loader Class Initialized
DEBUG - 2012-04-06 23:51:45 --> Controller Class Initialized
DEBUG - 2012-04-06 23:51:45 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:51:45 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:51:45 --> Session Class Initialized
DEBUG - 2012-04-06 23:51:45 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:51:45 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:51:45 --> Session routines successfully run
DEBUG - 2012-04-06 23:51:45 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:51:45 --> Pages view: home
DEBUG - 2012-04-06 23:51:45 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:51:45 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:51:45 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:51:45 --> Final output sent to browser
DEBUG - 2012-04-06 23:51:45 --> Total execution time: 0.0108
DEBUG - 2012-04-06 23:51:55 --> Config Class Initialized
DEBUG - 2012-04-06 23:51:55 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:51:55 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:51:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:51:55 --> URI Class Initialized
DEBUG - 2012-04-06 23:51:55 --> Router Class Initialized
DEBUG - 2012-04-06 23:51:55 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:51:55 --> Output Class Initialized
DEBUG - 2012-04-06 23:51:55 --> Security Class Initialized
DEBUG - 2012-04-06 23:51:55 --> Input Class Initialized
DEBUG - 2012-04-06 23:51:55 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:55 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:55 --> XSS Filtering completed
DEBUG - 2012-04-06 23:51:55 --> CRSF cookie Set
DEBUG - 2012-04-06 23:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:51:55 --> Language Class Initialized
DEBUG - 2012-04-06 23:51:55 --> Loader Class Initialized
DEBUG - 2012-04-06 23:51:55 --> Controller Class Initialized
DEBUG - 2012-04-06 23:51:55 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:51:55 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:51:55 --> Session Class Initialized
DEBUG - 2012-04-06 23:51:55 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:51:55 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:51:55 --> Session routines successfully run
DEBUG - 2012-04-06 23:51:55 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:51:55 --> Pages view: home
DEBUG - 2012-04-06 23:51:55 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:51:55 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:51:55 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:51:55 --> Final output sent to browser
DEBUG - 2012-04-06 23:51:55 --> Total execution time: 0.0100
DEBUG - 2012-04-06 23:52:11 --> Config Class Initialized
DEBUG - 2012-04-06 23:52:11 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:52:11 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:52:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:52:11 --> URI Class Initialized
DEBUG - 2012-04-06 23:52:11 --> Router Class Initialized
DEBUG - 2012-04-06 23:52:11 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:52:11 --> Output Class Initialized
DEBUG - 2012-04-06 23:52:11 --> Security Class Initialized
DEBUG - 2012-04-06 23:52:11 --> Input Class Initialized
DEBUG - 2012-04-06 23:52:11 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:11 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:11 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:11 --> CRSF cookie Set
DEBUG - 2012-04-06 23:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:52:11 --> Language Class Initialized
DEBUG - 2012-04-06 23:52:11 --> Loader Class Initialized
DEBUG - 2012-04-06 23:52:11 --> Controller Class Initialized
DEBUG - 2012-04-06 23:52:11 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:52:11 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:52:11 --> Session Class Initialized
DEBUG - 2012-04-06 23:52:11 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:52:11 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:52:11 --> Session routines successfully run
DEBUG - 2012-04-06 23:52:11 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:52:11 --> Pages view: home
DEBUG - 2012-04-06 23:52:11 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:52:11 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:52:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:52:11 --> Final output sent to browser
DEBUG - 2012-04-06 23:52:11 --> Total execution time: 0.0126
DEBUG - 2012-04-06 23:52:54 --> Config Class Initialized
DEBUG - 2012-04-06 23:52:54 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:52:54 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:52:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:52:54 --> URI Class Initialized
DEBUG - 2012-04-06 23:52:54 --> Router Class Initialized
DEBUG - 2012-04-06 23:52:54 --> Output Class Initialized
DEBUG - 2012-04-06 23:52:54 --> Security Class Initialized
DEBUG - 2012-04-06 23:52:54 --> Input Class Initialized
DEBUG - 2012-04-06 23:52:54 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:54 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:54 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:54 --> CRSF cookie Set
DEBUG - 2012-04-06 23:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:52:54 --> Language Class Initialized
DEBUG - 2012-04-06 23:52:54 --> Loader Class Initialized
DEBUG - 2012-04-06 23:52:54 --> Controller Class Initialized
DEBUG - 2012-04-06 23:52:54 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:52:54 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:52:54 --> Session Class Initialized
DEBUG - 2012-04-06 23:52:54 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:52:54 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:52:54 --> Session routines successfully run
DEBUG - 2012-04-06 23:52:54 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:52:54 --> Pages view: nuevacuenta
DEBUG - 2012-04-06 23:52:54 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:52:54 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-06 23:52:54 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:52:54 --> Final output sent to browser
DEBUG - 2012-04-06 23:52:54 --> Total execution time: 0.0125
DEBUG - 2012-04-06 23:52:57 --> Config Class Initialized
DEBUG - 2012-04-06 23:52:57 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:52:57 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:52:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:52:57 --> URI Class Initialized
DEBUG - 2012-04-06 23:52:57 --> Router Class Initialized
DEBUG - 2012-04-06 23:52:57 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:52:57 --> Output Class Initialized
DEBUG - 2012-04-06 23:52:57 --> Security Class Initialized
DEBUG - 2012-04-06 23:52:57 --> Input Class Initialized
DEBUG - 2012-04-06 23:52:57 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:57 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:57 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:57 --> CRSF cookie Set
DEBUG - 2012-04-06 23:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:52:57 --> Language Class Initialized
DEBUG - 2012-04-06 23:52:57 --> Loader Class Initialized
DEBUG - 2012-04-06 23:52:57 --> Controller Class Initialized
DEBUG - 2012-04-06 23:52:57 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:52:57 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:52:57 --> Session Class Initialized
DEBUG - 2012-04-06 23:52:57 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:52:57 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:52:57 --> Session routines successfully run
DEBUG - 2012-04-06 23:52:57 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:52:57 --> Pages view: home
DEBUG - 2012-04-06 23:52:57 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:52:57 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:52:57 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:52:57 --> Final output sent to browser
DEBUG - 2012-04-06 23:52:57 --> Total execution time: 0.0106
DEBUG - 2012-04-06 23:52:58 --> Config Class Initialized
DEBUG - 2012-04-06 23:52:58 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:52:58 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:52:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:52:58 --> URI Class Initialized
DEBUG - 2012-04-06 23:52:58 --> Router Class Initialized
DEBUG - 2012-04-06 23:52:58 --> Output Class Initialized
DEBUG - 2012-04-06 23:52:58 --> Security Class Initialized
DEBUG - 2012-04-06 23:52:58 --> Input Class Initialized
DEBUG - 2012-04-06 23:52:58 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:58 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:58 --> XSS Filtering completed
DEBUG - 2012-04-06 23:52:58 --> CRSF cookie Set
DEBUG - 2012-04-06 23:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:52:58 --> Language Class Initialized
DEBUG - 2012-04-06 23:52:58 --> Loader Class Initialized
DEBUG - 2012-04-06 23:52:58 --> Controller Class Initialized
DEBUG - 2012-04-06 23:52:58 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:52:58 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:52:58 --> Session Class Initialized
DEBUG - 2012-04-06 23:52:58 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:52:58 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:52:58 --> Session routines successfully run
DEBUG - 2012-04-06 23:52:58 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:52:58 --> Pages view: nuevacuenta
DEBUG - 2012-04-06 23:52:58 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:52:58 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-06 23:52:58 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:52:58 --> Final output sent to browser
DEBUG - 2012-04-06 23:52:58 --> Total execution time: 0.0095
DEBUG - 2012-04-06 23:53:06 --> Config Class Initialized
DEBUG - 2012-04-06 23:53:06 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:53:06 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:53:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:53:06 --> URI Class Initialized
DEBUG - 2012-04-06 23:53:06 --> Router Class Initialized
DEBUG - 2012-04-06 23:53:06 --> Output Class Initialized
DEBUG - 2012-04-06 23:53:06 --> Security Class Initialized
DEBUG - 2012-04-06 23:53:06 --> Input Class Initialized
DEBUG - 2012-04-06 23:53:06 --> XSS Filtering completed
DEBUG - 2012-04-06 23:53:06 --> XSS Filtering completed
DEBUG - 2012-04-06 23:53:06 --> XSS Filtering completed
DEBUG - 2012-04-06 23:53:06 --> CRSF cookie Set
DEBUG - 2012-04-06 23:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:53:06 --> Language Class Initialized
DEBUG - 2012-04-06 23:53:06 --> Loader Class Initialized
DEBUG - 2012-04-06 23:53:06 --> Controller Class Initialized
DEBUG - 2012-04-06 23:53:06 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:53:06 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:53:06 --> Session Class Initialized
DEBUG - 2012-04-06 23:53:06 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:53:06 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:53:06 --> Session routines successfully run
DEBUG - 2012-04-06 23:53:06 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:53:06 --> Pages view: nuevacuenta
DEBUG - 2012-04-06 23:53:06 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:53:06 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-06 23:53:06 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:53:06 --> Final output sent to browser
DEBUG - 2012-04-06 23:53:06 --> Total execution time: 0.0134
DEBUG - 2012-04-06 23:53:55 --> Config Class Initialized
DEBUG - 2012-04-06 23:53:55 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:53:55 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:53:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:53:55 --> URI Class Initialized
DEBUG - 2012-04-06 23:53:55 --> Router Class Initialized
DEBUG - 2012-04-06 23:53:55 --> Output Class Initialized
DEBUG - 2012-04-06 23:53:55 --> Security Class Initialized
DEBUG - 2012-04-06 23:53:55 --> Input Class Initialized
DEBUG - 2012-04-06 23:53:55 --> XSS Filtering completed
DEBUG - 2012-04-06 23:53:55 --> XSS Filtering completed
DEBUG - 2012-04-06 23:53:55 --> XSS Filtering completed
DEBUG - 2012-04-06 23:53:55 --> CRSF cookie Set
DEBUG - 2012-04-06 23:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:53:55 --> Language Class Initialized
DEBUG - 2012-04-06 23:53:55 --> Loader Class Initialized
DEBUG - 2012-04-06 23:53:55 --> Controller Class Initialized
DEBUG - 2012-04-06 23:53:55 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:53:55 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:53:55 --> Session Class Initialized
DEBUG - 2012-04-06 23:53:55 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:53:55 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:53:55 --> Session routines successfully run
DEBUG - 2012-04-06 23:53:55 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:53:55 --> Pages view: nuevacuenta
DEBUG - 2012-04-06 23:53:55 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:53:55 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-06 23:53:55 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:53:55 --> Final output sent to browser
DEBUG - 2012-04-06 23:53:55 --> Total execution time: 0.0103
DEBUG - 2012-04-06 23:54:05 --> Config Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:54:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:54:05 --> URI Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Router Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Output Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Security Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Input Class Initialized
DEBUG - 2012-04-06 23:54:05 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:05 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:05 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:05 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:05 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:05 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:05 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:05 --> CRSF cookie Set
DEBUG - 2012-04-06 23:54:05 --> CSRF token verified 
DEBUG - 2012-04-06 23:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:54:05 --> Language Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Loader Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Controller Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Model Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Model Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Database Driver Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Session Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:54:05 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Session routines successfully run
DEBUG - 2012-04-06 23:54:05 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:54:05 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:54:05 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:54:05 --> ermex/newaccount
DEBUG - 2012-04-06 23:54:05 --> App_model/userExist
DEBUG - 2012-04-06 23:54:05 --> Email already used
DEBUG - 2012-04-06 23:54:05 --> Config Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:54:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:54:05 --> URI Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Router Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Output Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Security Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Input Class Initialized
DEBUG - 2012-04-06 23:54:05 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:05 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:05 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:05 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:05 --> CRSF cookie Set
DEBUG - 2012-04-06 23:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:54:05 --> Language Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Loader Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Controller Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:54:05 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:54:05 --> Session Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:54:05 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:54:05 --> Session routines successfully run
DEBUG - 2012-04-06 23:54:05 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:54:05 --> Pages view: nuevacuenta
DEBUG - 2012-04-06 23:54:05 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:54:05 --> File loaded: application/views/pages/nuevacuenta.php
DEBUG - 2012-04-06 23:54:05 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:54:05 --> Final output sent to browser
DEBUG - 2012-04-06 23:54:05 --> Total execution time: 0.0083
DEBUG - 2012-04-06 23:54:33 --> Config Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:54:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:54:33 --> URI Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Router Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Output Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Security Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Input Class Initialized
DEBUG - 2012-04-06 23:54:33 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:33 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:33 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:33 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:33 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:33 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:33 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:33 --> CRSF cookie Set
DEBUG - 2012-04-06 23:54:33 --> CSRF token verified 
DEBUG - 2012-04-06 23:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:54:33 --> Language Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Loader Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Controller Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Model Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Model Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Database Driver Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Session Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:54:33 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Session routines successfully run
DEBUG - 2012-04-06 23:54:33 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:54:33 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:54:33 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:54:33 --> ermex/newaccount
DEBUG - 2012-04-06 23:54:33 --> App_model/userExist
DEBUG - 2012-04-06 23:54:33 --> Email not registered
DEBUG - 2012-04-06 23:54:33 --> App_model/insertUser
ERROR - 2012-04-06 23:54:33 --> Severity: Notice  --> Undefined variable: glob_mensajeExito /usr/local/zend/apache2/htdocs/ermex/ermx/application/controllers/ermex.php 35
DEBUG - 2012-04-06 23:54:33 --> Config Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:54:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:54:33 --> URI Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Router Class Initialized
DEBUG - 2012-04-06 23:54:33 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:54:33 --> Output Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Security Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Input Class Initialized
DEBUG - 2012-04-06 23:54:33 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:33 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:33 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:33 --> XSS Filtering completed
DEBUG - 2012-04-06 23:54:33 --> CRSF cookie Set
DEBUG - 2012-04-06 23:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:54:33 --> Language Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Loader Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Controller Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:54:33 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:54:33 --> Session Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:54:33 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:54:33 --> Session routines successfully run
DEBUG - 2012-04-06 23:54:33 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:54:33 --> Pages view: home
DEBUG - 2012-04-06 23:54:33 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:54:33 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:54:33 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:54:33 --> Final output sent to browser
DEBUG - 2012-04-06 23:54:33 --> Total execution time: 0.0082
DEBUG - 2012-04-06 23:55:12 --> Config Class Initialized
DEBUG - 2012-04-06 23:55:12 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:55:12 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:55:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:55:12 --> URI Class Initialized
DEBUG - 2012-04-06 23:55:12 --> Router Class Initialized
DEBUG - 2012-04-06 23:55:12 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:55:12 --> Output Class Initialized
DEBUG - 2012-04-06 23:55:12 --> Security Class Initialized
DEBUG - 2012-04-06 23:55:12 --> Input Class Initialized
DEBUG - 2012-04-06 23:55:12 --> XSS Filtering completed
DEBUG - 2012-04-06 23:55:12 --> XSS Filtering completed
DEBUG - 2012-04-06 23:55:12 --> XSS Filtering completed
DEBUG - 2012-04-06 23:55:12 --> XSS Filtering completed
DEBUG - 2012-04-06 23:55:12 --> CRSF cookie Set
DEBUG - 2012-04-06 23:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:55:12 --> Language Class Initialized
DEBUG - 2012-04-06 23:55:12 --> Loader Class Initialized
DEBUG - 2012-04-06 23:55:12 --> Controller Class Initialized
DEBUG - 2012-04-06 23:55:12 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:55:12 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:55:12 --> Session Class Initialized
DEBUG - 2012-04-06 23:55:12 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:55:12 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:55:12 --> Session routines successfully run
DEBUG - 2012-04-06 23:55:12 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:55:12 --> Pages view: home
DEBUG - 2012-04-06 23:55:12 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:55:12 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:55:12 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:55:12 --> Final output sent to browser
DEBUG - 2012-04-06 23:55:12 --> Total execution time: 0.0107
DEBUG - 2012-04-06 23:56:08 --> Config Class Initialized
DEBUG - 2012-04-06 23:56:08 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:56:08 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:56:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:56:08 --> URI Class Initialized
DEBUG - 2012-04-06 23:56:08 --> Router Class Initialized
DEBUG - 2012-04-06 23:56:08 --> No URI present. Default controller set.
DEBUG - 2012-04-06 23:56:08 --> Output Class Initialized
DEBUG - 2012-04-06 23:56:08 --> Security Class Initialized
DEBUG - 2012-04-06 23:56:08 --> Input Class Initialized
DEBUG - 2012-04-06 23:56:08 --> XSS Filtering completed
DEBUG - 2012-04-06 23:56:08 --> XSS Filtering completed
DEBUG - 2012-04-06 23:56:08 --> XSS Filtering completed
DEBUG - 2012-04-06 23:56:08 --> XSS Filtering completed
DEBUG - 2012-04-06 23:56:08 --> CRSF cookie Set
DEBUG - 2012-04-06 23:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:56:08 --> Language Class Initialized
DEBUG - 2012-04-06 23:56:08 --> Loader Class Initialized
DEBUG - 2012-04-06 23:56:08 --> Controller Class Initialized
DEBUG - 2012-04-06 23:56:08 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:56:08 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:56:08 --> Session Class Initialized
DEBUG - 2012-04-06 23:56:08 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:56:08 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:56:08 --> Session routines successfully run
DEBUG - 2012-04-06 23:56:08 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:56:08 --> Pages view: home
DEBUG - 2012-04-06 23:56:08 --> File loaded: application/views/templates/headerhome.php
DEBUG - 2012-04-06 23:56:08 --> File loaded: application/views/pages/home.php
DEBUG - 2012-04-06 23:56:08 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:56:08 --> Final output sent to browser
DEBUG - 2012-04-06 23:56:08 --> Total execution time: 0.0136
DEBUG - 2012-04-06 23:59:29 --> Config Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:59:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:59:29 --> URI Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Router Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Output Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Security Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Input Class Initialized
DEBUG - 2012-04-06 23:59:29 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:29 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:29 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:29 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:29 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:29 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:29 --> CRSF cookie Set
DEBUG - 2012-04-06 23:59:29 --> CSRF token verified 
DEBUG - 2012-04-06 23:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:59:29 --> Language Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Loader Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Controller Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Model Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Model Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Database Driver Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Session Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:59:29 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Session routines successfully run
DEBUG - 2012-04-06 23:59:29 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:59:29 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:59:29 --> *Security/login
DEBUG - 2012-04-06 23:59:29 --> App_model login
DEBUG - 2012-04-06 23:59:29 --> **Found user**
DEBUG - 2012-04-06 23:59:29 --> Config Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:59:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:59:29 --> URI Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Router Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Output Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Security Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Input Class Initialized
DEBUG - 2012-04-06 23:59:29 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:29 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:29 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:29 --> CRSF cookie Set
DEBUG - 2012-04-06 23:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:59:29 --> Language Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Loader Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Controller Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:59:29 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:59:29 --> Session Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:59:29 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:59:29 --> Session routines successfully run
DEBUG - 2012-04-06 23:59:29 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:59:29 --> Pages view: mainmenu
DEBUG - 2012-04-06 23:59:29 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 23:59:29 --> File loaded: application/views/pages/mainmenu.php
DEBUG - 2012-04-06 23:59:29 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:59:29 --> Final output sent to browser
DEBUG - 2012-04-06 23:59:29 --> Total execution time: 0.0090
DEBUG - 2012-04-06 23:59:43 --> Config Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:59:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:59:43 --> URI Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Router Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Output Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Security Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Input Class Initialized
DEBUG - 2012-04-06 23:59:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:43 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:43 --> CRSF cookie Set
DEBUG - 2012-04-06 23:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:59:43 --> Language Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Loader Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Controller Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Model Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Model Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Database Driver Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Session Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:59:43 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:59:43 --> Session routines successfully run
DEBUG - 2012-04-06 23:59:43 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:59:43 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:59:43 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:59:43 --> ermex/mapLocator
DEBUG - 2012-04-06 23:59:43 --> localizando por ADDR
DEBUG - 2012-04-06 23:59:43 --> creando mapa por addr: $addr 
DEBUG - 2012-04-06 23:59:43 --> GMap class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:59:43 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 23:59:43 --> File loaded: application/views/pages/mapa.php
DEBUG - 2012-04-06 23:59:43 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:59:43 --> Final output sent to browser
DEBUG - 2012-04-06 23:59:43 --> Total execution time: 0.0411
DEBUG - 2012-04-06 23:59:58 --> Config Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Hooks Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Utf8 Class Initialized
DEBUG - 2012-04-06 23:59:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 23:59:58 --> URI Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Router Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Output Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Security Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Input Class Initialized
DEBUG - 2012-04-06 23:59:58 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:58 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:58 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:58 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:58 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:58 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:58 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:58 --> XSS Filtering completed
DEBUG - 2012-04-06 23:59:58 --> CRSF cookie Set
DEBUG - 2012-04-06 23:59:58 --> CSRF token verified 
DEBUG - 2012-04-06 23:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 23:59:58 --> Language Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Loader Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Controller Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Model Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Model Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Database Driver Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Session Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Helper loaded: string_helper
DEBUG - 2012-04-06 23:59:58 --> Encrypt Class Initialized
DEBUG - 2012-04-06 23:59:58 --> Session routines successfully run
DEBUG - 2012-04-06 23:59:58 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2012-04-06 23:59:58 --> Helper loaded: url_helper
DEBUG - 2012-04-06 23:59:58 --> Helper loaded: form_helper
DEBUG - 2012-04-06 23:59:58 --> ermex/newregistry	
DEBUG - 2012-04-06 23:59:58 --> forma de registro para: 18.879311 x -97.111696 x Puerta del Sol, 94420 Palmira, VER, México
DEBUG - 2012-04-06 23:59:58 --> File loaded: application/views/templates/header.php
DEBUG - 2012-04-06 23:59:58 --> File loaded: application/views/pages/registro.php
DEBUG - 2012-04-06 23:59:58 --> File loaded: application/views/templates/footer.php
DEBUG - 2012-04-06 23:59:58 --> Final output sent to browser
DEBUG - 2012-04-06 23:59:58 --> Total execution time: 0.0175
