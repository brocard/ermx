  <div class="row-fluid">
    <div class="span8">
      <div><a href="<?=base_url()?>index.php"><img src="<?=base_url()?>/design/img/miniermex.png" alt="ERmx"></a> beta</div>
      <div class="alert alert-error separaForma">
        <h2 class="alert-error">Acceso restringido, por favor ingresa tu usuario y password para continuar.</h2>
        <div class="row-fluid">
          <div class="span8 offset1">
            	<a href="<?=base_url()?>index.php" class="btn btn-warning">Ir a la página inicial</a>
          </div>
        </div>
        
       
      </div>

      <!-- /hero-unit --> 
      
    </div>
  </div>