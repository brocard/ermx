</div>
<!-- /container -->

<footer>
<div class="alert alert-success separaForma">Ayúdanos a mejorar: <a href="https://twitter.com/ermx1" class="twitter-follow-button" data-show-count="false" data-lang="en">Follow @ermx1</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script></div>
  <center>
    <p>&copy; Metis Studio. 2012</p>
  </center>
  <!-- diseñado por Metis Studio --> 
</footer>
</div>
<!-- ================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 

<script src="<?=base_url()?>/design/js/bootstrap-transition.js"></script> 
<script src="<?=base_url()?>/design/js/bootstrap-alert.js"></script> 
<script src="<?=base_url()?>/design/js/bootstrap-modal.js"></script> 
<script src="<?=base_url()?>/design/js/bootstrap-dropdown.js"></script> 
<script src="<?=base_url()?>/design/js/bootstrap-scrollspy.js"></script> 
<script src="<?=base_url()?>/design/js/bootstrap-tab.js"></script> 
<script src="<?=base_url()?>/design/js/bootstrap-tooltip.js"></script> 
<script src="<?=base_url()?>/design/js/bootstrap-popover.js"></script> 
<script src="<?=base_url()?>/design/js/bootstrap-button.js"></script> 
<script src="<?=base_url()?>/design/js/bootstrap-collapse.js"></script> 
<script src="<?=base_url()?>/design/js/bootstrap-carousel.js"></script> 
<script src="<?=base_url()?>/design/js/bootstrap-typeahead.js"></script>
</body>
</html>
