<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>erMx</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black" />
<meta name="description" content="ERMx Localiza las salas de emergencia de México y compártelas con el mundo">
<meta name="author" content="Metistd">
<!-- Le styles -->
<link href="<?=base_url()?>/design/css/bootstrap.css" rel="stylesheet">
<link href="<?=base_url()?>/design/css/bootstrap-responsive.css" rel="stylesheet">
<link href="<?=base_url()?>/design/css/ermex.css" rel="stylesheet">
<script type="text/javascript" src="<?=base_url()?>/design/js/jquery-1.7.1.min.js"></script> 
<script type="text/javascript" src="<?=base_url()?>/design/js/jquery.validate.js"></script> 
<style>
body {
	padding-top: 5px; /* 60px to make the container go all the way to the bottom of the topbar */
}
</style>
</head>
<body>
<!-- <?php //print_r($sessiondata); ?> -->
<!-- container -->
<div class="container-fluid">
    
